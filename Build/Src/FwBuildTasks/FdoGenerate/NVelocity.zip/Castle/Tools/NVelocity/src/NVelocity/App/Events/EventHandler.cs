namespace NVelocity.App.Events
{
	/// <summary>  Base interface for all event handlers
	/// *
	/// </summary>
	/// <author> <a href="mailto:geirm@optonline.net">Geir Magnusson Jr.</a>
	/// </author>
	/// <version> $Id: EventHandler.cs,v 1.3 2003/10/27 13:54:07 corts Exp $
	///
	/// </version>
	public interface EventHandler
	{
	}
}