set nocount on















if object_id('master..xp_IsMatch') is not null begin
	print 'removing xp_IsMatch'
	EXEC master..sp_dropextendedproc 'xp_IsMatch'
end
go
print 'adding xp_IsMatch'
EXEC master..sp_addextendedproc 'xp_IsMatch', 'FwSqlExtend.dll'
go







-- Version$ table.
if object_id('Version$') is not null begin
	print 'removing table Version$'
	drop table [Version$]
end
go
print 'creating table Version$'
create table [Version$] (
	[DbVer]		int primary key,
	[Guid$]		uniqueidentifier	not null,
	[DateStdVer]	datetime		not null,
	[DateCustomized] datetime,
	[ParDbVer]	int,
	[ParGuid]	uniqueidentifier,
	[ParDateStdVer]	datetime,
	[ParDateCustomized] datetime
)
go

-- This must match kdbAppVersion in DbVersion.h. See DbVersion.h for further information.
insert into Version$([DbVer], [Guid$], [DateStdVer], [DateCustomized], 
		[ParDbVer], [ParGuid], [ParDateStdVer], [ParDateCustomized])
	values (200006, newid(), current_timestamp, NULL, NULL, NULL, NULL, NULL);
go


-- AppCompat$ table.
if object_id('AppCompat$') is not null begin
	print 'removing proc AppCompat$'
	drop proc [AppCompat$]
end
go
print 'creating table AppCompat$'
create table [AppCompat$] (
	[AppGuid] uniqueidentifier primary key,
	[AppName] nvarchar(200),
	[EarliestCompatVer] int not null,
	[LastKnownCompatVer] int not null,
)
go

insert into AppCompat$([AppGuid], [AppName], [EarliestCompatVer], [LastKnownCompatVer]) 
values('39886581-4DD5-11d4-8078-0000C0FB81B5', 'FwNotebook', 500, 500);
insert into AppCompat$([AppGuid], [AppName], [EarliestCompatVer], [LastKnownCompatVer]) 
values('5EA62D01-7A78-11d4-8078-0000C0FB81B5', 'FwChoicesListEditor', 500, 500);
insert into AppCompat$([AppGuid], [AppName], [EarliestCompatVer], [LastKnownCompatVer]) 
values('A7D421E1-1DD3-11d5-B720-0010A4B54856', 'TE', 500, 500);
insert into AppCompat$([AppGuid], [AppName], [EarliestCompatVer], [LastKnownCompatVer]) 
values('8645FA4B-EE90-11D2-A9B8-0080C87B6086', 'FwMorphologyModelEditor', 500, 500);
insert into AppCompat$([AppGuid], [AppName], [EarliestCompatVer], [LastKnownCompatVer]) 
values('8645fa4d-ee90-11d2-a9b8-0080c87b6086', 'FwLexEd', 500, 500);
insert into AppCompat$([AppGuid], [AppName], [EarliestCompatVer], [LastKnownCompatVer]) 
values('76230C21-7084-11d5-83CD-0050BA78F57C', 'FwExplorer', 500, 500);
go


-- Module$ table.
if object_id('Module$') is not null begin
	print 'removing proc Module$'
	drop proc [Module$]
end
go
print 'creating table Module$'
create table [Module$] (
	[Id] 		int 				primary key clustered,
	[Name] 		nvarchar(100) not null	unique,
	[Ver] 		int 		not null,
	[VerBack] 	int 		not null,

	constraint [_CK_Module$_VerBack] check (0 < [VerBack] and [VerBack] <= [Ver])
)
go


-- Class$ table.
if object_id('Class$') is not null begin
	print 'removing proc Class$'
	drop proc [Class$]
end
go
print 'creating table Class$'
create table [Class$] (
	[Id]		int				primary key clustered,
	[Mod]		int		not null	references [Module$] ([Id]),
	[Base]		int		not null	references [Class$] ([Id]),
	[Abstract]	bit,
	[Name]		nvarchar(100) not null	unique
)
go

-- Field$ table.
if object_id('Field$') is not null begin
	print 'removing proc Field$'
	drop table [Field$]
end
go
print 'creating table Field$'
create table [Field$] (
	[Id]		int				primary key clustered,
	[Type]		int		not null,
	[Class]		int		not null	references [Class$] ([Id]),
	[DstCls]	int		null		references [Class$] ([Id]),
	[Name] 		nvarchar(100) not null,
	[Custom] 	tinyint		not null 	default 1,
	[CustomId] 	uniqueidentifier null		default newid(),
	[Min]		bigint		null		default null,
	[Max]		bigint		null		default null,
	[Big]		bit		null		default 0,
	UserLabel	NVARCHAR(100) NULL DEFAULT NULL,
	HelpString	NVARCHAR(100) NULL DEFAULT NULL,
	ListRootId	INT NULL DEFAULT NULL,
	WsSelector	INT NULL,
	XmlUI		NTEXT NULL
	constraint [_UQ_Field$_Class_Fieldname]	unique ([class], [name]),
	constraint [_CK_Field$_DstCls]
		check (([Type] < 23 and [DstCls] is null) or
			([Type] >= 23 and [DstCls] is not null)),
	constraint [_CK_Field$_Custom]
		check (([Custom] = 0 and [CustomId] is null) or
			([Custom] = 1 and [CustomId] is not null)),
	constraint [_CK_Field$_Type_Integer]
		check (([Type] <> 2 and [Min] is null and [Max] is null) or
			[Type] = 2),
	constraint [_CK_Field$_Type]
		check ([Type] In (	1,
					2,
					3,
					4,
					5,
					6,
					7,
					8,
					9,
					13,
					14,
					15,
					16,
					17,
					18,
					19,
					20,
					23,
					24,
					25,
					26,
					27,
					28)),
	constraint [_CK_Field$_MinMax] check ((Max is null and min is null) or (Type = 2 and Max >= Min))
)
create nonclustered index Ind_Field$_ClassType on Field$(Class, Type)
create nonclustered index ind_Field$_DstCls on Field$(DstCls)
go


-- ClassPar$ table.
if object_id('ClassPar$') is not null begin
	print 'removing proc ClassPar$'
	drop proc [ClassPar$]
end
go
print 'creating table ClassPar$'
create table [ClassPar$] (
	[Src]		int		not null	references [Class$] ([Id]),
	[Dst]		int		not null	references [Class$] ([Id]),
	[Depth] 	int 		not null,

	constraint [_CK_ClassPar$_Depth] check (([Depth] > 0 and [Src] <> [Dst]) or ([Depth] = 0 and [Src] = [Dst])),
	constraint [_UQ_ClassPar$_Depth] unique ([Src], [Depth]),
	constraint [_PK_ClassPar$] primary key clustered ([Src], [Dst])
)
create nonclustered index Ind_ClassPar$_Dst_Src on ClassPar$([Dst], [Src])
go


-- PropInfo$ view.
if object_id('PropInfo$') is not null begin
	print 'removing proc PropInfo$'
	drop view [PropInfo$]
end
go
print 'creating view PropInfo$'
go
create view [PropInfo$] as
select convert(char(25), [Class$].[Name]) as [Class],
	convert(char(5), [Class$].[Id]) as [Clid],
	convert(char(25), [Field$].[Name]) as [Property],
	convert(char(8), [Field$].[Id]) as [Flid],
	convert(char(20), case [Field$].[Type]
		when 1 then 'Boolean'
		when 2 then 'Integer'
		when 3 then 'Numeric'
		when 4 then 'Float'
		when 5 then 'Time'
		when 6 then 'Guid'
		when 7 then 'Image'
		when 8 then 'GenDate'
		when 9 then 'Binary'
		when 13 then 'String'
		when 14 then 'MultiString'
		when 15 then 'Unicode'
		when 16 then 'MultiUnicode'
		when 17 then 'BigString'
		when 18 then 'MultiBigString'
		when 19 then 'BigUnicode'
		when 20 then 'MultiBigUnicode'
		when 23 then 'OwningAtom'
		when 24 then 'ReferenceAtom'
		when 25 then 'OwningCollection'
		when 26 then 'ReferenceCollection'
		when 27 then 'OwningSequence'
		when 28 then 'ReferenceSequence'
		else 'Unknown'
		end) as [Type],
	convert(char(3), [Field$].[Type]) as [Tid],
	convert(char(25), (select [Name] from [Class$] where [Class$].[Id] = [DstCls])) as [Signature],
	convert(char(5), case [Field$].[Custom]
		when 0 then 'false'
		when 1 then 'true'
		else 'BOGUS'
		end) as [Custom],
	convert(char(20), [Field$].[CustomId]) as [CustomId]
from [Field$] join [Class$]
	on [Field$].[Class] = [Class$].[Id]
go

--( FlidCollation$ table.
IF OBJECT_ID('FlidCollation$') IS NOT NULL BEGIN
	PRINT 'removing table FlidCollation$'
	DROP TABLE [FlidCollation$]
END
GO
PRINT 'creating table FlidCollation$'
GO
CREATE TABLE FlidCollation$ (
	[Id]			INT	PRIMARY KEY CLUSTERED IDENTITY(1,1),
	[Ws]			INT NOT NULL,
	[CollationId]	INT	NOT NULL,
	[Flid]			INT NOT NULL)






-- ObjListTbl$ table.
if object_id('ObjListTbl$') is not null begin
	print 'removing table ObjListTbl$'
	drop table [ObjListTbl$]
end
go
print 'creating table ObjListTbl$'
go
create table [ObjListTbl$] (
	[uid] 	uniqueidentifier	not null,
	[ObjId] int			not null,
	[Ord] 	int			not null,
	[Class]	int			null
)
create nonclustered index IND_ObjListTbl$ on ObjListTbl$ (uid, ObjId)
go


-- ObjInfoTbl$ table.
if object_id('ObjInfoTbl$') is not null begin
	print 'removing table ObjInfoTbl$'
	drop table [ObjInfoTbl$]
end
go
print 'creating table ObjInfoTbl$'
go
create table [ObjInfoTbl$]
(
	[uid]		uniqueidentifier not null,
	[ObjId]		int		not null,
	[ObjClass]	int		null,
	[InheritDepth]	int		null		default(0),
	[OwnerDepth]	int		null		default(0),
	[RelObjId]	int		null,
	[RelObjClass]	int		null,
	[RelObjField]	int		null,
	[RelOrder]	int		null,
	[RelType]	int		null,
	[OrdKey]	varbinary(250)	null		default(0)
)
create nonclustered index Ind_ObjInfoTbl$_Id on ObjInfoTbl$(uid, ObjId)
go





print 'creating table Sync$'
create table [Sync$]
(
	[Id] int primary key clustered identity(1,1),
	[LpInfoId] uniqueidentifier null,
	[Msg] int null,
	[ObjId] int null,
	[ObjFlid] int null
)
go















if object_id('ClearSyncTable$') is not null begin
	print 'removing proc ClearSyncTable$'
	drop proc [ClearSyncTable$]
end
go
print 'creating proc ClearSyncTable$'
go
create proc [ClearSyncTable$]
	@dbName nvarchar(4000)
as
	declare	@fIsNocountOn int

	-- check for the arbitrary case where the db name is null
	if @dbName is null return 0

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	if (not exists(select spid from master.dbo.sysprocesses sproc
		join master.dbo.sysdatabases sdb on sdb.dbid = sproc.dbid and name = @dbName
		where sproc.spid != @@spid))
		truncate table sync$

	select max(id) from sync$ 

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	return 0
go
















if object_id('StoreSyncRec$') is not null begin
	print 'removing proc StoreSyncRec$'
	drop proc [StoreSyncRec$]
end
go
print 'creating proc StoreSyncRec$'
go
create proc [StoreSyncRec$]
	@dbName nvarchar(4000),
	@uid uniqueidentifier,
	@msg int,
	@hvo int,
	@flid int
as
	declare	@fIsNocountOn int

	-- check for the arbitrary case where the db name is null
	if @dbName is null return 0

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	if (select count(distinct spid) from master.dbo.sysprocesses sproc
		join master.dbo.sysdatabases sdb on sdb.dbid = sproc.dbid and name = @dbName
		where sproc.spid != @@spid) > 0
		insert sync$ (LpInfoId, Msg, ObjId, ObjFlid)
		values (@uid, @msg, @hvo, @flid)
	
-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	return 0
go





















if object_id('SetObjList$') is not null begin
	print 'removing proc SetObjList$'
	drop proc [SetObjList$]
end
go
print 'creating proc SetObjList$'
go
create proc [SetObjList$]
	@ObjList varbinary(7900),
	@uid uniqueidentifier = null output, -- if null then a guid is generated, otherwise use the supplied value
	@Tbl tinyint = 1,
	@fLittleEndian tinyint = 1
as
	declare @nNumObjs int, @iCurrObj int
	declare	@fIsNocountOn int, @iTemp int
	declare @Err int

	-- check for the arbitrary case where the array of objects is null
	if @ObjList is null return 0

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	if @uid is null set @uid = newid()

	-- get the number of objects in the destination object array
	set @nNumObjs = datalength(@ObjList) / 4

	set @iCurrObj = 0
	if @Tbl = 1 begin
		-- loop through the array of objects and insert each one into the ObjListTbl$ table
		if @fLittleEndian = 1 begin
			while @iCurrObj < @nNumObjs begin
				set @iTemp = @iCurrObj * 4
				insert into [ObjListTbl$] with (rowlock) ([uid], [ObjId], [Ord]) 
				values(@uid, substring(@ObjList, @iTemp + 4, 1) +
					substring(@ObjList, @iTemp + 3, 1) +
					substring(@ObjList, @iTemp + 2, 1) +
					substring(@ObjList, @iTemp + 1, 1), @iCurrObj)
				set @Err = @@error
				if @Err <> 0 goto LFail
				set @iCurrObj = @iCurrObj + 1
			end
		end
		else begin
			while @iCurrObj < @nNumObjs begin
				insert into [ObjListTbl$] with (rowlock) ([uid], [ObjId], [Ord]) 
					values(@uid, substring(@ObjList, @iCurrObj*4+1, 4), @iCurrObj)
				set @Err = @@error
				if @Err <> 0 goto LFail
				set @iCurrObj = @iCurrObj + 1
			end
		end
	end 
	else begin
		-- loop through the array of objects and insert each one into the ObjInfoTbl$ table
		if @fLittleEndian = 1 begin
			while @iCurrObj < @nNumObjs begin
				set @iTemp = @iCurrObj * 4
				insert into [ObjInfoTbl$] with (rowlock) ([uid], [ObjId], [OrdKey]) values(@uid, 
					substring(@ObjList, @iTemp + 4, 1) +
					substring(@ObjList, @iTemp + 3, 1) +
					substring(@ObjList, @iTemp + 2, 1) +
					substring(@ObjList, @iTemp + 1, 1), @iCurrObj)
				set @Err = @@error
				if @Err <> 0 goto LFail
				set @iCurrObj = @iCurrObj + 1
			end
		end
		else begin
			while @iCurrObj < @nNumObjs begin
				insert into [ObjInfoTbl$] with (rowlock) ([uid], [ObjId], [OrdKey]) 
					values(@uid, substring(@ObjList, @iCurrObj*4+1, 4), @iCurrObj)
				set @Err = @@error
				if @Err <> 0 goto LFail
				set @iCurrObj = @iCurrObj + 1
			end
		end
	end

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	return 0

LFail:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	raiserror ('SetObjList$: SQL Error %d; Unable to insert rows into the ObjListTbl$.', 16, 1, @Err)
	return @Err
go














if object_id('CleanObjListTbl$') is not null begin
	print 'removing proc CleanObjListTbl$'
	drop proc [CleanObjListTbl$]
end
go
print 'creating proc CleanObjListTbl$'
go
create proc [CleanObjListTbl$]
	@uid uniqueidentifier
as
	declare @fIsNocountOn int, @Err int, @sUid nvarchar(50)

	set @Err = 0

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- remove the specified rows from the ObjListTbl$ table
	delete	[ObjListTbl$] with (rowlock)
	where	[uid] = @uid

	set @Err = @@error
	if @Err <> 0 begin
		set @sUid = convert(nvarchar(50), @Uid)
		raiserror ('CleanObjListTbl$: SQL Error %d; Unable to remove rows from the ObjInfoTbl$ table (UID=%s).', 16, 1, @Err, @sUid)
	end

	if @fIsNocountOn = 0 set nocount off

	return @Err
go


-- ObjInfoTbl$_Owned view.
if object_id('ObjInfoTbl$_Owned') is not null begin
	print 'removing view ObjInfoTbl$_Owned'
	drop view [ObjInfoTbl$_Owned]
end
go
print 'creating view ObjInfoTbl$_Owned'
go
create view [ObjInfoTbl$_Owned]
as
	select	* 
	from	ObjInfoTbl$ 
	where	[RelType] in (23, 25, 27)
go


-- ObjInfoTbl$_Ref view.
if object_id('ObjInfoTbl$_Ref') is not null begin
	print 'removing view ObjInfoTbl$_Ref'
	drop view [ObjInfoTbl$_Ref]
end
go
print 'creating view ObjInfoTbl$_Ref'
go
create view [ObjInfoTbl$_Ref]
as
	select	* 
	from	ObjInfoTbl$ 
	where	[RelType] in (24, 26, 28)

go















if object_id('CleanObjInfoTbl$') is not null begin
	print 'removing proc CleanObjInfoTbl$'
	drop proc [CleanObjInfoTbl$]
end
go
print 'creating proc CleanObjInfoTbl$'
go
create proc [CleanObjInfoTbl$]
	@uid uniqueidentifier
as
	declare @fIsNocountOn int, @Err int, @sUid nvarchar(50)

	set @Err = 0

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- remove the specified rows from the ObjInfoTbl$ table
	delete	[ObjInfoTbl$] with (rowlock)
	where	[uid] = @uid

	set @Err = @@error
	if @Err <> 0 begin
		set @sUid = convert(nvarchar(50), @Uid)
		raiserror ('CleanObjInfoTbl$: SQL Error %d; Unable to remove rows from the ObjInfoTbl$ table (UID=%s).', 16, 1, @Err, @sUid)
	end

	if @fIsNocountOn = 0 set nocount off

	return @Err
go























if object_id('TR_Class$_Ins') is not null begin
	print 'removing trigger TR_Class$_Ins'
	drop trigger [TR_Class$_Ins]
end
go
print 'creating trigger TR_Class$_Ins'
go
create trigger [TR_Class$_Ins] on [Class$] for insert 
as
	declare @clid int, @clidBase int, @depth int, @clidT int, @clidBaseT int
	declare @sName sysname, @sBase sysname
	declare @Abstract bit
	declare @sql varchar(4000)
	declare @fIsNocountOn int
	declare @Err int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	select	top 1 	
		@clid = [Id], 
		@clidBase = [Base], 
		@sName = [Name],
		@Abstract = [Abstract]
	from	inserted 
	order by [Id]

	set @clidBaseT = @clidBase
	while @@rowcount > 0 begin
		-- Fill in ClassPar$
		insert into [ClassPar$] ([Src], [Dst], [Depth]) 
			values(@clid, @clid, 0)
		if @@error <> 0 goto LFail

		set @depth = 1
		set @clidT = @clid
		while @clidBaseT <> @clidT begin
			insert into [ClassPar$] ([Src], [Dst], [Depth])
				values(@clid, @clidBaseT, @depth)
			if @@error <> 0 goto LFail

			set @clidT = @clidBaseT
			select	@clidBaseT = [Base] 
			from	[Class$] 
			where	[Id] = @clidT
			if @@rowcount = 0 break

			set @depth = @depth + 1
		end

		-- Create Database Model from Class$ entries (CmObject table pre-created)
		If @sName <> 'CmObject' Begin

			-- Create Table
			select	@sBase = [Name] 
			from	[Class$] 
			where	[id] = @clidBase

			set @sql = 'create table [' + @sName + '] ([id] int constraint [_PK_'
					+ @sName + '] primary key clustered'

			  -- CmObject foreign keys are handled through a trigger
			if @sBase <> 'CmObject' set @sql = @sql +  ', constraint [_FK_' 
					+ @sName + '_id] foreign key ([Id]) references [' + @sBase + '] ([Id])'

			set @sql = @sql + ')'
			exec (@sql)
			if @Err <> 0 Begin
				raiserror('TR_Class$_Ins: SQL Error %d; Failed to Create Table %s', 16, 1, @Err, @sName)
				goto LFail
			end

			-- Create Trigger
			set @sql = 'create trigger [TR_' + @sName + '_TStmp] on [' + @sName + '] for update' + char(13) +
				'as' + char(13) +
				'update	CmObject' + char(13) +
				'set 	UpdDttm = getdate()' + char(13) +
				'from 	CmObject co join inserted i on co.[Id] = i.[Id]'
			exec (@sql)
			set @Err = @@error
			if @Err <> 0 Begin
				raiserror('TR_Class$_Ins: SQL Error %d; Failed to Create Trigger for %s',16,1,@Err,@sName)
				goto LFail
			end
		end

		set @clidT = @clid
		select top 1 
			@clid = [Id], 
			@clidBase = [Base], 
			@sName = [Name] 
		from	inserted 
		where	[Id] > @clidT 
		order by [Id]
	end

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	return

LFail:
	rollback tran
	raiserror('TR_Class$_Ins Failed on class %s ', 16,1, @sName)
go






-- CmObject table.

if object_id('CmObject') is not null begin
	print 'removing table CmObject'
	drop table [CmObject]
end
go
print 'creating table CmObject'
create table [CmObject] (
	[Id] 		int 				primary key clustered identity(1,1),
	[Guid$] 	uniqueidentifier not null 	unique default newid(),
	[Class$] 	int 		not null	references [Class$] ([Id]),
	[Owner$] 	int 		null		references [CmObject] ([Id]),
	[OwnFlid$] 	int 		null		references [Field$] ([Id]),
	[OwnOrd$] 	int 		null,
	[UpdStmp] 	timestamp,
	[UpdDttm]	smalldatetime	not null	default getdate(),

	-- an object cannot be owned by itself and if an object has an owner an owning flid
	--	must be specified
	constraint [_CK_CmObject_Owner$] check
		(([Owner$] is not null or [OwnFlid$] is null) and
			([Owner$] <> [Id]))
)

-- TODO (SteveMiller): Take a good hard look at these indexes to see if they 
-- are really serving us the way they should.

create nonclustered index Ind_CmObject_Owner$_OwnFlid$_OwnOrd$ on [CmObject] ([Owner$], [OwnFlid$], [OwnOrd$])
go

--( The views make extensive use of OwnFlid$. Except the name, this comes from the Index Tuning Wizard:
CREATE NONCLUSTERED INDEX [Ind_CmObject_OwnFlid$_Id_Owner$_OwnOrd$] ON 
	[dbo].[CmObject] ([OwnFlid$] ASC, [Id] ASC, [Owner$] ASC, [OwnOrd$] ASC )
GO

CREATE INDEX Ind_CmObject_Id ON dbo.CmObject ([Id])
GO


if object_id('CmObject_') is not null begin
	print 'removing view CmObject_'
	drop view [CmObject_]
end
go
print 'creating view CmObject_'
go
create view [CmObject_] 
as 
	select	[CmObject].* 
	from	[CmObject]
go




























if object_id('TR_CmObject$_RI_Del') is not null begin
	print 'removing trigger TR_CmObject$_RI_Del'
	drop trigger TR_CmObject$_RI_Del
end
go
print 'creating trigger TR_CmObject$_RI_Del'
go
create trigger TR_CmObject$_RI_Del on CmObject for delete
as
	declare @sDynSql nvarchar(4000)
	declare @iCurDelClsId int
	declare @fIsNocountOn int
	declare @uid uniqueidentifier

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	--( 	The following query is against the "deleted" table. This table
	--( is poorly documented in SQL Server documentation, but as I recall, both
	--( Oracle and FoxPro have a similar concept. The rows marked as deleted are
	--( here. The query inserts them into a scratch table ObjListTbl$. This table
	--( isn't one of the temp tables, or a table variable, but a scratch table the
	--( authors set up. It's used here because dynamic SQL isn't able to see the
	--( deleted table.
	--(	    Note also the use of newid(). This generates a new, unique ID. However,
	--( it happens only once, not for the whole table. The reason for this, I think,
	--( is that another user might be using the same scratch table concurrently. The
	--( second user would have a different ID than the first user. This makes sure 
	--( each user is using their own rows in the same scratch table.
	
	-- copy the deleted rows into a the ObjListTbl table - this is necessary since the logical "deleted" 
	--	table is not in	the scope of the dynamic SQL
	set @uid = newid()	
	insert into [ObjListTbl$] ([Uid], [ObjId], [Ord], [Class])
	select	@uid, [Id], coalesce([OwnOrd$], -1), [Class$]
	from	deleted
	if @@error <> 0 begin
		raiserror('TR_CmObject$_RI_Del: Unable to copy the logical DELETED table to the ObjListTbl table', 16, 1)
		goto LFail
	end

	-- get the first class to process
	select	@iCurDelClsId = min([Class])
	from	[ObjListTbl$] (serializable)
	where	[uid] = @uid
	if @@error <> 0 begin
		raiserror('TR_CmObject$_RI_Del: Unable to get the first deleted class', 16, 1)
		goto LFail
	end

	-- loop through all of the classes in the deleted logical table
	while @iCurDelClsId is not null begin

		--(    In SQL Server, you can set a variable with a SELECT statement,
		--( as long as the query returns a single row. In this case, the code
		--( queries the Class$ table on the Class.ID, to return the name of the
		--( class.  The name of the Class is concatenated into a string.
		--(    In this system, remember: 1) Each class is mapped to a table, 
		--( whether it is an abstract or concrete class.  2) Each class is
		--( subclassed from CmObject. 3) The data in an object will therefore
		--( be persisted in more than one table: CmObject, and at least one table
		--( mapped to a subclass. This is foundational to understanding this database.
		--(    The query in the dynamic SQL joins the data in the scatch table, which
		--( came from the deleted table, which originally came from CmObject--we are
		--( in the CmObject trigger. The join is on the object ID. So this is checking
		--( to see if some of some of the object's data is still in one of the subclass
		--( tables. If so, it rolls back the transaction and raises an error. In this
		--( system, you must remove the object's persisted data in the subclass(es)
		--( before removing the persisted data in CmObject. 

		-- REVIEW (SteveMiller): Is it necessary to make sure the data in the subclass
		-- tables is removed before removing the persisted data in the CmObject table?
		-- The presence of this	check makes referential integrity very tight. However,
		-- it comes at the cost of performance. We may want to return to this if we ever
		-- need some speed in the object deletion process. If nothing else, the dynamic
		-- SQL can be converted into a EXEC sp_executesql command, which is more efficient.

		select	@sDynSql = 
			'if exists ( ' +
				'select * ' +
				'from ObjListTbl$ del  join ' + [name] + ' c ' +
					'on del.[ObjId] = c.[Id] and del.[Class] = ' + convert(nvarchar(11), @iCurDelClsId) +
				'where del.[uid] = ''' + convert(varchar(255), @uid) + ''' ' +
			') begin ' +
				'raiserror(''Delete in CmObject violated referential integrity with %s'', 16, 1, ''' + [name] + ''') ' +
				'exec CleanObjListTbl$ ''' + convert(varchar(255), @uid) + ''' ' +
				'rollback tran ' +
			'end '
		from	[Class$]
		where	[Id] = @iCurDelClsId

		exec (@sDynSql)
		if @@error <> 0 begin
			raiserror('TR_CmObject$_RI_Del: Unable to execute dynamic SQL', 16, 1)
			goto LFail
		end

		-- get the next class to process
		select	@iCurDelClsId = min([Class])
		from	[ObjListTbl$] (serializable)
		where	[Class] > @iCurDelClsId
			and [uid] = @uid
	end

	exec CleanObjListTbl$ @uid
	
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return

LFail:
	-- because the transaction is ROLLBACKed the rows in the ObjListTbl$ will be removed
	rollback tran
	return
go







 
if object_id('TR_CmObject$_UpdDttm_Del') is not null begin
	print 'removing trigger TR_CmObject$_UpdDttm_Del'
	drop trigger TR_CmObject$_UpdDttm_Del
end
go
print 'creating trigger TR_CmObject$_UpdDttm_Del'
go
create trigger TR_CmObject$_UpdDttm_Del on CmObject for delete
as
	declare @fIsNocountOn int
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on
	
	update CmObject set UpdDttm = getdate()
		from CmObject co JOIN deleted del on co.[id] = del.[owner$] 
		
	if @@error <> 0 begin
		raiserror('TR_CmObject$_UpdDttm_Del: Unable to update owning object', 16, 1)
		goto LFail
	end
	
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return
	
LFail:
	-- because the transaction is ROLLBACKed the rows in the ObjListTbl$ will be removed
	rollback tran
	return
go























if object_id('TR_CmObject_ValidateOwner') is not null begin
	print 'removing trigger TR_CmObject_ValidateOwner'
	drop trigger [TR_CmObject_ValidateOwner]
end
go
print 'creating trigger TR_CmObject_ValidateOwner'
go
create trigger [TR_CmObject_ValidateOwner] on [CmObject] for update 
as
	-- make sure the Class$ has not been changed
	if update([Class$]) begin
		raiserror('An object''s class cannot be changed', 16, 1)
		rollback tran
	end

	if update([Id]) begin
		raiserror('An object''s Id cannot be changed', 16, 1)
		rollback tran
	end

	-- only perform checks if one of the following columns are updated: id, class$, owner$, ownflid$, or 
	--	ownord$	because updates to UpdDttm or UpdStmp do not require the below validations
	if not ( update([Owner$]) or update([OwnFlid$]) or update([OwnOrd$]) )  return

	declare @idBad int, @own int, @flid int, @ord int, @cnt int
	declare @dupownId int, @dupseqId int
	declare @fIsNocountOn int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	if update([Owner$]) or update([OwnFlid$]) or update([OwnOrd$]) begin
		-- Get the owner's class and make sure it is a subclass of the field's type. Get the 
		--	inserted object's class and make sure it is a subclass of the field's dst type.
		-- 	Make sure the OwnOrd$ field is consistent with the field type (if not sequence 
		--	then it should be null). Make sure more than one object is not added as a child 
		--	of an object with an atomic owning relationship. Make sure there are no duplicate
		--	Ord values within a sequence
		select top 1
			@idBad = ins.[Id],
			@own = ins.[Owner$],
			@flid = ins.[OwnFlid$],
			@ord = ins.[OwnOrd$],
			@dupownId = dupown.[Id],
			@dupseqId = dupseq.[Id]
		from	inserted ins
			-- If there is no owner, there is nothing to check so an inner join is OK here.
			join [CmObject] own  on own.[Id] = ins.[Owner$]
			-- The constraints on CmObject guarantee this join.
			join [Field$] fld on fld.[Id] = ins.[OwnFlid$]
			-- If this join has no matches the owner is of the wrong type.
			left outer join [ClassPar$] ot on ot.[Src] = own.[Class$] 
				and ot.[Dst] = fld.[Class]
			-- If this join has no matches the inserted object is of the wrong type.
			left outer join [ClassPar$] it on it.[Src] = ins.[Class$] 
				and it.[Dst] = fld.[DstCls]
			-- if this join has matches there is more than one owned object in an atomic relationship
			left outer join [CmObject] dupown  on fld.[Type] = 23 and dupown.[Owner$] = ins.[Owner$] 
				and dupown.[OwnFlid$] = ins.[OwnFlid$] 
				and dupown.[Id] <> ins.[Id]
			-- if this join has matches there is a duplicate sequence order in a sequence relationship
			left outer join [CmObject] dupseq  on fld.[Type] = 27 and dupseq.[Owner$] = ins.[Owner$] 
				and dupseq.[OwnFlid$] = ins.[OwnFlid$] 
				and dupseq.[OwnOrd$] = ins.[OwnOrd$] 
				and dupseq.[Id] <> ins.[Id]
		where
			ot.[Src] is null
			or it.[Src] is null
			or (fld.[Type] = 23 and ins.[OwnOrd$] is not null)
			or (fld.[Type] = 25 and ins.[OwnOrd$] is not null)
			or (fld.[Type] = 27 and ins.[OwnOrd$] is null)
			or dupown.[Id] is not null
			or dupseq.[Id] is not null

		if @@rowcount <> 0 begin
			if @dupownId is not null begin
				raiserror('More than one owned object in an atomic relationship: New ID=%d, Owner=%d, OwnFlid=%d, Already Owned Id=%d', 16, 1,
						@idBad, @own, @flid, @dupownId)
			end
			else if @dupseqId is not null begin
				raiserror('Duplicate OwnOrd in a sequence relationship: New ID=%d, Owner=%d, OwnFlid=%d, OwnOrd=%d, Duplicate Id=%d', 16, 1,
						@idBad, @own, @flid, @ord, @dupseqId)
			end
			else begin
				raiserror('Bad owner information ID=%d, Owner$=%d, OwnFlid$=%d, OwnOrd$=%d', 16, 1, @idBad, @own, @flid, @ord)
			end
			rollback tran
		end
	end

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
go





--( The Txt field is collated to Latin1_General_BIN because Yi,
--( IPA, and Khmer at least are not in the Microsoft collation
--( tables currently. This makes equality tests fail. We have
--( discovered however that they equate correctly in binary
--( collations. How this effects sorting is yet to be seen, and
--( we are talking about ways to fix that.

-- MultiStr$ table.
if object_id('MultiStr$') is not null begin
	print 'removing table MultiStr$'
	drop table [MultiStr$]
end
go
print 'creating table MultiStr$'
create table [MultiStr$] (
	[Flid]		int		not null	references [Field$] ([Id]),
	[Obj] 		int		not null,
	[Ws]		int		not null,
	[Txt] 		nvarchar(4000) COLLATE Latin1_General_BIN not null,
	[Fmt] 		varbinary(8000)	not null,

	constraint [_PK_MultiStr$] primary key clustered ([Flid], [Obj], [Ws])
)
create nonclustered index Ind_MultiStr$ on MultiStr$(obj)
go


--( The section for creating the MultiTxt$ table used to go here.
--( It has since been moved to TR_Field$_UpdateModel_Ins

-- MultiBigStr$ table.
if object_id('MultiBigStr$') is not null begin
	print 'removing table MultiBigStr$'
	drop table [MultiBigStr$]
end
go
print 'creating table MultiBigStr$'
create table [MultiBigStr$] (
	[Flid]		int		not null	references [Field$] ([Id]),
	[Obj]		int		not null,
	[Ws]		int		not null,
	[Txt] 		ntext		COLLATE Latin1_General_BIN not null,
	[Fmt] 		image		not null,

	constraint [_PK_MultiBigStr$] primary key clustered ([Flid], [Obj], [Ws])
)
create nonclustered index Ind_MultiBigStr$ on MultiBigStr$(obj)
go

-- Set 'Text In Row' option for MultiBigStr$.
exec sp_tableoption 'MultiBigStr$', 'text in row', '4000'
go


-- MultiBigTxt$ table.
if object_id('MultiBigTxt$') is not null begin
	print 'removing table MultiBigTxt$'
	drop table [MultiBigTxt$]
end
go
print 'creating table MultiBigTxt$'
create table [MultiBigTxt$] (
	[Flid]		int		not null	references [Field$] ([Id]),
	[Obj]		int		not null,
	[Ws]		int		not null,
	[Txt]		ntext		COLLATE Latin1_General_BIN not null,

	constraint [_PK_MultiBigTxt$] primary key clustered ([Flid], [Obj], [Ws])
)
create nonclustered index Ind_MultiBigTxt$ on MultiBigTxt$(obj)
go

-- Set 'Text In Row' option for MultiBigTxt$.
exec sp_tableoption 'MultiBigTxt$', 'text in row', '4000'
go























if object_id('SetMultiStr$') is not null begin
	print 'removing proc SetMultiStr$'
	drop proc [SetMultiStr$]
end
go
print 'creating proc SetMultiStr$'
go
create proc [SetMultiStr$]
	@flid int,
	@obj int,
	@ws int,
	@txt nvarchar(4000) = null,
	@fmt varbinary(8000) = null
as
	declare @sTranName varchar(50), @nTrnCnt int
	declare	@fIsNocountOn int, @Err int
	declare @nRowCnt int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- determine if a transaction already exists; if one does then create a savepoint, 
	--	otherwise create a transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'SetMultiStr$_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName

	-- determine if the string should be removed
	if @txt is null or len(@txt) = 0 begin
		delete from MultiStr$ 
		where	[Flid] = @flid 
			and [Obj] = @obj 
			and [Ws] = @ws
		set @Err = @@error
		if @Err <> 0 goto LCleanUp
	end
	else begin
		-- attempt to update the string, if no rows are updated then insert the string
		update	MultiStr$ 
		set	[Txt] = @txt, [Fmt] = @fmt 
		where	[Flid] = @flid 
			and [Obj] = @obj 
			and [Ws] = @ws
		select @Err = @@error, @nRowCnt = @@rowcount
		if @Err <> 0 goto LCleanUp
		if @nRowCnt = 0  begin
			insert into [MultiStr$] ([Flid], [Obj], [Ws], [Txt], [Fmt]) 
				values(@flid, @obj, @ws, @txt, @fmt)
			set @Err = @@error
			if @Err <> 0 goto LCleanUp
		end
	end

	-- update the timestamp column in CmObject by updating the update date and time
	update	[CmObject]
	set	[UpdDttm] = getdate()
	where	[Id] = @obj
	set @Err = @@error
	if @Err <> 0 goto LCleanUp

LCleanUp:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	if @Err = 0 begin
		-- if a transaction was created within this procedure commit it
		if @nTrnCnt = 0 commit tran @sTranName 
	end
	else begin
		rollback tran @sTranName 
	end

	return @err
go

















if object_id('SetMultiTxt$') is not null begin
	print 'removing procedure SetMultiTxt$'
	drop proc [SetMultiTxt$]
end
go
print 'creating proc SetMultiTxt$'
go
create proc [SetMultiTxt$]
	@flid int,
	@obj int,
	@ws int,
	@txt nvarchar(4000)
as
	declare @sTranName varchar(50), @nTrnCnt int
	declare	@fIsNocountOn int, @Err int
	declare @nRowCnt int
	DECLARE
		@nvcTable NVARCHAR(40),
		@nvcSql NVARCHAR(4000)

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- determine if a transaction already exists; if one does then create a savepoint, 
	--	otherwise create a transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'SetMultiTxt$_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName
	
	EXEC GetMultiTableName @flid, @nvcTable OUTPUT
	
	-- determine if the string should be removed
	if @txt is null or len(@txt) = 0 begin
		SET @nvcSql = N'DELETE FROM ' + @nvcTable + CHAR(13) +
			N'WHERE Obj = @nObj AND Ws = @nWs'
		
		EXECUTE sp_executesql @nvcSql, N'@nObj INT, @nWs INT', @obj, @ws
		set @Err = @@error
		if @Err <> 0 goto LCleanUp
	end
	else begin
		-- attempt to update the string, if no rows are updated then insert the string
		SET @nvcSql = 
			N'UPDATE ' + @nvcTable + CHAR(13) +
			N'SET Txt = @nvcTxt ' + CHAR(13) +
			N'WHERE Obj = @nObj AND Ws = @nWs'
		EXECUTE sp_executesql @nvcSql,
			N'@nvcTxt NVARCHAR(4000), @nObj INT, @nWs INT',
			@txt, @obj, @ws
		
		select @Err = @@error, @nRowCnt = @@rowcount
		if @Err <> 0
			goto LCleanUp
		
		if @nRowCnt = 0 begin
			SET @nvcSql = 
				N'INSERT INTO ' + @nvcTable + 
				N' (Obj, Ws, Txt)' + CHAR(13) +
				CHAR(9) + N'VALUES (@nObj, @nWs, @nvcTxt)'
			EXECUTE sp_executesql @nvcSQL,
				N'@nvcTxt NVARCHAR(4000), @nObj INT, @nWs INT',
				@txt, @obj, @ws
			set @Err = @@error
			if @Err <> 0 goto LCleanUp
		end
	end
	
	-- update the timestamp column in CmObject by updating the update date and time
	update	[CmObject]
	set	[UpdDttm] = getdate()
	where	[Id] = @obj
	set @Err = @@error
	if @Err <> 0 goto LCleanUp

LCleanUp:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	if @Err = 0 begin
		-- if a transaction was created within this procedure commit it
		if @nTrnCnt = 0 commit tran @sTranName 
	end
	else begin
		rollback tran @sTranName 
	end

	return @err
go


















if object_id('SetMultiBigStr$') is not null begin
	print 'removing proc SetMultiBigStr$'
	drop proc [SetMultiBigStr$]
end
go
print 'creating proc SetMultiBigStr$'
go
create proc [SetMultiBigStr$]
	@flid int,
	@obj int,
	@ws int,
	@txt ntext,
	@fmt image
as
	declare @sTranName varchar(50), @nTrnCnt int
	declare	@fIsNocountOn int, @Err int
	declare @nRowCnt int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- determine if a transaction already exists; if one does then create a savepoint, 
	--	otherwise create a transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'SetMultiBigStr$_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName

	-- determine if the string should be removed
	if @txt is null or @txt like '' begin
		delete from MultiBigStr$ 
		where	[Flid] = @flid 
			and [Obj] = @obj 
			and [Ws] = @ws
		set @Err = @@error
		if @Err <> 0 goto LCleanUp
	end
	else begin
		-- attempt to update the string, if no rows are updated then insert the string
		update	MultiBigStr$
		set	[Txt] = @txt, [Fmt] = @fmt 
		where	[Flid] = @flid 
			and [Obj] = @obj 
			and [Ws] = @ws
		select @Err = @@error, @nRowCnt = @@rowcount
		if @Err <> 0 goto LCleanUp
		if @nRowCnt = 0 begin
			insert into [MultiBigStr$] ([Flid], [Obj], [Ws], [Txt], [Fmt]) 
				values(@flid, @obj, @ws, @txt, @fmt)
			set @Err = @@error
			if @Err <> 0 goto LCleanUp
		end
	end

	-- update the timestamp column in CmObject by updating the update date and time
	update	[CmObject]
	set	[UpdDttm] = getdate()
	where	[Id] = @obj
	set @Err = @@error
	if @Err <> 0 goto LCleanUp

LCleanUp:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	if @Err = 0 begin
		-- if a transaction was created within this procedure commit it
		if @nTrnCnt = 0 commit tran @sTranName 
	end
	else begin
		rollback tran @sTranName 
	end

	return @err
go

















if object_id('SetMultiBigTxt$') is not null begin
	print 'removing proc SetMultiBigTxt$'
	drop proc [SetMultiBigTxt$]
end
go
print 'creating proc SetMultiBigTxt$'
go
create proc [SetMultiBigTxt$]
	@flid int,
	@obj int,
	@ws int,
	@txt ntext
as
	declare @sTranName varchar(50), @nTrnCnt int
	declare	@fIsNocountOn int, @Err int
	declare @nRowCnt int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- determine if a transaction already exists; if one does then create a savepoint, 
	--	otherwise create a transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'SetMultiBigStr$_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName

	-- determine if the string should be removed
	if @txt is null or @txt like '' begin
		delete from MultiBigTxt$ 
		where	[Flid] = @flid 
			and [Obj] = @obj 
			and [Ws] = @ws
		set @Err = @@error
		if @Err <> 0 goto LCleanUp
	end
	else begin
		-- attempt to update the string, if no rows are updated then insert the string
		update	MultiBigTxt$ 
		set	[Txt] = @txt 
		where	[Flid] = @flid 
			and [Obj] = @obj 
			and [Ws] = @ws
		select @Err = @@error, @nRowCnt = @@rowcount
		if @Err <> 0 goto LCleanUp
		if @nRowCnt = 0 begin
			insert into [MultiBigTxt$] ([Flid], [Obj], [Ws], [Txt]) 
				values(@flid, @obj, @ws, @txt)
			set @Err = @@error
			if @Err <> 0 goto LCleanUp
		end
	end

	-- update the timestamp column in CmObject by updating the update date and time
	update	[CmObject]
	set	[UpdDttm] = getdate()
	where	[Id] = @obj
	set @Err = @@error
	if @Err <> 0 goto LCleanUp

LCleanUp:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	if @Err = 0 begin
		-- if a transaction was created within this procedure commit it
		if @nTrnCnt = 0 commit tran @sTranName 
	end
	else begin
		rollback tran @sTranName 
	end

	return @err
go

















if object_id('GetMultiTableName') is not null begin
	print 'removing proc GetMultiTableName'
	drop proc [GetMultiTableName]
end
go
print 'creating proc GetMultiTableName'
go

CREATE PROCEDURE GetMultiTableName
 	@nFlid INT = NULL, 
	@nvcTableName NVARCHAR(60) OUTPUT
AS
 	SELECT @nvcTableName = c.[Name] + '_' + f.[Name]
 	FROM Class$ c
 	JOIN Field$ f ON f.Class = c.[Id] AND f.[Id] = @nFlid
GO















if object_id('MergeWritingSystem') is not null begin
	print 'removing proc MergeWritingSystem'
	drop proc [MergeWritingSystem]
end
go
print 'creating proc MergeWritingSystem'
go

CREATE PROCEDURE MergeWritingSystem
	@nOldWs INT,
	@nNewWs INT
AS
	DECLARE
		@nRowCount INT,
		@nFlid INT,
		@nvcTableName NVARCHAR(60),
		@nvcSql NVARCHAR(200)
	
	SET @nRowCount = 1
	SELECT TOP 1 @nFlid = [Id] FROM Field$ WHERE Type = 16 ORDER BY [Id]
	WHILE @nRowCount > 0 BEGIN
		EXEC GetMultiTableName @nFlid, @nvcTableName OUTPUT
		
		SET @nvcSql = N'UPDATE ' + @nvcTableName + CHAR(13) +
			N'SET Ws = @nNewWs WHERE Ws = @nOldWs'
		EXECUTE sp_executesql @nvcSql,
			N'@nNewWs INT, @nOldWs INT', @nNewWs, @nOldWs
	
		SELECT TOP 1 @nFlid = [Id]
		FROM Field$
		WHERE Type = 16 AND [Id] > @nFlid
		ORDER BY [Id]
		
		SET @nRowCount = @@ROWCOUNT
	END

	UPDATE MultiBigTxt$ SET Ws = @nNewWs WHERE Ws = @nOldWs
	UPDATE MultiStr$ SET Ws = @nNewWs WHERE Ws = @nOldWs
	UPDATE MultiBigStr$ SET Ws = @nNewWs WHERE Ws = @nOldWs
GO


















if object_id('xp_GetSortKey') is not null begin
	print 'removing proc xp_GetSortKey'
	drop proc [xp_GetSortKey]
end
go
print 'creating proc xp_GetSortKey'
go
CREATE PROCEDURE [xp_GetSortKey]
	@nvcText NVARCHAR(4000) OUTPUT,
	@nvcLocale NVARCHAR(100) OUTPUT,
	@nKey VARBINARY(900) OUTPUT
AS
	SET @nKey = ASCII(@nvcText) -- will take first character of @nvcText
GO













































if object_id('fnGetOwnedObjects$') is not null begin
	print 'removing function fnGetOwnedObjects$'
	drop function [fnGetOwnedObjects$]
end
go
print 'creating function fnGetOwnedObjects$'
go
create function [fnGetOwnedObjects$] (
	@ObjId int=null,
	@hXMLDocObjList int=null,
	@grfcpt int=528482304,
	@fBaseClasses tinyint=0,
	@fSubClasses tinyint=0,
	@fRecurse tinyint=1,
	@riid int=NULL,
	@fCalcOrdKey tinyint=1 )
returns @ObjInfo table (
	[ObjId]		int		not null,
	[ObjClass]	int		null,
	[InheritDepth]	int		null		default(0),
	[OwnerDepth]	int		null		default(0),
	[RelObjId]	int		null,
	[RelObjClass]	int		null,
	[RelObjField]	int		null,
	[RelOrder]	int		null,
	[RelType]	int		null,
	[OrdKey]	varbinary(250)	null		default(0)
)
as
begin
	declare @nRowCnt int
	declare	@nObjId int, @nInheritDepth int, @nOwnerDepth int, @sOrdKey varchar(250)

	-- if NULL was specified as the mask assume that all objects are desired
	if @grfcpt is null set @grfcpt = 528482304

	-- at least one and only one object must be specified somewhere - objId paramater or XML
	if @objId is null and @hXMLDocObjList is null goto LFail
	if @objId is not null and @hXMLDocObjList is not null goto LFail

	-- determine if an object was supplied as an argument, if one was not use ObjInfoTbl$ as the list of objects
	if @objId is not null begin 

		-- get the class of the specified object
		insert into @ObjInfo (ObjId, ObjClass, OrdKey)
		select	@objId, co.[Class$],
			-- calculate the order key even if @fCalcOrdKey = 0 because the overhead is very small here
			convert(varbinary, coalesce(co.[Owner$], 0)) + 
			convert(varbinary, coalesce(co.[OwnFlid$], 0)) +
			convert(varbinary, coalesce(co.[OwnOrd$], 0))
		from	[CmObject] co 
		where	co.[Id] = @objId
		if @@error <> 0 goto LFail
	end
	else begin

		-- parse the XML list of Object IDs and insert them into the table variable
		insert into @ObjInfo (ObjId, ObjClass, OrdKey)
		select	i.[Id], co.[Class$],
			-- calculate the order key even if @fCalcOrdKey = 0 because the overhead is very small here
			convert(varbinary, coalesce(co.[Owner$], 0)) + 
			convert(varbinary, coalesce(co.[OwnFlid$], 0)) +
			convert(varbinary, coalesce(co.[OwnOrd$], 0))
		from	openxml (@hXMLDocObjList, '/root/Obj') with ([Id] int) i
			join [CmObject] co  on co.[Id] = i.[Id]
		if @@error <> 0 goto LFail
	end

	set @nOwnerDepth = 1
	set @nRowCnt = 1
	while @nRowCnt > 0 begin	
		-- determine if the order key should be calculated - if the order key is not needed a more 
		--    effecient query can be used to generate the ownership tree
		if @fCalcOrdKey = 1 begin
			-- get the objects owned at the next depth and calculate the order key
			insert	into @ObjInfo
				(ObjId, ObjClass, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType, OrdKey)
			select 	co.[id], co.[Class$], @nOwnerDepth, co.[Owner$], f.[Class], co.[OwnFlid$], co.[OwnOrd$], f.[Type], 
				oi.OrdKey+convert(varbinary, co.[Owner$]) + convert(varbinary, co.[OwnFlid$]) + convert(varbinary, coalesce(co.[OwnOrd$], 0))
			from 	[CmObject] co 
					join @ObjInfo oi on co.[Owner$] = oi.[ObjId]
					join [Field$] f on f.[id] = co.[OwnFlid$]
			where 	oi.[OwnerDepth] = @nOwnerDepth - 1
				and ( 	( @grfcpt & 8388608 = 8388608 and f.[Type] = 23 )
					or ( @grfcpt & 33554432 = 33554432 and f.[Type] = 25 )
					or ( @grfcpt & 134217728 = 134217728 and f.[Type] = 27 )
				)
		end
		else begin
			-- get the objects owned at the next depth and do not calculate the order key
			insert	into @ObjInfo
				(ObjId, ObjClass, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType)
			select 	co.[id], co.[Class$], @nOwnerDepth, co.[Owner$], f.[Class], co.[OwnFlid$], co.[OwnOrd$], f.[Type]
			from 	[CmObject] co 
					join [Field$] f on f.[id] = co.[OwnFlid$]
			where 	exists (select 	*
					from 	@ObjInfo oi
					where 	oi.[ObjId] = co.[Owner$]
						and oi.[OwnerDepth] = @nOwnerDepth - 1
				)
				and ( 	( @grfcpt & 8388608 = 8388608 and f.[Type] = 23 )
					or ( @grfcpt & 33554432 = 33554432 and f.[Type] = 25 )
					or ( @grfcpt & 134217728 = 134217728 and f.[Type] = 27 )
				)
		end
 		set @nRowCnt=@@rowcount
 
 		-- determine if the whole owning tree should be included in the results
  		if @fRecurse = 0 break

 		set @nOwnerDepth = @nOwnerDepth + 1
 	end

	--
	-- get all of the base classes of the object(s)
	--
	if @fBaseClasses = 1 begin
		insert	into @ObjInfo
			(ObjId, ObjClass, InheritDepth, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType, OrdKey)
		select	oi.[ObjId], p.[Dst], p.[Depth], oi.[OwnerDepth], oi.[RelObjId], oi.[RelObjClass], oi.[RelObjField], oi.[RelOrder], oi.[RelType], oi.[OrdKey]
		from	@ObjInfo oi
				join [ClassPar$] p on oi.[ObjClass] = p.[Src]
				join [Class$] c on c.[id] = p.[Dst]
		where	p.[Depth] > 0 
			and p.[Dst] <> 0
		if @@error <> 0 goto LFail
	end
	--
	-- get all of the sub classes of the object(s)
	--
	if @fSubClasses = 1 begin
		insert	into @ObjInfo
			(ObjId, ObjClass, InheritDepth, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType, OrdKey)
		select	oi.[ObjId], p.[Src], -p.[Depth], oi.[OwnerDepth], oi.[RelObjId], oi.[RelObjClass], oi.[RelObjField], oi.[RelOrder], oi.[RelType], oi.[OrdKey]
		from	@ObjInfo oi
				join [ClassPar$] p on oi.[ObjClass] = p.[Dst] and InheritDepth = 0
				join [Class$] c on c.[id] = p.[Dst]
		where	p.[Depth] > 0 
			and p.[Dst] <> 0
		if @@error <> 0 goto LFail
	end

	-- if a class was specified remove the owned objects that are not of that type of class; these objects were
	--    necessary in order to get a list of all of the referenced and referencing objects that were potentially 
	--    the type of specified class
	if @riid is not null begin
		delete	@ObjInfo
		where 	not exists (
				select	*
				from	[ClassPar$] cp
				where	cp.[Dst] = @riid
					and cp.[Src] = [ObjClass]
			)
		if @@error <> 0 goto LFail
	end

	return
LFail:
	
	delete from @ObjInfo
	return
end
go



































































































if object_id('GetLinkedObjs$') is not null begin
	print 'removing proc GetLinkedObjs$'
	drop proc [GetLinkedObjs$]
end
go
print 'creating proc GetLinkedObjs$'
go

create proc [GetLinkedObjs$]
	@ObjId int=null,
	@hXMLDocObjList int=null,
	@grfcpt int=528482304,
	@fBaseClasses bit=0,
	@fSubClasses bit=0,
	@fRecurse bit=1,
	@nRefDirection smallint=0,
	@riid int=null,
	@fCalcOrdKey bit=1
as
	declare @Err int, @nRowCnt int
	declare	@sQry nvarchar(1000), @sUid nvarchar(50)
	declare	@nObjId int, @nObjClass int, @nInheritDepth int, @nOwnerDepth int, @nClass int, @nField int, 
		@nRelOrder int, @nType int, @nDirection int, @sClass sysname, @sField sysname, 
		@sOrderField sysname, @sOrdKey varchar(250)
	declare	@fIsNocountOn int

	set @Err = 0

	CREATE TABLE [#OwnedObjsInfo$](
		[ObjId]		INT NOT NULL,
		[ObjClass]	INT NULL,
		[InheritDepth]	INT NULL DEFAULT(0),
		[OwnerDepth]	INT NULL DEFAULT(0),
		[RelObjId]	INT NULL,
		[RelObjClass]	INT NULL,
		[RelObjField]	INT NULL,
		[RelOrder]	INT NULL,
		[RelType]	INT NULL,
		[OrdKey]	VARBINARY(250) NULL DEFAULT(0))
	
	CREATE NONCLUSTERED INDEX #OwnedObjsInfoObjId ON #OwnedObjsInfo$ ([ObjId])
	
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on
	
	-- if null was specified as the mask assume that all objects are desired
	if @grfcpt is null set @grfcpt = 528482304
	
	-- make sure objects were specified either in the XML or through the @ObjId parameter
	if ( @ObjId is null and @hXMLDocObjList is null ) or ( @ObjId is not null and @hXMLDocObjList is not null )
		goto LFail

	-- get the owned objects
	IF (176160768) & @grfcpt > 0 --( mask = owned obects
		INSERT INTO [#OwnedObjsInfo$]
			SELECT * FROM dbo.fnGetOwnedObjects$(
				@ObjId,
				@hXMLDocObjList,
				@grfcpt,
				@fBaseClasses,
				@fSubClasses,
				@fRecurse,
				@riid,
				@fCalcOrdKey)
	ELSE --( mask = referenced items or all: get all owned objects
		INSERT INTO [#OwnedObjsInfo$]
			SELECT * FROM dbo.fnGetOwnedObjects$(
				@ObjId,
				@hXMLDocObjList,
				528482304,
				@fBaseClasses,
				@fSubClasses,
				@fRecurse,
				@riid,
				@fCalcOrdKey)
	
	IF NOT (352321536) & @grfcpt > 0 --( mask = not referenced. In other words, mask is owned or all
		INSERT INTO [#ObjInfoTbl$]
			SELECT * FROM [#OwnedObjsInfo$]
	
	-- determine if any references should be included in the results
	if (352321536) & @grfcpt > 0 begin
	
		--
		-- get a list of all of the classes that reference each class associated with the specified object 
		--	and a list of the classes that each associated class reference, then loop through them to 
		--	get all of the objects that participate in the references
		--

		-- determine which reference direction should be included
		if @nRefDirection = 0 begin
			declare GetClassRefObj_cur cursor local static forward_only read_only for
			-- get the classes that reference (atomic, sequences, and collections) this class
			select 	oi.[ObjId], oi.[ObjClass], oi.[InheritDepth], oi.[OwnerDepth], f.[Type], c.[Name], c.[Id], f.[Name], f.[Id],
				1, -- references this class
				master.dbo.fn_varbintohexstr(oi.[OrdKey])
			from 	#OwnedObjsInfo$ oi
					join [Field$] f on f.[DstCls] = oi.[ObjClass] 
						and ( 	( f.[type] = 24 and @grfcpt & 16777216 = 16777216 )
							or ( f.[type] = 26 and @grfcpt & 67108864 = 67108864 )
							or ( f.[type] = 28 and @grfcpt & 268435456 = 268435456 )
						)
					join [Class$] c on f.[Class] = c.[Id]
			union all
			-- get the classes that are referenced (atomic, sequences, and collections) by this class
			select	oi.[ObjId], oi.[ObjClass], oi.[InheritDepth], oi.[OwnerDepth], f.[Type], c.[Name], f.[DstCls], f.[Name], f.[Id],
				2, -- referenced by this class
				master.dbo.fn_varbintohexstr(oi.[OrdKey])
			from	#OwnedObjsInfo$ oi 
					join [Class$] c on c.[Id] = oi.[ObjClass]
					join [Field$] f on f.[Class] = c.[Id] 
						and ( 	( f.[type] = 24 and @grfcpt & 16777216 = 16777216 )
							or ( f.[type] = 26 and @grfcpt & 67108864 = 67108864 )
							or ( f.[type] = 28 and @grfcpt & 268435456 = 268435456 )
						)
			order by oi.[ObjId]
		end
		else if @nRefDirection = 1 begin
			declare GetClassRefObj_cur cursor local static forward_only read_only for
			-- get the classes that are referenced (atomic, sequences, and collections) by these classes
			select	oi.[ObjId], oi.[ObjClass], oi.[InheritDepth], oi.[OwnerDepth], f.[Type], c.[Name], f.[DstCls], f.[Name], f.[Id],
				2, -- referenced by this class
				master.dbo.fn_varbintohexstr(oi.[OrdKey])
			from	#OwnedObjsInfo$ oi
					join [Class$] c on c.[Id] = oi.[ObjClass]
					join [Field$] f on f.[Class] = c.[Id] 
						and ( 	( f.[type] = 24 and @grfcpt & 16777216 = 16777216 )
							or ( f.[type] = 26 and @grfcpt & 67108864 = 67108864 )
							or ( f.[type] = 28 and @grfcpt & 268435456 = 268435456 )
						)
			order by oi.[ObjId]
		end
		else begin
			declare GetClassRefObj_cur cursor local static forward_only read_only for
			-- get the classes that reference (atomic, sequences, and collections) these classes
			-- do not include internal references between objects within the owning object hierarchy;
			--	this will be handled below
			select 	oi.[ObjId], oi.[ObjClass], oi.[InheritDepth], oi.[OwnerDepth], f.[Type], c.[Name], c.[Id], f.[Name], f.[Id],
				1, -- references this class
				master.dbo.fn_varbintohexstr(oi.[OrdKey])
			from 	#OwnedObjsInfo$ oi
					join [Field$] f on f.[DstCls] = oi.[ObjClass] 
						and ( 	( f.[type] = 24 and @grfcpt & 16777216 = 16777216 )
							or ( f.[type] = 26 and @grfcpt & 67108864 = 67108864 )
							or ( f.[type] = 28 and @grfcpt & 268435456 = 268435456 )
						)
					join [Class$] c on f.[Class] = c.[Id]
			order by oi.[ObjId]
		end

		open GetClassRefObj_cur
		fetch GetClassRefObj_cur into @nObjId, @nObjClass, @nInheritDepth, @nOwnerDepth, @nType, @sClass, @nClass, 
				@sField, @nField, @nDirection, @sOrdKey
		while @@fetch_status = 0 begin

			-- build the base part of the query
			set @sQry = 'insert into #ObjInfoTbl$ '+
					'(ObjId,ObjClass,InheritDepth,OwnerDepth,RelObjId,RelObjClass,RelObjField,RelOrder,RelType,OrdKey)' + char(13) +
					'select '

			-- determine if the reference is atomic
			if @nType = 24 begin
				-- determine if this class references an object's class within the object hierachy,
				--	and whether or not it should be included
				if @nDirection = 1 and (@nRefDirection = 0 or @nRefDirection = -1) begin 
					set @sQry=@sQry+convert(nvarchar(11), @nObjId)+','+convert(nvarchar(11), @nObjClass)+','+
							convert(nvarchar(11), @nInheritDepth)+','+convert(nvarchar(11), @nOwnerDepth)+','+
							't.[Id],'+convert(nvarchar(11), @nClass)+','+convert(nvarchar(11), @nField)+','+
							'NULL,'+convert(nvarchar(11), @nType)+',convert(varbinary,'''+@sOrdKey+''') '+
						'from ['+@sClass+'] t  '+
						'where ['+@sField+']='+convert(nvarchar(11),@nObjId)

					-- determine if only external references should be included - don't included
					--	references between objects within the owning hierarchy
					if @nRefDirection = -1 begin
						set @sQry = @sQry + 'and not exists (' +
								'select * from #OwnedObjsInfo$ oi ' +
								'where oi.[ObjId]=t.[Id] ' +
									'and oi.[RelType] not in (' +
									convert(nvarchar(11), 16777216)+',' +
									convert(nvarchar(11), 67108864)+',' +
									convert(nvarchar(11), 268435456)+'))'
					end
				end
				-- determine if this class is referenced by an object's class within the object hierachy,
				--	and whether or not it should be included
				else if @nDirection = 2 and (@nRefDirection = 0 or @nRefDirection = 1) begin
					set @sQry=@sQry+'['+@sField+'],'+
					 		convert(nvarchar(11), @nClass)+','+convert(nvarchar(11), @nInheritDepth)+','+
							convert(nvarchar(11), @nOwnerDepth)+','+convert(nvarchar(11), @nObjId)+','+
							convert(nvarchar(11), @nObjClass)+','+convert(nvarchar(11), @nField)+','+
							'NULL,'+convert(nvarchar(11), @nType)+',convert(varbinary,'''+@sOrdKey+''') '+
						'from ['+@sClass+']  ' +
						'where [id]='+convert(nvarchar(11),@nObjId)+' '+
							'and ['+@sField+'] is not null'
				end
			end
			else begin
				-- if the reference is ordered insert the order value, otherwise insert null
				if @nType = 28 set @sOrderField = '[Ord]'
				else set @sOrderField = 'NULL'

				-- determine if this class references an object's class and whether or not it should be
				--	included
				if @nDirection = 1 and (@nRefDirection = 0 or @nRefDirection = -1) begin 
					set @sQry=@sQry+convert(nvarchar(11), @nObjId)+','+convert(nvarchar(11), @nObjClass)+','+
							convert(nvarchar(11), @nInheritDepth)+','+convert(nvarchar(11), @nOwnerDepth)+','+
							't.[Src],'+convert(nvarchar(11), @nClass)+','+convert(nvarchar(11), @nField)+','+
							@sOrderField+','+convert(nvarchar(11), @nType)+',convert(varbinary,'''+@sOrdKey+''') '+
						'from ['+@sClass+'_'+@sField+'] t  '+
						'where t.[dst]='+convert(nvarchar(11),@nObjId)

					-- determine if only external references should be included - don't included
					--	references between objects within the owning hierarchy
					if @nRefDirection = -1 begin
						set @sQry = @sQry + 'and not exists (' +
								'select * from #OwnedObjsInfo$ oi ' +
								'where oi.[ObjId]=t.[Src] ' +
									'and oi.[RelType] not in (' +
									convert(nvarchar(11), 16777216)+',' +
									convert(nvarchar(11), 67108864)+',' +
									convert(nvarchar(11), 268435456)+'))'
					end
				end
				-- determine if this class is referenced by an object's class and whether or not it
				--	should be included
				else if @nDirection = 2 and (@nRefDirection = 0 or @nRefDirection = 1) begin
					set @sQry=@sQry+'[Dst],'+
							convert(nvarchar(11), @nClass)+','+convert(nvarchar(11), @nInheritDepth)+','+
							convert(nvarchar(11), @nOwnerDepth)+','+convert(nvarchar(11), @nObjId)+','+
							convert(nvarchar(11), @nObjClass)+','+convert(nvarchar(11), @nField)+','+
							@sOrderField+','+convert(nvarchar(11), @nType)+',convert(varbinary,'''+@sOrdKey+''') '+
						'from ['+@sClass+'_'+@sField+']  '+
						'where [src]='+convert(nvarchar(11),@nObjId)
				end
			end

			exec (@sQry)				
			set @Err = @@error
			if @Err <> 0 begin
				raiserror ('GetLinkedObjects$: SQL Error %d; Error performing dynamic SQL.', 16, 1, @Err)

				close GetClassRefObj_cur
				deallocate GetClassRefObj_cur

				goto LFail
			end

			fetch GetClassRefObj_cur into @nObjId, @nObjClass, @nInheritDepth, @nOwnerDepth, @nType, @sClass, 
					@nClass, @sField, @nField, @nDirection, @sOrdKey
		end

		close GetClassRefObj_cur
		deallocate GetClassRefObj_cur
	end

	-- if a class was specified remove the owned objects that are not of that type of class; these objects were
	--    necessary in order to get a list of all of the referenced and referencing objects that were potentially 
	--    the type of specified class
	if @riid is not null begin
		delete	#ObjInfoTbl$
		where 	not exists (
				select	*
				from	[ClassPar$] cp
				where	cp.[Dst] = @riid
					and cp.[Src] = [ObjClass]
			)
		set @Err = @@error
		if @Err <> 0 begin
			raiserror ('GetLinkedObjects$: SQL Error %d; Unable to remove objects that are not the specified class %d.', 16, 1, @Err, @riid)
			goto LFail
		end
	end

LFail:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @Err
go






























if object_id('GetLinkedObjects$') is not null begin
	print 'removing proc GetLinkedObjects$'
	drop proc [GetLinkedObjects$]
end
go
print 'creating proc GetLinkedObjects$'
go
create proc [GetLinkedObjects$]
	@uid uniqueidentifier output,
	@ObjId int=NULL,
	@grfcpt int=528482304,
	@fBaseClasses tinyint=0,
	@fSubClasses tinyint=0,
	@fRecurse tinyint=1,
	@nRefDirection smallint=0,
	@riid int=NULL,
	@fCalcOrdKey tinyint=1
as
	declare @Err int, @nRowCnt int
	declare	@sQry nvarchar(1000), @sUid nvarchar(50)
	declare	@nObjId int, @nObjClass int, @nInheritDepth int, @nOwnerDepth int, @nClass int, @nField int, 
		@nRelOrder int, @nType int, @nDirection int, @sClass sysname, @sField sysname, 
		@sOrderField sysname, @sOrdKey varchar(250)
	declare	@fIsNocountOn int

	set @Err = 0

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- if null was specified as the mask assume that all objects are desired
	if @grfcpt is null set @grfcpt = 528482304

	-- determine if an object was supplied as an argument, if one was not use ObjInfoTbl$ as the list of objects
	if @objId is not null begin 
		-- get a unique value to identify this invocation's results
		set @uid = newid()

		-- get the class of the specified object
		insert into [ObjInfoTbl$] with (rowlock) (uid, ObjId, ObjClass, OrdKey)
		select	@uid, @objId, co.[Class$],
			-- calculate the order key even if @fCalcOrdKey = 0 because the overhead is very small here
			convert(varbinary, coalesce(co.[Owner$], 0)) + 
			convert(varbinary, coalesce(co.[OwnFlid$], 0)) +
			convert(varbinary, coalesce(co.[OwnOrd$], 0))
		from	[CmObject] co 
		where	co.[Id] = @objId

		set @Err = @@error
		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('GetLinkedObjects$: SQL Error %d; Unable to insert the initial object into the ObjInfoTbl$ table (UID=%s).', 16, 1, @Err, @sUid)
			goto LFail
		end
	end
	else begin
		update	[ObjInfoTbl$] with (rowlock)
		set	[ObjClass]=co.[Class$], [OwnerDepth]=0, [InheritDepth]=0,
			-- calculate the order key even if @fCalcOrdKey = 0 because the overhead is very small here
			[OrdKey]=convert(varbinary, coalesce(co.[Owner$], 0)) + 
				convert(varbinary, coalesce(co.[OwnFlid$], 0)) +
				convert(varbinary, coalesce(co.[OwnOrd$], 0))
		from	[ObjInfoTbl$] oi 
				join [CmObject] co  on oi.[ObjId] = co.[Id]
		where	oi.[uid]=@uid
	end

	-- determine if the whole owning tree should be included in the results
	set @nOwnerDepth = 1
	set @nRowCnt = 1
	while @nRowCnt > 0
	begin	
		-- determine if the order key should be calculated - if the order key is not needed a more 
		--    effecient query can be used to generate the ownership tree
		if @fCalcOrdKey = 1 begin
			-- get the objects owned at the next depth and calculate the order key
			insert	into [ObjInfoTbl$] with (rowlock)
				(uid, ObjId, ObjClass, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType, OrdKey)
			select 	@uid, co.[id], co.[Class$], @nOwnerDepth, co.[Owner$], f.[Class], co.[OwnFlid$], co.[OwnOrd$], f.[Type], 
				oi.OrdKey+convert(varbinary, co.[Owner$]) + convert(varbinary, co.[OwnFlid$]) + convert(varbinary, coalesce(co.[OwnOrd$], 0))
			from 	[CmObject] co 
					join [ObjInfoTbl$] oi  on co.[Owner$] = oi.[ObjId]
					join [Field$] f on f.[id] = co.[OwnFlid$]
			where 	oi.[Uid]=@uid
				and oi.[OwnerDepth] = @nOwnerDepth - 1
				and ( 	( @grfcpt & 8388608 = 8388608 and f.[Type] = 23 )
					or ( @grfcpt & 33554432 = 33554432 and f.[Type] = 25 )
					or ( @grfcpt & 134217728 = 134217728 and f.[Type] = 27 )
				)
		end
		else begin
			-- get the objects owned at the next depth and do not calculate the order key
			insert	into [ObjInfoTbl$] with (rowlock)
				(uid, ObjId, ObjClass, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType)
			select 	@uid, co.[id], co.[Class$], @nOwnerDepth, co.[Owner$], f.[Class], co.[OwnFlid$], co.[OwnOrd$], f.[Type]
			from 	[CmObject] co 
					join [Field$] f on f.[id] = co.[OwnFlid$]
			where 	exists (select 	*
					from 	[ObjInfoTbl$] oi 
					where 	oi.[ObjId] = co.[Owner$]
						and oi.[Uid] = @uid
						and oi.[OwnerDepth] = @nOwnerDepth - 1
				)
				and ( 	( @grfcpt & 8388608 = 8388608 and f.[Type] = 23 )
					or ( @grfcpt & 33554432 = 33554432 and f.[Type] = 25 )
					or ( @grfcpt & 134217728 = 134217728 and f.[Type] = 27 )
				)
		end
		select @nRowCnt=@@rowcount, @Err=@@error
		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('GetLinkedObjects$: SQL Error %d; Unable to traverse owning hierachy (UID=%s).', 16, 1, @Err, @sUid)
			goto LFail
		end	

		if @fRecurse = 0 break
		set @nOwnerDepth = @nOwnerDepth + 1
	end

	--
	-- get all of the base classes of the object(s)
	--
	if @fBaseClasses = 1 begin
		insert	into ObjInfoTbl$ with (rowlock)
			(uid, ObjId, ObjClass, InheritDepth, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType, OrdKey)
		select	@uid, oi.[ObjId], p.[Dst], p.[Depth], oi.[OwnerDepth], oi.[RelObjId], oi.[RelObjClass], oi.[RelObjField], oi.[RelOrder], oi.[RelType], oi.[OrdKey]
		from	[ObjInfoTbl$] oi 
				join [ClassPar$] p on oi.[ObjClass] = p.[Src]
				join [Class$] c on c.[id] = p.[Dst]
		where	p.[Depth] > 0 and p.[Dst] <> 0
			and [Uid]=@uid

		set @Err = @@error
		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('GetLinkedObjects$: SQL Error %d; Unable to get base classes (UID=%s).', 16, 1, @Err, @sUid)
			goto LFail
		end	
	end
	--
	-- get all of the sub classes of the object(s)
	--
	if @fSubClasses = 1 begin
		insert	into ObjInfoTbl$ with (rowlock)
			(uid, ObjId, ObjClass, InheritDepth, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType, OrdKey)
		select	@uid, oi.[ObjId], p.[Src], -p.[Depth], oi.[OwnerDepth], oi.[RelObjId], oi.[RelObjClass], oi.[RelObjField], oi.[RelOrder], oi.[RelType], oi.[OrdKey]
		from	[ObjInfoTbl$] oi 
				join [ClassPar$] p on oi.[ObjClass] = p.[Dst] and InheritDepth = 0
				join [Class$] c on c.[id] = p.[Dst]
		where	p.[Depth] > 0 and p.[Dst] <> 0
			and [Uid] = @uid

		set @Err = @@error
		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('GetLinkedObjects$: SQL Error %d; Unable to get sub classes (UID=%s).', 16, 1, @Err, @sUid)
			goto LFail
		end	
	end
	
	-- determine if any references should be included in the results
	if (352321536) & @grfcpt > 0 begin

		--
		-- get a list of all of the classes that reference each class associated with the specified object 
		--	and a list of the classes that each associated class reference, then loop through them to 
		--	get all of the objects that participate in the references
		--

		-- determine which reference direction should be included
		if @nRefDirection = 0 begin
			declare GetClassRefObj_cur cursor local static forward_only read_only for
			-- get the classes that reference (atomic, sequences, and collections) this class
			select 	oi.[ObjId], oi.[ObjClass], oi.[InheritDepth], oi.[OwnerDepth], f.[Type], c.[Name], c.[Id], f.[Name], f.[Id],
				1, -- references this class
				convert(varchar, oi.[OrdKey])
			from 	[ObjInfoTbl$] oi 
					join [Field$] f on f.[DstCls] = oi.[ObjClass] 
						and ( 	( f.[type] = 24 and @grfcpt & 16777216 = 16777216 )
							or ( f.[type] = 26 and @grfcpt & 67108864 = 67108864 )
							or ( f.[type] = 28 and @grfcpt & 268435456 = 268435456 )
						)
					join [Class$] c on f.[Class] = c.[Id]
			where	[Uid]=@uid
				and (@riid is null or oi.[ObjClass] = @riid)
			union all
			-- get the classes that are referenced (atomic, sequences, and collections) by this class
			select	oi.[ObjId], oi.[ObjClass], oi.[InheritDepth], oi.[OwnerDepth], f.[Type], c.[Name], f.[DstCls], f.[Name], f.[Id],
				2, -- referenced by this class
				convert(varchar, oi.[OrdKey])
			from	[ObjInfoTbl$] oi 
					join [Class$] c on c.[Id] = oi.[ObjClass]
					join [Field$] f on f.[Class] = c.[Id] 
						and ( 	( f.[type] = 24 and @grfcpt & 16777216 = 16777216 )
							or ( f.[type] = 26 and @grfcpt & 67108864 = 67108864 )
							or ( f.[type] = 28 and @grfcpt & 268435456 = 268435456 )
						)
			where	[Uid]=@uid
				and (@riid is null or f.[DstCls] = @riid)
			order by oi.[ObjId]
		end
		else if @nRefDirection = 1 begin
			declare GetClassRefObj_cur cursor local static forward_only read_only for
			-- get the classes that are referenced (atomic, sequences, and collections) by these classes
			select	oi.[ObjId], oi.[ObjClass], oi.[InheritDepth], oi.[OwnerDepth], f.[Type], c.[Name], f.[DstCls], f.[Name], f.[Id],
				2, -- referenced by this class
				convert(varchar, oi.[OrdKey])
			from	[ObjInfoTbl$] oi 
					join [Class$] c on c.[Id] = oi.[ObjClass]
					join [Field$] f on f.[Class] = c.[Id] 
						and ( 	( f.[type] = 24 and @grfcpt & 16777216 = 16777216 )
							or ( f.[type] = 26 and @grfcpt & 67108864 = 67108864 )
							or ( f.[type] = 28 and @grfcpt & 268435456 = 268435456 )
						)
			where	[Uid]=@uid
				and (@riid is null or f.[DstCls] = @riid)
			order by oi.[ObjId]
		end
		else begin
			declare GetClassRefObj_cur cursor local static forward_only read_only for
			-- get the classes that reference (atomic, sequences, and collections) these classes
			-- do not include internal references between objects within the owning object hierarchy;
			--	this will be handled below
			select 	oi.[ObjId], oi.[ObjClass], oi.[InheritDepth], oi.[OwnerDepth], f.[Type], c.[Name], c.[Id], f.[Name], f.[Id],
				1, -- references this class
				convert(varchar, oi.[OrdKey])
			from 	[ObjInfoTbl$] oi 
					join [Field$] f on f.[DstCls] = oi.[ObjClass] 
						and ( 	( f.[type] = 24 and @grfcpt & 16777216 = 16777216 )
							or ( f.[type] = 26 and @grfcpt & 67108864 = 67108864 )
							or ( f.[type] = 28 and @grfcpt & 268435456 = 268435456 )
						)
					join [Class$] c on f.[Class] = c.[Id]
			where	[Uid]=@uid
				and (@riid is null or oi.[ObjClass] = @riid)
			order by oi.[ObjId]
		end

		open GetClassRefObj_cur
		fetch GetClassRefObj_cur into @nObjId, @nObjClass, @nInheritDepth, @nOwnerDepth, @nType, @sClass, @nClass, 
				@sField, @nField, @nDirection, @sOrdKey
		while @@fetch_status = 0 begin

			-- build the base part of the query
			set @sQry = 'insert into [ObjInfoTbl$] with (rowlock) '+
					'(uid,ObjId,ObjClass,InheritDepth,OwnerDepth,RelObjId,RelObjClass,RelObjField,RelOrder,RelType,OrdKey)' + char(13) +
					'select '''+convert(nvarchar(255), @uid)+''','

			-- determine if the reference is atomic
			if @nType = 24 begin
				-- determine if this class references an object's class within the object hierachy,
				--	and whether or not it should be included
				if @nDirection = 1 and (@nRefDirection = 0 or @nRefDirection = -1) begin 
					set @sQry=@sQry+convert(nvarchar(11), @nObjId)+','+convert(nvarchar(11), @nObjClass)+','+
							convert(nvarchar(11), @nInheritDepth)+','+convert(nvarchar(11), @nOwnerDepth)+','+
							't.[Id],'+convert(nvarchar(11), @nClass)+','+convert(nvarchar(11), @nField)+','+
							'NULL,'+convert(nvarchar(11), @nType)+',convert(varbinary,'''+@sOrdKey+''') '+
						'from ['+@sClass+'] t  '+
						'where ['+@sField+']='+convert(nvarchar(11),@nObjId)

					-- determine if only external references should be included - don't included
					--	references between objects within the owning hierarchy
					if @nRefDirection = -1 begin
						set @sQry = @sQry + 'and not exists (' +
								'select * from [ObjInfoTbl$] oi  ' +
								'where oi.[ObjId]=t.[Id] ' +
									'and oi.[uid] = '''+convert(nvarchar(255), @uid)+ '''' +
									'and oi.[RelType] not in (' +
									convert(nvarchar(11), 16777216)+',' +
									convert(nvarchar(11), 67108864)+',' +
									convert(nvarchar(11), 268435456)+'))'
					end
				end
				-- determine if this class is referenced by an object's class within the object hierachy,
				--	and whether or not it should be included
				else if @nDirection = 2 and (@nRefDirection = 0 or @nRefDirection = 1) begin
					set @sQry=@sQry+'['+@sField+'],'+
					 		convert(nvarchar(11), @nClass)+','+convert(nvarchar(11), @nInheritDepth)+','+
							convert(nvarchar(11), @nOwnerDepth)+','+convert(nvarchar(11), @nObjId)+','+
							convert(nvarchar(11), @nObjClass)+','+convert(nvarchar(11), @nField)+','+
							'NULL,'+convert(nvarchar(11), @nType)+',convert(varbinary,'''+@sOrdKey+''') '+
						'from ['+@sClass+']  ' +
						'where [id]='+convert(nvarchar(11),@nObjId)+' '+
							'and ['+@sField+'] is not null'
				end
			end
			else begin
				-- if the reference is ordered insert the order value, otherwise insert null
				if @nType = 28 set @sOrderField = '[Ord]'
				else set @sOrderField = 'NULL'

				-- determine if this class references an object's class and whether or not it should be
				--	included
				if @nDirection = 1 and (@nRefDirection = 0 or @nRefDirection = -1) begin 
					set @sQry=@sQry+convert(nvarchar(11), @nObjId)+','+convert(nvarchar(11), @nObjClass)+','+
							convert(nvarchar(11), @nInheritDepth)+','+convert(nvarchar(11), @nOwnerDepth)+','+
							't.[Src],'+convert(nvarchar(11), @nClass)+','+convert(nvarchar(11), @nField)+','+
							@sOrderField+','+convert(nvarchar(11), @nType)+',convert(varbinary,'''+@sOrdKey+''') '+
						'from ['+@sClass+'_'+@sField+'] t  '+
						'where t.[dst]='+convert(nvarchar(11),@nObjId)

					-- determine if only external references should be included - don't included
					--	references between objects within the owning hierarchy
					if @nRefDirection = -1 begin
						set @sQry = @sQry + 'and not exists (' +
								'select * from [ObjInfoTbl$] oi  ' +
								'where oi.[ObjId]=t.[Src] ' +
									'and oi.[uid] = '''+convert(nvarchar(255), @uid)+ '''' +
									'and oi.[RelType] not in (' +
									convert(nvarchar(11), 16777216)+',' +
									convert(nvarchar(11), 67108864)+',' +
									convert(nvarchar(11), 268435456)+'))'
					end
				end
				-- determine if this class is referenced by an object's class and whether or not it
				--	should be included
				else if @nDirection = 2 and (@nRefDirection = 0 or @nRefDirection = 1) begin
					set @sQry=@sQry+'[Dst],'+
							convert(nvarchar(11), @nClass)+','+convert(nvarchar(11), @nInheritDepth)+','+
							convert(nvarchar(11), @nOwnerDepth)+','+convert(nvarchar(11), @nObjId)+','+
							convert(nvarchar(11), @nObjClass)+','+convert(nvarchar(11), @nField)+','+
							@sOrderField+','+convert(nvarchar(11), @nType)+',convert(varbinary,'''+@sOrdKey+''') '+
						'from ['+@sClass+'_'+@sField+']  '+
						'where [src]='+convert(nvarchar(11),@nObjId)
				end
			end

			exec (@sQry)				
			set @Err = @@error
			if @Err <> 0 begin
				set @sUid = convert(nvarchar(50), @Uid)
				raiserror ('GetLinkedObjects$: SQL Error %d; Error performing dynamic SQL (UID=%s).', 16, 1, @Err, @sUid)

				close GetClassRefObj_cur
				deallocate GetClassRefObj_cur

				goto LFail
			end

			fetch GetClassRefObj_cur into @nObjId, @nObjClass, @nInheritDepth, @nOwnerDepth, @nType, @sClass, 
					@nClass, @sField, @nField, @nDirection, @sOrdKey
		end

		close GetClassRefObj_cur
		deallocate GetClassRefObj_cur
	end

	-- if a class was specified remove the owned objects that are not of that type of class; these objects were
	--    necessary in order to get a list of all of the referenced and referencing objects that were potentially 
	--    the type of specified class
	if @riid is not null begin
		delete	[ObjInfoTbl$]
		where 	[Uid] = @uid
			and not exists (
				select	*
				from	[ClassPar$] cp
				where	cp.[Dst] = @riid
					and cp.[Src] = [ObjClass]
			)
		set @Err = @@error
		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('GetLinkedObjects$: SQL Error %d; Unable to remove objects that are not the specified class %d (UID=%s).', 16, 1, @Err, @riid, @sUid)
			goto LFail
		end
	end

LFail:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @Err
go

































if object_id('fnGetOwnershipPath$') is not null begin
	print 'removing function fnGetOwnershipPath$'
	drop function [fnGetOwnershipPath$]
end
go
print 'creating function fnGetOwnershipPath$'
go
create function [fnGetOwnershipPath$] (
	@ObjId int=null,
	@hXMLDocObjList int=null,
	@nDirection smallint=0,	
	@fRecurse tinyint=1,
	@fCalcOrdKey tinyint=1 )
returns @ObjInfo table (
	[ObjId]		int		not null,
	[ObjClass]	int		null,
	[InheritDepth]	int		null		default(0),
	[OwnerDepth]	int		null		default(0),
	[RelObjId]	int		null,
	[RelObjClass]	int		null,
	[RelObjField]	int		null,
	[RelOrder]	int		null,
	[RelType]	int		null,
	[OrdKey]	varbinary(250)	null		default(0)
)
as
begin
	declare @nRowCnt int, @nOwnerDepth int

	-- determine if an object was supplied as an argument, if one was not use ObjInfoTbl$ as the list of objects
	if @objId is not null begin 

		-- get the class of the specified object
		insert into @ObjInfo
			(ObjId, ObjClass, OwnerDepth, InheritDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType, OrdKey)
		select	@objId, co.[Class$], 0, 0, co.[Owner$], f.[Class], co.[OwnFlid$], co.[OwnOrd$], f.[Type],
			-- go ahead and calculate the order key for depth 0 objects even if @fCalcOrdKey=0
			convert(varbinary, coalesce(co.[Owner$], 0)) + 
			convert(varbinary, coalesce(co.[OwnFlid$], 0)) +
			convert(varbinary, coalesce(co.[OwnOrd$], 0))
		from	[CmObject] co 
				left outer join [Field$] f on co.[OwnFlid$] = f.[Id]
		where	co.[Id] = @objId
		if @@error <> 0 goto LFail
	end
	else begin

		-- parse the XML list of Object IDs and insert them into the table variable
		insert into @ObjInfo (ObjId, ObjClass, OrdKey)
		select	i.[Id], co.[Class$],
			-- calculate the order key even if @fCalcOrdKey = 0 because the overhead is very small here
			convert(varbinary, coalesce(co.[Owner$], 0)) + 
			convert(varbinary, coalesce(co.[OwnFlid$], 0)) +
			convert(varbinary, coalesce(co.[OwnOrd$], 0))
		from	openxml (@hXMLDocObjList, '/root/Obj') with ([Id] int) i
			join [CmObject] co  on co.[Id] = i.[Id]
		if @@error <> 0 goto LFail
	end

	-- determine if the objects owned by the specified object(s) should be included in the results
	if @nDirection = 0 or @nDirection = 1 begin
		set @nRowCnt = 1
		set @nOwnerDepth = 1
	end
	else set @nRowCnt = 0
	while @nRowCnt > 0 begin	

		-- determine if the order key should be calculated - if the order key is not needed a more 
		--    effecient query can be used to generate the ownership tree
		if @fCalcOrdKey = 1 begin
			-- get the objects owned at the next depth and calculate the order key
			insert into @ObjInfo
				(ObjId, ObjClass, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType, OrdKey)
			select 	co.[id], co.[Class$], @nOwnerDepth, co.[Owner$], f.[DstCls], co.[OwnFlid$], co.[OwnOrd$], f.[Type], 
				oi.OrdKey+convert(varbinary, co.[Owner$]) + convert(varbinary, co.[OwnFlid$]) + convert(varbinary, coalesce(co.[OwnOrd$], 0))
			from 	[CmObject] co 
					join @ObjInfo oi on co.[Owner$] = oi.[ObjId]
					join [Field$] f on f.[id] = co.[OwnFlid$]
			where 	oi.[OwnerDepth] = @nOwnerDepth - 1
		end
		else begin
			-- get the objects owned at the next depth and do not calculate the order key
			insert into @ObjInfo
				(ObjId, ObjClass, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType)
			select 	co.[id], co.[Class$], @nOwnerDepth, co.[Owner$], f.[DstCls], co.[OwnFlid$], co.[OwnOrd$], f.[Type]
			from 	[CmObject] co 
					join [Field$] f on f.[id] = co.[OwnFlid$]
			where 	exists (select 	*
					from 	@ObjInfo oi
					where 	oi.[ObjId] = co.[Owner$]
						and oi.[OwnerDepth] = @nOwnerDepth - 1
					)
		end
		set @nRowCnt = @@rowcount

		if @fRecurse = 0 break
		set @nOwnerDepth = @nOwnerDepth + 1
	end

	-- determine if the heirarchy of objects that own the specified object(s) should be included in the results
	if @nDirection = 0 or @nDirection = -1 begin
		set @nRowCnt = 1
		set @nOwnerDepth = -1
	end
	else set @nRowCnt = 0
	while @nRowCnt > 0 begin
		insert into @ObjInfo
			(ObjId, ObjClass, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType, OrdKey)
		select 	co.[Id], co.[Class$], @nOwnerDepth, co.[Owner$], f.[Class], co.[OwnFlid$], co.[OwnOrd$], f.[Type], 0
		from 	[CmObject] co 
				left join [Field$] f on f.[id] = co.[OwnFlid$]
		-- for this query the exists clause is more effecient than a join based on the ownership depth
		where 	exists (select	*
				from	@ObjInfo oi
				where	oi.[RelObjId] = co.[Id]
					and oi.[OwnerDepth] = @nOwnerDepth + 1
				)
		set @nRowCnt = @@rowcount

		if @fRecurse = 0 break
		set @nOwnerDepth = @nOwnerDepth - 1
	end

	return
LFail:
	delete @ObjInfo

	return
end
go


























if object_id('GetOwnershipPath$') is not null begin
	print 'removing proc GetOwnershipPath$'
	drop proc [GetOwnershipPath$]
end
go
print 'creating proc GetOwnershipPath$'
go
create proc [GetOwnershipPath$]
	@uid uniqueidentifier output,
	@ObjId int=NULL,
	@nDirection smallint=0,	
	@fRecurse tinyint=1,
	@fCalcOrdKey tinyint=1
as
	declare @Err int, @nRowCnt int, @nOwnerDepth int, @fIsNocountOn int, @sUid nvarchar(50)

	set @Err = 0

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- determine if an object was supplied as an argument, if one was not use ObjInfoTbl$ as the list of objects
	if @objId is not null begin 
		-- get a unique value to identify this invocation's results
		set @uid = newid()

		-- get the class of the specified object
		insert into [ObjInfoTbl$] with (rowlock)
			(uid, ObjId, ObjClass, OwnerDepth, InheritDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType, OrdKey)
		select	@uid, @objId, co.[Class$], 0, 0, co.[Owner$], f.[Class], co.[OwnFlid$], co.[OwnOrd$], f.[Type],
			-- go ahead and calculate the order key for depth 0 objects even if @fCalcOrdKey=0
			convert(varbinary, coalesce(co.[Owner$], 0)) + 
			convert(varbinary, coalesce(co.[OwnFlid$], 0)) +
			convert(varbinary, coalesce(co.[OwnOrd$], 0))
		from	[CmObject] co 
				left outer join [Field$] f on co.[OwnFlid$] = f.[Id]
		where	co.[Id] = @objId

		set @Err = @@error
		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('GetOwnershipPath$: SQL Error %d; Error inserting initial object (UID=%s).', 16, 1, @Err, @sUid)
			goto LFail
		end
	end
	else begin
		update	[ObjInfoTbl$] with (rowlock)
		set	[ObjClass]=co.[Class$], [OwnerDepth]=0, [InheritDepth]=0, [RelObjId]=co.[Owner$], [RelObjClass]=f.[Class], 
			[RelObjField]=co.[OwnFlid$], [RelOrder]=co.[OwnOrd$], [RelType]=f.[Type],
			-- go ahead and calculate the order key for depth 0 objects even if @fCalcOrdKey=0
			[OrdKey]=convert(varbinary, coalesce(co.[Owner$], 0)) + 
				convert(varbinary, coalesce(co.[OwnFlid$], 0)) +
				convert(varbinary, coalesce(co.[OwnOrd$], 0))
		from	[ObjInfoTbl$] oi 
				join [CmObject] co  on oi.[ObjId] = co.[Id] 
				left outer join [Field$] f on co.[OwnFlid$] = f.[Id]
		where	oi.[uid]=@uid

		set @Err = @@error
		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('GetOwnershipPath$: SQL Error %d; Unable to update initial objects (UID=%s).', 16, 1, @Err, @sUid)
			goto LFail
		end
	end

	-- determine if the objects owned by the specified object(s) should be included in the results
	if @nDirection = 0 or @nDirection = 1 begin
		set @nRowCnt = 1
		set @nOwnerDepth = 1
	end
	else set @nRowCnt = 0
	while @nRowCnt > 0 begin	

		-- determine if the order key should be calculated - if the order key is not needed a more 
		--    effecient query can be used to generate the ownership tree
		if @fCalcOrdKey = 1 begin
			-- get the objects owned at the next depth and calculate the order key
			insert into [ObjInfoTbl$] with (rowlock)
				(uid, ObjId, ObjClass, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType, OrdKey)
			select 	@uid, co.[id], co.[Class$], @nOwnerDepth, co.[Owner$], f.[DstCls], co.[OwnFlid$], co.[OwnOrd$], f.[Type], 
				oi.OrdKey+convert(varbinary, co.[Owner$]) + convert(varbinary, co.[OwnFlid$]) + convert(varbinary, coalesce(co.[OwnOrd$], 0))
			from 	[CmObject] co 
					join [ObjInfoTbl$] oi  on co.[Owner$] = oi.[ObjId]
					join [Field$] f on f.[id] = co.[OwnFlid$]
			where 	[Uid]=@uid
				and oi.[OwnerDepth] = @nOwnerDepth - 1
		end
		else begin
			-- get the objects owned at the next depth and do not calculate the order key
			insert into [ObjInfoTbl$] with (rowlock)
				(uid, ObjId, ObjClass, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType)
			select 	@uid, co.[id], co.[Class$], @nOwnerDepth, co.[Owner$], f.[DstCls], co.[OwnFlid$], co.[OwnOrd$], f.[Type]
			from 	[CmObject] co 
					join [Field$] f on f.[id] = co.[OwnFlid$]
			where 	exists (select 	*
					from 	[ObjInfoTbl$] oi 
					where 	oi.[ObjId] = co.[Owner$]
						and oi.[Uid] = @uid
						and oi.[OwnerDepth] = @nOwnerDepth - 1
					)
		end
		select @nRowCnt=@@rowcount, @Err=@@error

		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('GetOwnershipPath$: SQL Error %d; Unable to traverse owning hierachy - owned object(s) (UID=%s).', 16, 1, @Err, @sUid)
			goto LFail
		end

		if @fRecurse = 0 break
		set @nOwnerDepth = @nOwnerDepth + 1
	end

	-- determine if the heirarchy of objects that own the specified object(s) should be included in the results
	if @nDirection = 0 or @nDirection = -1 begin
		set @nRowCnt = 1
		set @nOwnerDepth = -1
	end
	else set @nRowCnt = 0
	while @nRowCnt > 0 begin
		-- REVIEW: JDR
		-- possibly calculate the OrdKey for this direction as well - if this is done it may be easiest to calculate all of the order
		-- keys at the very end
		insert into [ObjInfoTbl$] with (rowlock)
			(uid, ObjId, ObjClass, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType, OrdKey)
		select 	@uid, co.[Id], co.[Class$], @nOwnerDepth, co.[Owner$], f.[Class], co.[OwnFlid$], co.[OwnOrd$], f.[Type], 0
		from 	[CmObject] co 
				left join [Field$] f on f.[id] = co.[OwnFlid$]
		-- for this query the exists clause is more effecient than a join based on the ownership depth
		where 	exists (select	*
				from	ObjInfoTbl$ oi 
				where	oi.[RelObjId] = co.[Id]
					and oi.[Uid]=@uid
					and oi.[OwnerDepth] = @nOwnerDepth + 1
				)
		select @nRowCnt=@@rowcount, @Err=@@error

		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('GetOwnershipPath$: SQL Error %d; Unable to traverse owning hierachy - object(s) that own the specified object(s) (UID=%s).', 16, 1, @Err, @sUid)
			goto LFail
		end
		if @fRecurse = 0 break
		set @nOwnerDepth = @nOwnerDepth - 1
	end

	set @Err = 0
LFail:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @Err
go

















if object_id('fnIsInOwnershipPath$') is not null begin
	print 'removing function fnIsInOwnershipPath$'
	drop function [fnIsInOwnershipPath$]
end
go
print 'creating function fnIsInOwnershipPath$'
go
create function [fnIsInOwnershipPath$] (
	@ObjId int,
	@OwnerObjId int )
returns tinyint
as
begin
	declare @nRowCnt int, @nOwnerDepth int
	declare @fInPath tinyint
	declare @ObjInfo table (
		[ObjId]		int		not null,
		[ObjClass]	int		null,
		[InheritDepth]	int		null		default(0),
		[OwnerDepth]	int		null		default(0),
		[RelObjId]	int		null,
		[RelObjClass]	int		null,
		[RelObjField]	int		null,
		[RelOrder]	int		null,
		[RelType]	int		null,
		[OrdKey]	varbinary(250)	null		default(0) )

	set @fInPath = 0

	-- get the class of the specified object
	insert into @ObjInfo (ObjId, ObjClass)
	select	@OwnerObjId, co.[Class$]
	from	[CmObject] co 
	where	co.[Id] = @OwnerObjId
	if @@error <> 0 goto LFail

	set @nRowCnt = 1
	set @nOwnerDepth = 1
	while @nRowCnt > 0 begin
		-- determine if one of the objects at the current depth owns the specified object, if
		--    one does we can exit here
		if exists (
			select	*
			from	[CmObject] co 
					join @ObjInfo oi on co.[Owner$] = oi.[ObjId]
			where	oi.[OwnerDepth] = @nOwnerDepth - 1
				and co.[Id] = @ObjId 
			) 
		begin
			set @fInPath = 1
			goto Finish
		end

		-- add all of the objects owned at the next depth to the object list
		insert	into @ObjInfo (ObjId, ObjClass, OwnerDepth, RelObjId)
		select 	co.[id], co.[Class$], @nOwnerDepth, co.[Owner$]
		from 	[CmObject] co 
		where 	exists (select	*
				from 	@ObjInfo oi
				where 	oi.[ObjId] = co.[Owner$]
					and oi.[OwnerDepth] = @nOwnerDepth - 1
				)
		set @nRowCnt = @@rowcount

		set @nOwnerDepth = @nOwnerDepth + 1
	end

Finish:
	return @fInPath
LFail:
	return -1
end
go



























if object_id('fnGetObjInOwnershipPathWithId$') is not null begin
	print 'removing function fnGetObjInOwnershipPathWithId$'
	drop function [fnGetObjInOwnershipPathWithId$]
end
go
print 'creating function fnGetObjInOwnershipPathWithId$'
go
create function [fnGetObjInOwnershipPathWithId$] (
	@objId int=null,
	@hXMLDocObjList int=null,
	@riid int )
returns @ObjInfo table (
	[ObjId]		int		not null,
	[ObjClass]	int		null,
	[InheritDepth]	int		null		default(0),
	[OwnerDepth]	int		null		default(0),
	[RelObjId]	int		null,
	[RelObjClass]	int		null,
	[RelObjField]	int		null,
	[RelOrder]	int		null,
	[RelType]	int		null,
	[OrdKey]	varbinary(250)	null		default(0)
)
as
begin
	declare	@iOwner int, @iOwnerClass int, @iCurObjId int, @iPrevObjId int

	-- determine if an object was supplied as an argument, if one was not use ObjInfoTbl$ as the list of objects
	if @objId is not null begin 

		-- get the class of the specified object
		insert into @ObjInfo (ObjId, ObjClass, InheritDepth, OwnerDepth, ordkey)
		select	@objId, co.[Class$], null, null, null
		from	[CmObject] co 
		where	co.[Id] = @objId
		if @@error <> 0 goto LFail		
	end
	else begin

		-- parse the XML list of Object IDs and insert them into the table variable
		insert into @ObjInfo (ObjId, ObjClass, OrdKey)
		select	i.[Id], co.[Class$],
			-- calculate the order key even if @fCalcOrdKey = 0 because the overhead is very small here
			convert(varbinary, coalesce(co.[Owner$], 0)) + 
			convert(varbinary, coalesce(co.[OwnFlid$], 0)) +
			convert(varbinary, coalesce(co.[OwnOrd$], 0))
		from	openxml (@hXMLDocObjList, '/root/Obj') with ([Id] int) i
			join [CmObject] co  on co.[Id] = i.[Id]
		if @@error <> 0 goto LFail
	end

	select	@iCurObjId=min(ObjId)
	from	@ObjInfo

	while @iCurObjId is not null begin
		set @iPrevObjId = @iCurObjId

		-- loop up (objects that own the specified objects) through the ownership hierarchy until the specified type (class=riid) of 
		-- 	owning object is found or the top of the ownership hierarchy is reached
		set @iOwnerClass = 0
		while @iOwnerClass <> @riid begin
			select top 1
				@iOwner = co.[Owner$],
				@iOwnerClass = f.[Class]
			from	[CmObject] co 
					join [Field$] f on f.[id] = co.[OwnFlid$]
			where 	co.[id] = @iCurObjId

			if @@rowcount > 0 set @iCurObjId = @iOwner
			else begin
				set @iCurObjId = null
				break
			end
		end

		if @iCurObjId is not null begin
			-- update the ObjInfoTbl$ so that specified object(s) is/are related to the specified type of
			--    object (class=riid) that owns it
			update	@ObjInfo
			set	[RelObjId]=@iOwner,
				[RelObjClass]=(
					select co.[Class$]
					from [CmObject] co 
					where co.[id]=@iOwner)
			where	[ObjId]=@iPrevObjId
			if @@error <> 0 goto LFail
		end

		-- if the user specified an object there was only one object to process and we can therefore
		--    break out of the loop
		if @objId is not null break

		select	@iCurObjId=min(ObjId)
		from	@ObjInfo
		where	[ObjId] > @iPrevObjId
	end

	return
LFail:
	delete @ObjInfo
	return
end
go



















if object_id('GetObjInOwnershipPathWithId$') is not null begin
	print 'removing proc GetObjInOwnershipPathWithId$'
	drop proc [GetObjInOwnershipPathWithId$]
end
go
print 'creating proc GetObjInOwnershipPathWithId$'
go
create proc [GetObjInOwnershipPathWithId$]
	@uid uniqueidentifier output,
	@objId int=NULL,
	@riid int
as
	declare	@iOwner int, @iOwnerClass int, @iCurObjId int, @iPrevObjId int,
		@Err int, @fIsNoCountOn int
	declare @sUid nvarchar(50)

	set @Err = 0
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- determine if an object was supplied as an argument, if one was not use ObjInfoTbl$ as the list of objects
	if @objId is not null begin 
		-- get a unique value to identify this invocation's results
		set @uid = newid()

		-- get the class of the specified object
		insert into [ObjInfoTbl$] with (rowlock) (uid, ObjId, ObjClass, InheritDepth, OwnerDepth, ordkey)
		select	@uid, @objId, co.[Class$], null, null, null
		from	[CmObject] co 
		where	co.[Id] = @objId
		
		set @Err = @@error
		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('GetObjInOwnershipPathWithId$: SQL Error %d; Unable to insert the initial object (UID=%s).', 16, 1, @Err, @sUid)
			goto LFail
		end	
	end
	else begin
		update	[ObjInfoTbl$] with (rowlock)
		set	[ObjClass]=co.[Class$], [OwnerDepth]=null, [InheritDepth]=null, [RelObjId]=null, 
			[RelObjClass]=null, [RelObjField]=null,	[RelOrder]=null, [RelType]=null, [OrdKey]=null
		from	[ObjInfoTbl$] oi 
				join [CmObject] co  on oi.[ObjId] = co.[Id] 
		where	oi.[uid]=@uid

		set @Err = @@error
		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('GetObjInOwnershipPathWithId$: SQL Error %d; Unable to update the initial object(s) (UID=%s).', 16, 1, @Err, @sUid)
			goto LFail
		end	
	end

	select	@iCurObjId=min(ObjId)
	from	ObjInfoTbl$ (serializable)
	where	uid=@uid

	while @iCurObjId is not null begin
		set @iPrevObjId = @iCurObjId

		-- loop up (objects that own the specified objects) through the ownership hierarchy until the specified type (class=riid) of 
		-- 	owning object is found or the top of the ownership hierarchy is reached
		set @iOwnerClass = 0
		while @iOwnerClass <> @riid begin
			select top 1
				@iOwner = co.[Owner$],
				@iOwnerClass = f.[Class]
			from	[CmObject] co 
					join [Field$] f on f.[id] = co.[OwnFlid$]
			where 	co.[id] = @iCurObjId

			if @@rowcount > 0 set @iCurObjId = @iOwner
			else begin
				set @iCurObjId = null
				break
			end
		end

		if @iCurObjId is not null
		begin
			-- update the ObjInfoTbl$ so that specified object(s) is/are related to the specified type of
			--    object (class=riid) that owns it
			update	[ObjInfoTbl$] with (rowlock)
			set	[RelObjId]=@iOwner,
				[RelObjClass]=(
					select co.[Class$]
					from [CmObject] co 
					where co.[id]=@iOwner)
			where	[uid]=@uid 
				and [ObjId]=@iPrevObjId

			set @Err = @@error
			if @Err <> 0 begin
				set @sUid = convert(nvarchar(50), @Uid)
				raiserror ('GetObjInOwnershipPathWithId$: SQL Error %d; Unable to update object relationship information (UID=%s).', 16, 1, @Err, @sUid)
				goto LFail
			end	
		end

		-- if the user specified an object there was only one object to process and we can therefore
		--    break out of the loop
		if @objId is not null break

		select	@iCurObjId=min(ObjId)
		from	[ObjInfoTbl$] (serializable)
		where	[uid]=@uid 
			and [ObjId] > @iPrevObjId
	end

LFail:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @Err
go


























if object_id('GetIncomingRefs$') is not null begin
	print 'removing proc GetIncomingRefs$'
	drop proc [GetIncomingRefs$]
end
go
print 'creating proc GetIncomingRefs$'
go
create proc [GetIncomingRefs$]
	@uid uniqueidentifier output,
	@ObjId int=null,
	@fRecurse tinyint=1,
	@fDelOwnTree tinyint=1
as
	declare @Err int

	exec @Err = GetLinkedObjects$ @uid, @ObjId, 528482304, 1, 0, @fRecurse, -1, null, 0
	return @Err
go






























if object_id('fnGetSubObjects$') is not null begin
	print 'removing function GetSubObjects$'
	drop function [fnGetSubObjects$]
end
go
print 'Creating function fnGetSubObjects$'
go
create function [fnGetSubObjects$] (
	@ObjId int=null,
	@hXMLDocObjList int=null,
	@Flid int )
returns @ObjInfo table (
	[ObjId]		int		not null,
	[ObjClass]	int		null,
	[InheritDepth]	int		null		default(0),
	[OwnerDepth]	int		null		default(0),
	[RelObjId]	int		null,
	[RelObjClass]	int		null,
	[RelObjField]	int		null,
	[RelOrder]	int		null,
	[RelType]	int		null,
	[OrdKey]	varbinary(250)	null		default(0)
)
as
begin
	declare @nRowCnt int, @nOwnerDepth int

	-- determine if an object was supplied as an argument, if one was not use ObjInfoTbl$ as the list of objects
	if @objId is not null begin 

		-- get the class of the specified object
		insert into @ObjInfo (ObjId, ObjClass)
		select	@objId, co.[Class$]
		from	[CmObject] co 
		where	co.[Id] = @objId
		if @@error <> 0 goto LFail
	end
	else begin

		-- parse the XML list of Object IDs and insert them into the table variable
		insert into @ObjInfo (ObjId, ObjClass, OrdKey)
		select	i.[Id], co.[Class$],
			-- calculate the order key even if @fCalcOrdKey = 0 because the overhead is very small here
			convert(varbinary, coalesce(co.[Owner$], 0)) + 
			convert(varbinary, coalesce(co.[OwnFlid$], 0)) +
			convert(varbinary, coalesce(co.[OwnOrd$], 0))
		from	openxml (@hXMLDocObjList, '/root/Obj') with ([Id] int) i
			join [CmObject] co  on co.[Id] = i.[Id]
		if @@error <> 0 goto LFail
	end

	-- loop through the ownership hiearchy for all sub-objects based on the specified flid (field ID)
	set @nRowCnt = 1
	set @nOwnerDepth = 1
	while @nRowCnt > 0 begin	
		insert into @ObjInfo
			(ObjId, ObjClass, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType)
		select 	co.[id], co.[Class$], @nOwnerDepth, co.[Owner$], null, co.[OwnFlid$], co.[OwnOrd$], 25
		from 	[CmObject] co 
		where 	co.[OwnFlid$] = @flid
			and exists (
				select 	*
				from 	@ObjInfo oi
				where 	oi.[ObjId] = co.[Owner$]
					and oi.[OwnerDepth] = @nOwnerDepth - 1
				)
		set @nRowCnt = @@rowcount
		set @nOwnerDepth = @nOwnerDepth + 1
	end

	return	
LFail:
	delete @ObjInfo
	return
end
go


















if object_id('GetSubObjects$') is not null begin
	print 'removing proc GetSubObjects$'
	drop proc [GetSubObjects$]
end
go
print 'Creating proc GetSubObjects$'
go
create proc [GetSubObjects$]
	@uid uniqueidentifier output,
	@ObjId int=NULL,
	@Flid int
as
	declare @Err int, @nRowCnt int, @nOwnerDepth int
	declare	@fIsNocountOn int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- determine if an object was supplied as an argument, if one was not use ObjInfoTbl$ as the list of objects
	if @objId is not null begin 
		-- get a unique value to identify this invocation's results
		set @uid = newid()

		-- get the class of the specified object
		insert into [ObjInfoTbl$] with (rowlock) (uid, ObjId, ObjClass)
		select	@uid, @objId, co.[Class$]
		from	[CmObject] co 
		where	co.[Id] = @objId
		set @Err = @@error
		if @Err <> 0 goto Finish
	end
	else begin
		update	[ObjInfoTbl$] with (rowlock)
		set	[ObjClass]=co.[Class$], [OwnerDepth]=0, [InheritDepth]=0
		from	[ObjInfoTbl$] oi 
				join [CmObject] co  on oi.[ObjId] = co.[Id]
					and oi.[uid]=@uid
		set @Err = @@error
		if @Err <> 0 goto Finish
	end

	-- loop through the ownership hiearchy for all sub-objects based on the specified flid (field ID)
	set @nRowCnt = 1
	set @nOwnerDepth = 1
	while @nRowCnt > 0 begin	
		insert into [ObjInfoTbl$] with (rowlock)
			(uid, ObjId, ObjClass, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType)
		select 	@uid, co.[id], co.[Class$], @nOwnerDepth, co.[Owner$], null, co.[OwnFlid$], co.[OwnOrd$], 25
		from 	[CmObject] co 
		where 	co.[OwnFlid$] = @flid
			and exists (
				select 	*
				from 	[ObjInfoTbl$] oi 
				where 	oi.[ObjId] = co.[Owner$]
					and oi.[Uid] = @uid
					and oi.[OwnerDepth] = @nOwnerDepth - 1
				)
		select @nRowCnt=@@rowcount, @Err=@@error

		if @Err <> 0 goto Finish
		set @nOwnerDepth = @nOwnerDepth + 1
	end
	
Finish:
	-- reestablish the initial setting of nocount
	if @fIsNocountOn = 0 set nocount off
	return @Err
go

















if object_id('GetIncomingRefsPrepDel$') is not null begin
	print 'removing proc GetIncomingRefsPrepDel$'
	drop proc [GetIncomingRefsPrepDel$]
end
go
print 'creating proc GetIncomingRefsPrepDel$'
go
create proc [GetIncomingRefsPrepDel$]
	@uid uniqueidentifier output,
	@ObjId int=NULL
as
	declare @Err int, @sUid nvarchar(50)

	-- get incoming references, but do not delete the ownership tree
	exec @Err=GetIncomingRefs$ @uid, @ObjId, 1, 0
	if @Err <> 0 begin
		set @sUid = convert(nvarchar(50), @Uid)
		raiserror ('GetIncomingRefsPrepDel$: SQL Error %d; Unable to get incoming references (UID=%s).', 16, 1, @Err, @sUid)
	end

	return @Err
go















if object_id('fnGetLastModified$') is not null begin
	print 'removing function fnGetLastModified$'
	drop function [fnGetLastModified$]
end
go
print 'creating function fnGetLastModified$'
go
create function [fnGetLastModified$] (@ObjId int)
returns smalldatetime
as
begin
	declare @dttmLastUpdate smalldatetime

	-- get all objects owned by the specified object
	select	@dttmLastUpdate = max(co.[UpdDttm])
	from	fnGetOwnershipPath$ (@Objid, null, 1, 1, 0) oi
			join [CmObject] co  on oi.[ObjId] = co.[Id]

	return @dttmLastUpdate
end
go















if object_id('GetPossibilities') is not null begin
	print 'removing proc GetPossibilities'
	drop proc [GetPossibilities]
end
go
print 'creating proc GetPossibilities'
go
create proc [GetPossibilities]
	@ObjId int,
	@Ws int
as
	declare @uid uniqueidentifier, 
	        @retval int

	-- get all of the possibilities owned by the specified possibility list object
	declare @tblObjInfo table (
		[ObjId]		int		not null,
		[ObjClass]	int		null,
		[InheritDepth]	int		null	default(0),
		[OwnerDepth]	int		null	default(0),
		[RelObjId]	int		null,
		[RelObjClass]	int		null,
		[RelObjField]	int		null,
		[RelOrder]	int		null,
		[RelType]	int		null,
		[OrdKey]	varbinary(250)	null	default(0))

	insert into @tblObjInfo
		select * from fnGetOwnedObjects$(@ObjId, null, 176160768, 0, 0, 1, 7, 1)
	
	-- First return a count so that the caller can preallocate memory for the results.
	select count(*) from @tblObjInfo
	
	--
	--  get an ordered list of relevant writing system codes
	--
	declare @tblWs table (
		[WsId]	int not null, -- don't make unique. It shouldn't happen, but we don't want a crash if it does.
		[Ord]	int primary key clustered identity(1,1))
	--( 0xffffffff (-1) or 0xfffffffd (-3) = First string from a) ordered checked analysis 
	-- writing systems b) any remaining analysis writing systems or stars if none of the above.
	if @Ws = 0xffffffff or @Ws = 0xfffffffd begin
		insert into @tblWs (WsId)
			select lws.id
			from LanguageProject_CurrentAnalysisWritingSystems caws
			join LgWritingSystem lws on caws.dst = lws.id
			order by caws.Ord
		insert into @tblWs (WsId)
			select distinct lws.id
			from LanguageProject_AnalysisWritingSystems caws
			join LgWritingSystem lws on caws.dst = lws.id and lws.id not in (select WsId from @tblWs)
	end
	--( 0xfffffffe (-2) or 0xfffffffc (-4) = First string from a) ordered checked vernacular 
	-- writing systems b) any remaining vernacular writing systems or stars if none of the above.
	else if @Ws = 0xfffffffe or @Ws = 0xfffffffc begin
		insert into @tblWs (WsId)
			select lws.id
			from LanguageProject_CurrentVernacularWritingSystems cvws
			join LgWritingSystem lws on cvws.dst = lws.id
			order by cvws.Ord
		insert into @tblWs (WsId)
			select distinct lws.id
			from LanguageProject_VernacularWritingSystems cvws
			join LgWritingSystem lws on cvws.dst = lws.id and lws.id not in (select WsId from @tblWs)
	end
	--( 0xfffffffb = -5 = First string from a) ordered checked analysis writing systems 
	-- b) ordered checked vernacular writing systems, c) any remaining analysis writing systems,
	-- d) any remaining vernacular writing systems or stars if none of the above.
	else if @Ws = 0xfffffffb begin
		insert into @tblWs (WsId)
			select lws.id
			from LanguageProject_CurrentAnalysisWritingSystems caws
			join LgWritingSystem lws on caws.dst = lws.id
			order by caws.Ord
		insert into @tblWs (WsId)
			select lws.id
			from LanguageProject_CurrentVernacularWritingSystems cvws
			join LgWritingSystem lws on cvws.dst = lws.id
			where lws.id not in (select WsId from @tblWs)
			order by cvws.Ord
		insert into @tblWs (WsId)
			select distinct lws.id
			from LanguageProject_AnalysisWritingSystems caws
			join LgWritingSystem lws on caws.dst = lws.id and lws.id not in (select WsId from @tblWs)
		insert into @tblWs (WsId)
			select distinct lws.id
			from LanguageProject_VernacularWritingSystems cvws
			join LgWritingSystem lws on cvws.dst = lws.id and lws.id not in (select WsId from @tblWs)
	end
	--( 0xfffffffa = -6 = First string from a) ordered checked vernacular writing systems 
	-- b) ordered checked analysis writing systems, c) any remaining vernacular writing systems, 
	-- d) any remaining analysis writing systems or stars if none of the above.
	else if @Ws = 0xfffffffa begin
		insert into @tblWs (WsId)
			select lws.id
			from LanguageProject_CurrentVernacularWritingSystems cvws
			join LgWritingSystem lws on cvws.dst = lws.id
			order by cvws.Ord
		insert into @tblWs (WsId)
			select lws.id
			from LanguageProject_CurrentAnalysisWritingSystems caws
			join LgWritingSystem lws on caws.dst = lws.id
			where lws.id not in (select WsId from @tblWs)
			order by caws.Ord
		insert into @tblWs (WsId)
			select distinct lws.id
			from LanguageProject_VernacularWritingSystems cvws
			join LgWritingSystem lws on cvws.dst = lws.id and lws.id not in (select WsId from @tblWs)
		insert into @tblWs (WsId)
			select distinct lws.id
			from LanguageProject_AnalysisWritingSystems caws
			join LgWritingSystem lws on caws.dst = lws.id and lws.id not in (select WsId from @tblWs)
	end
	else -- Hard coded value
		insert into @tblWs (WsId) Values(@Ws)

	-- Now that we have the desired writing systems in @tblWs, we can return the desired information.
	select
		o.ObjId,
		(select top 1 isnull(ca.[txt], '***') + ' - ' + isnull(cn.[txt], '***')
			from LgWritingSystem lws 
			left outer join CmPossibility_Name cn  on cn.[ws] = lws.[Id] and cn.[Obj] = o.[objId]
			left outer join CmPossibility_Abbreviation ca  on ca.[ws] = lws.[Id] and ca.[Obj] = o.[objId]
			join @tblWs wstbl on wstbl.WsId = lws.id
			order by (
				select [Ord] = CASE 
					WHEN cn.[txt] IS NOT NULL THEN wstbl.[ord]
					WHEN ca.[txt] IS NOT NULL THEN wstbl.[ord] + 9000
					ELSE wstbl.[Ord] + 99000
					END)),
		isnull((select top 1 lws.id
			from LgWritingSystem lws 
			left outer join CmPossibility_Name cn  on cn.[ws] = lws.[Id] and cn.[Obj] = o.[objId]
			left outer join CmPossibility_Abbreviation ca  on ca.[ws] = lws.[Id] and ca.[Obj] = o.[objId]
			join @tblWs wstbl on wstbl.WsId = lws.id
			order by (
				select [Ord] = CASE 
					WHEN cn.[txt] IS NOT NULL THEN wstbl.[ord]
					WHEN ca.[txt] IS NOT NULL THEN wstbl.[ord] + 9000
					ELSE wstbl.[Ord] + 99000
					END)
			), (select top 1 WsId from @tblws)),
		o.OrdKey, cp.ForeColor, cp.BackColor, cp.UnderColor, cp.UnderStyle
	from @tblObjInfo o
		left outer join CmPossibility cp  on cp.[id] = o.[objId]
	order by o.OrdKey

	return @retval
go

-----------------------------------------------------------------------------------------
-- Description: retrieves the possibilities and their abbreviations of a specified possibility list
--    that have a specific keyword in their names
-- Parameters: 
--    @ObjId=the object Id of the possibility list;
--    @Ws=the writing system;
--    @sKeyword=the keyword to search for
-- Returns: 0 if successful, otherwise an error code

-- ***** TODO: This is not correct. It doesn't handle kwsVernAnals & kwsAnalVerns, and might possibly
-- have other problems that we solved in GetPossibilities. However, this whole procedure will
-- need to be updated before release to do proper matching based on proper Unicode algorithms,
-- so we aren't fixing this at this tiem.

if object_id('GetPossKeyword') is not null begin
	print 'removing proc GetPossKeyword'
	drop proc [GetPossKeyword]
end
go
print 'creating proc GetPossKeyword'
go

create proc [GetPossKeyword]
	@ObjId int,
	@Ws int,
	@sKeyword nvarchar(250)
as
	declare @retval int

	-- get all of the possibilities owned by the specified possibility list object
	
	declare @tblObjInfo table (
		[ObjId]	int not null,
		[ObjClass] int null,
		[InheritDepth] int null default(0),
		[OwnerDepth] int null default(0),
		[RelObjId] int null,
		[RelObjClass] int null,
		[RelObjField] int null,
		[RelOrder] int null,
		[RelType] int null,
		[OrdKey] varbinary(250)	null default(0))


	insert into @tblObjInfo
		select * from fnGetOwnedObjects$(@ObjId, null, 176160768, 1, 0, 1, null, 1)
	
	-- Fudge this for now so it doesn't crash.
	if @Ws = 0xffffffff or @Ws = 0xfffffffd or @Ws = 0xfffffffb
		
		--( To avoid seeing stars, send a "magic" writing system of 0xffffffff. 
		--( This will cause the query to return the first non-null string.
		--( Priority is givin to encodings with the highest order.
		
		select
			o.ObjId,
			isnull((select top 1 txt
				from CmPossibility_Name cn 
				left outer join LgWritingSystem le  on le.[Id] = cn.[ws]
				left outer join LanguageProject_AnalysisWritingSystems lpaws  on lpaws.[dst] = le.[id]
				left outer join LanguageProject_CurrentAnalysisWritingSystems lpcaws  on lpcaws.[dst] = lpaws.[dst]
				where cn.[Obj] = o.[objId] and cn.[Txt] like '%' + @sKeyword + '%'
				order by isnull(lpcaws.[ord], 99999)), '***'),
			isnull((select top 1 txt
				from CmPossibility_Abbreviation ca 
				left outer join LgWritingSystem le  on le.[Id] = ca.[ws]
				left outer join LanguageProject_AnalysisWritingSystems lpaws  on lpaws.[dst] = le.[id]
				left outer join LanguageProject_CurrentAnalysisWritingSystems lpcaws  on lpcaws.[dst] = lpaws.[dst]
				where ca.[Obj] = o.[objId]
				order by isnull(lpcaws.[ord], 99999)), '***'),
			o.OrdKey
		from @tblObjInfo o
		where o.[ObjClass] = 7  -- CmPossibility
		order by o.OrdKey
		
	else if @Ws = 0xfffffffe or @Ws = 0xfffffffc or @Ws = 0xfffffffa
		
		--( To avoid seeing stars, send a "magic" writing system of 0xfffffffe. 
		--( This will cause the query to return the first non-null string.
		--( Priority is givin to encodings with the highest order.
		
		select
			o.ObjId,
			isnull((select top 1 txt
				from CmPossibility_Name cn 
				left outer join LgWritingSystem le  on le.[Id] = cn.[ws]
				left outer join LanguageProject_VernacularWritingSystems lpvws  on lpvws.[dst] = le.[id]
				left outer join LanguageProject_CurrentVernacularWritingSystems lpcvws  on lpcvws.[dst] = lpvws.[dst]
				where cn.[Obj] = o.[objId] and cn.[Txt] like '%' + @sKeyword + '%'
				order by isnull(lpcvws.[ord], 99999)), '***'),
			isnull((select top 1 txt
				from CmPossibility_Abbreviation ca 
				left outer join LgWritingSystem le  on le.[Id] = ca.[ws]
				left outer join LanguageProject_VernacularWritingSystems lpvws  on lpvws.[dst] = le.[id]
				left outer join LanguageProject_CurrentVernacularWritingSystems lpcvws  on lpcvws.[dst] = lpvws.[dst]
				where ca.[Obj] = o.[objId]
				order by isnull(lpcvws.[ord], 99999)), '***'),
			o.OrdKey
		from @tblObjInfo o
		where o.[ObjClass] = 7  -- CmPossibility
		order by o.OrdKey
		
	else
		select	o.ObjId, isnull(cn.txt, '***'), isnull(ca.txt, '***'), o.OrdKey
			from @tblObjInfo o
				left outer join [CmPossibility_Name] cn 
					on cn.[Obj] = o.[ObjId] and cn.[Ws] = @Ws
				left outer join [CmPossibility_Abbreviation] ca 
					on ca.[Obj] = o.[ObjId] and ca.[Ws] = @Ws
			where o.[ObjClass] = 7  -- CmPossibility
				and cn.[Txt] like '%' + @sKeyword + '%'
			order by o.OrdKey

	return @retval
go






















if object_id('GetTagInfo$') is not null begin
	print 'removing procedure GetTagInfo$'
	drop proc [GetTagInfo$]
end
go
print 'creating proc GetTagInfo$'
go

create proc GetTagInfo$
	@iOwnerId int,
	@iWritingSystem int
as
	
	declare @fIsNocountOn int
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on
	
	-- TODO (SteveM) This needs to be fixed to handle 0xfffffffb and 0xfffffffa properly.
	--( if "magic" writing system is for analysis encodings
	if @iWritingSystem = 0xffffffff or @iWritingSystem = 0xfffffffd or @iWritingSystem = 0xfffffffb
		select 
			[co].[Guid$],
			[opi].[Dst],
			isnull((select top 1 [ca].[txt]
				from CmPossibility_Abbreviation ca 
				left outer join LgWritingSystem le 
					on le.[Id] = ca.[ws]
				left outer join LanguageProject_AnalysisWritingSystems lpaws 
					on lpaws.[dst] = le.[id]
				left outer join LanguageProject_CurrentAnalysisWritingSystems lpcaws 
					on lpcaws.[dst] = lpaws.[dst]
				where ca.[Obj] = [opi].[Dst]
				order by isnull(lpcaws.[ord], 99999)), '***'),
			isnull((select top 1 [cn].[txt]
				from CmPossibility_Name cn 
				left outer join LgWritingSystem le 
					on le.[Id] = cn.[ws]
				left outer join LanguageProject_AnalysisWritingSystems lpaws 
					on lpaws.[dst] = le.[id]
				left outer join LanguageProject_CurrentAnalysisWritingSystems lpcaws 
					on lpcaws.[dst] = lpaws.[dst]
				where cn.[Obj] = [opi].[Dst]
				order by isnull(lpcaws.[ord], 99999)), '***'),
			[cp].[ForeColor],
			[cp].[BackColor],
			[cp].[UnderColor],
			[cp].[UnderStyle],
			[cp].[Hidden]
		from CmOverlay_PossItems [opi] 
			join CmPossibility [cp]  on [cp].[id] = [opi].[Dst]
			join CmObject [co]  on [co].[id] = [cp].[id]
		where [opi].[Src] = @iOwnerId
		order by [opi].[Dst]
	
	--( if "magic" writing system is for vernacular encodings
	else if @iWritingSystem = 0xfffffffe or @iWritingSystem = 0xfffffffc or @iWritingSystem = 0xfffffffa
		select 
			[co].[Guid$],
			[opi].[Dst],
			isnull((select top 1 txt
				from CmPossibility_Abbreviation ca 
				left outer join LgWritingSystem le 
					on le.[Id] = ca.[ws]
				left outer join LanguageProject_VernacularWritingSystems lpvws 
					on lpvws.[dst] = le.[id]
				left outer join LanguageProject_CurrentVernacularWritingSystems lpcvws 
					on lpcvws.[dst] = lpvws.[dst]
				where ca.[Obj] = [opi].[Dst]
				order by isnull(lpcvws.[ord], 99999)), '***'),
			isnull((select top 1 txt
				from CmPossibility_Name cn 
				left outer join LgWritingSystem le 
					on le.[Id] = cn.[ws]
				left outer join LanguageProject_VernacularWritingSystems lpvws 
					on lpvws.[dst] = le.[id]
				left outer join LanguageProject_CurrentVernacularWritingSystems lpcvws 
					on lpcvws.[dst] = lpvws.[dst]
				where cn.[Obj] = [opi].[Dst]
				order by isnull(lpcvws.[ord], 99999)), '***'),
			[cp].[ForeColor],
			[cp].[BackColor],
			[cp].[UnderColor],
			[cp].[UnderStyle],
			[cp].[Hidden]
		from CmOverlay_PossItems [opi] 
			join CmPossibility [cp]  on [cp].[id] = [opi].[Dst]
			join CmObject [co]  on [co].[id] = [cp].[id]
		where [opi].[Src] = @iOwnerId
		order by [opi].[Dst]

	--( if one particular writing system is wanted
	else
		select 
			[co].[Guid$],
			[opi].[Dst],
			isnull([ca].[txt], '***'),
			isnull([cn].[txt], '***'),
			[cp].[ForeColor],
			[cp].[BackColor],
			[cp].[UnderColor],
			[cp].[UnderStyle],
			[cp].[Hidden]
		from CmOverlay_PossItems [opi] 
			join CmPossibility [cp]  on [cp].[id] = [opi].[Dst]
			join CmObject [co]  on [co].[id] = [cp].[id]
			left outer join CmPossibility_Abbreviation [ca] 
				on [ca].[Obj] = [opi].[Dst] and [ca].[ws] = @iWritingSystem
			left outer join CmPossibility_Name cn 
				on [cn].[Obj] = [opi].[Dst] and [cn].[ws] = @iWritingSystem
		where [opi].[Src] = @iOwnerId
		order by [opi].[Dst]
		
	--( if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

LFail: 
	--( if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

go


















if object_id('[fnGetColumnDef$]') is not null begin
	print 'removing function fnGetColumnDef$'
	drop function [fnGetColumnDef$]
end
go
print 'creating function fnGetColumnDef$'
go
create function [fnGetColumnDef$] (@nFieldType int)
returns nvarchar(1000)
as
begin
	return case @nFieldType
			when 1 then N'bit = 0'					-- Boolean
			when 2 then N'int = 0'					-- Integer
			when 3 then N'decimal(28,4) = 0'		-- Numeric
			when 4 then N'float = 0.0'				-- Float
			when 5 then N'datetime = null'			-- Time
			when 6 then N'uniqueidentifier = null'	-- Guid
			when 7 then N'image = null'				-- Image
			when 8 then N'int = 0'					-- GenDate
			when 9 then N'varbinary(8000) = null'	-- Binary
			when 13 then N'nvarchar(4000) = null'	-- String
			when 15 then N'nvarchar(4000) = null'	-- Unicode
			when 17 then N'ntext = null'			-- BigString
			when 19 then N'ntext = null'			-- BigUnicode
		end
end
go














if object_id('[DefineCreateProc$]') is not null begin
	print 'removing proc DefineCreateProc$'
	drop proc [DefineCreateProc$]
end
go
print 'creating proc DefineCreateProc$'
go
create proc [DefineCreateProc$]
	@clid int
as
	declare @Err int, @fIsNocountOn int
	declare @sDynSQL1 nvarchar(4000), @sDynSQL2 nvarchar(4000), @sDynSQL3 nvarchar(4000), 
		@sDynSQL4 nvarchar(4000), @sDynSQL5 nvarchar(4000), @sDynSQLParamList nvarchar(4000)
	declare @sValuesList nvarchar(1000)
	declare @fAbs tinyint, @sClass sysname, @sProcName sysname
	declare @sFieldName sysname, @nFieldType int, @flid int,
		@sFieldList nvarchar(4000), @sXMLTableDef nvarchar(4000)
	declare @sInheritClassName sysname, @nInheritClid int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- validate the class
	select	@fAbs = [Abstract], 
		@sClass = [Name] 
	from	[Class$] 
	where	[Id] = @clid
	if @fAbs is null begin
		raiserror('Invalid class: clid=%d', 16, 1, @clid)
		set @Err = 50001
		goto LCleanUp
	end
	if @fAbs <> 0 begin
		raiserror('Cannot create procedure for abstract class %s', 16, 1, @sClass)
		set @Err = 50002
		goto LCleanUp
	end

	set @sProcName = N'CreateObject_' + @sClass

	-- if an old procedure exists remove it
	if exists ( 
		select	* 
		from	sysobjects 
		where	type = 'P' 
			and name = @sProcName 
		) begin 
		set @sDynSQL1 = N'drop proc '+@sProcName
		exec (@sDynSQL1)
	end

	--
	-- build the parameter list and table insert statements
	--
	
	set @sDynSQL3=N''
	set @sDynSQL4=N''
	set @sDynSQLParamList=N''

	-- create a cursor to loop through the base classes and class
	declare curClassInheritPath cursor local fast_forward for
	select	c.[Name], c.[Id]
	from	[ClassPar$] cp join [Class$] c on cp.[Dst] = c.[Id]
	where	cp.[Src] = @clid
		and cp.[Dst] > 0
	order by cp.[Depth] desc
	
	open curClassInheritPath
	fetch curClassInheritPath into @sInheritClassName, @nInheritClid

	while @@fetch_status = 0 begin

		set @sValuesList=''

		-- create a cursor to assemble the field list
		declare curFieldList cursor local fast_forward for
		select	[Name], [Type], [Id]
		from	[Field$]
		where	[Class] = @nInheritClid 
			and [Name] <> 'Id'
			-- do not include MultiString type columns nor relationship, e.g. reference sequence,
			--	type columns because these are all stored in tables external to the actual 
			--	class table
			and [Type] not in (23, 24, 25, 26, 27, 28)
		order by [Id]

		open curFieldList
		fetch curFieldList into @sFieldName, @nFieldType, @flid

		set @sFieldList = N''
		set @sXMLTableDef = N''
		while @@fetch_status = 0 begin
			if @nFieldType = 14 begin -- MultiStr$
 				set @sDynSQLParamList = @sDynSQLParamList + char(9) +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_ws int = null' + N', ' +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_txt nvarchar(4000) = null' + N', ' +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_fmt varbinary(8000) = null' + N', ' + char(13)
				set @sDynSQL3 = @sDynSQL3 + char(9) +
					N'if @' + @sInheritClassName + N'_' + @sFieldName + N'_txt is not null begin' + char(13) +
					char(9) + char(9) + N'insert into [MultiStr$] with (rowlock) ([Flid],[Obj],[Ws],[Txt],[Fmt]) ' + char(13) + 
					char(9) + char(9) + N'values (' + convert(nvarchar(11), @flid)+ N',@ObjId,' +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_ws' + N',' +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_txt' + N',' +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_fmt)'
				set @sDynSQL3 = @sDynSQL3 + 
N'
		set @Err = @@error
		if @Err <> 0 goto LCleanUp
	end
'
			end
			else if @nFieldType = 16 begin -- MultiTxt$
 				set @sDynSQLParamList = @sDynSQLParamList + char(9) +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_ws int = null' + N', ' +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_txt nvarchar(4000) = null' + N', ' + char(13)
				set @sDynSQL3 = @sDynSQL3 + char(9) +
					N'if @' + @sInheritClassName + N'_' + @sFieldName + N'_txt is not null begin' + char(13)
				SET @sDynSQL3 = @sDynSQL3 + CHAR(9) + CHAR(9) + 
					N'INSERT INTO ' + @sInheritClassName + N'_' + @sFieldName + 
					N' WITH (ROWLOCK) (Obj, Ws, Txt)' + CHAR(13) +
					char(9) + char(9) + N'values (@ObjId,' +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_ws' + ',' +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_txt)'
				set @sDynSQL3 = @sDynSQL3 + 
N'
		set @Err = @@error
		if @Err <> 0 goto LCleanUp
	end
'
			end
			else if @nFieldType = 18 begin -- MultiBigStr$
 				set @sDynSQLParamList = @sDynSQLParamList + char(9) + 
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_ws int = null' + N', ' +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_txt ntext = null' + N', ' +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_fmt image = null' + N', ' + char(13)
				set @sDynSQL3 = @sDynSQL3 + char(9) +
					N'if @' + @sInheritClassName + N'_' + @sFieldName + N'_txt is not null begin' + char(13) +
					char(9) + char(9) + N'insert into [MultiBigStr$] with (rowlock) ([Flid],[Obj],[Ws],[Txt],[Fmt])' + char(13) + 
					char(9) + char(9) + N'values (' + convert(nvarchar(11), @flid)+ N',@ObjId,' +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_ws' + N',' +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_txt' + N',' +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_fmt)'
				set @sDynSQL3 = @sDynSQL3 + 
N'
		set @Err = @@error
		if @Err <> 0 goto LCleanUp
	end
'
			end
			else if @nFieldType = 20 begin -- MultiBigTxt$
 				set @sDynSQLParamList = @sDynSQLParamList + char(9) +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_ws int = null' + N', ' +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_txt ntext = null' + N', ' + char(13)
				set @sDynSQL3 = @sDynSQL3 + char(9) +
					N'if @' + @sInheritClassName + N'_' + @sFieldName + N'_txt is not null begin' + char(13) +
					char(9) + char(9) + N'insert into [MultiBigTxt$] with (rowlock) ([Flid],[Obj],[Ws],[Txt])' + char(13) + 
					char(9) + char(9) + N'values (' + convert(nvarchar(11), @flid)+ N',@ObjId,' +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_ws' + N',' +
					N'@' + @sInheritClassName + N'_' + @sFieldName + N'_txt)'
				set @sDynSQL3 = @sDynSQL3 + 
N'
		set @Err = @@error
		if @Err <> 0 goto LCleanUp
	end
'
			end	
			else begin
				set @sDynSQLParamList = @sDynSQLParamList + char(9) + N'@' + @sInheritClassName + '_' + @sFieldName + ' ' +
					dbo.fnGetColumnDef$(@nFieldType) + N',' + char(13)
				set @sFieldList = @sFieldList + N',[' + @sFieldName + N']'
				
				if @sValuesList = '' set @sValuesList = N'@' + @sInheritClassName + N'_' + @sFieldName
				else set @sValuesList = @sValuesList + N', @' + @sInheritClassName + N'_' + @sFieldName

				if @nFieldType = 13 or @nFieldType = 17 begin -- String or BigString
					set @sDynSQLParamList = @sDynSQLParamList + char(9) + N'@' + @sInheritClassName + '_' + @sFieldName + '_fmt '
					if @nFieldType = 13 set @sDynSQLParamList = @sDynSQLParamList + 'varbinary(8000) = null,' + char(13)
					else if @nFieldType = 17 set @sDynSQLParamList = @sDynSQLParamList + 'image = null,' + char(13)

					set @sFieldList = @sFieldList + N',[' + @sFieldName + N'_fmt]'
					set @sValuesList = @sValuesList + N', @' + @sInheritClassName + '_' + @sFieldName + '_fmt'
				end

			end
			fetch curFieldList into @sFieldName, @nFieldType, @flid
		end

		close curFieldList
		deallocate curFieldList

		if @sFieldList <> N'' set @sDynSQL4 = @sDynSQL4 + char(13) + char(9) +
				N'insert into ['+@sInheritClassName+N'] ([Id]' + 	@sFieldList + N') ' + char(13) + 
				char(9) + char(9) + N'values (@ObjId, ' + @sValuesList + N')'
		else set @sDynSQL4 = @sDynSQL4 + char(9) + N'insert into ['+@sInheritClassName+N'] with (rowlock) ([Id]) values(@ObjId)'
		set @sDynSQL4 = @sDynSQL4 + char(13) + char(9) + N'set @Err = @@error' + char(13) + char(9) + N'if @Err <> 0 goto LCleanUp' + char(13)

		fetch curClassInheritPath into @sInheritClassName, @nInheritClid
	end
	
	close curClassInheritPath
	deallocate curClassInheritPath
	
	--
	-- build the dynamic SQL strings
	--

		set @sDynSQLParamList =
N'
Create proc ['+@sProcName+N']' + char(13) + @sDynSQLParamList
	set @sDynSQL1 = 
N'	@Owner int = null,
	@OwnFlid int = null,
	@StartObj int = null,
	@NewObjId int output,
	@NewObjGuid uniqueidentifier output,
	@fReturnTimestamp tinyint = 0,
	@NewObjTimestamp int = null output
as
	declare @fIsNocountOn int, @Err int, @nTrnCnt int, @sTranName sysname
	declare @OwnOrd int, @Type int, @ObjId int, @guid uniqueidentifier
	declare @DstClass int, @OwnerClass int, @OwnerFlidClass int

	set @nTrnCnt = null
	set @Type = null
	set @OwnOrd = null
	set @NewObjTimestamp = null

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- validate the new object''s owner arguments
	if @Owner is not null begin
		-- get the type of the @OwnFlid field and validate @OwnFlid as being a valid field
		select	@Type = [Type], @DstClass = [DstCls], @OwnerFlidClass = [Class]
		from	[Field$]
		where	[Id] = @OwnFlid
		if @@rowcount = 0 begin
			raiserror(''Owner field does not exist: OwnFlid=%d'', 16, 1, @OwnFlid)
			set @Err = 50001
			goto LCleanUp
		end
		if @Type not in (23, 25, 27) begin
			raiserror(''OwnFlid is not an owning relationship field: OwnFlid=%d Type=%d'', 16, 1, @Ownflid, @Type)
			set @Err = 50002
			goto LCleanUp
		end

		-- make sure the @OwnFlid field has a relationship with the ' + @sClass + N' class
		if @DstClass <> ' + convert(nvarchar(11), @clid) + N'  begin
			-- check the base classes
			if not exists (
				select	*
				from	[ClassPar$]
				where	[Src] = '+convert(nvarchar(11), @clid) + N' and [Dst] = @DstClass 
			) begin
				raiserror(''OwnFlid does not relate to the ' + @sClass + N' class: OwnFlid=%d'', 16, 1, @OwnFlid)
				set @Err = 50003
				goto LCleanUp
			end
		end

		-- make sure that @OwnFlid is a field of the @Owner class
		select	@OwnerClass = [Class$]
		from	[CmObject] 
		where	[Id] = @Owner
		if @@rowcount = 0 begin
			raiserror(''Owner object does not exist: Owner=%d'', 16, 1, @Owner)
			set @Err = 50004
			goto LCleanUp
		end
		if @OwnerClass <> @OwnerFlidClass begin
			-- check the base classes
			if not exists (
				select	*
				from	[ClassPar$]
				where	[Src] = @ownerClass and [Dst] = @OwnerFlidClass
			) begin
				raiserror(''OwnFlid is not a field of the owner class: Owner=%d, OwnerClass=%d, OwnFlid=%d'', 16, 1, @Owner, @OwnerClass, @OwnFlid)
				set @Err = 50005
				goto LCleanUp
			end
		end
	end

	-- determine if a transaction already exists; if one does then create a savepoint, otherwise create a 
	--	transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = '''+@sProcName+N'_tr'' + convert(varchar(2), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName
'
	set @sDynSQL2 = 
N'
	-- determine if the object is being added to an owning sequence
	if @Type = 27 begin

		-- determine if the objects should be added to the end of the list
		if @StartObj is null begin
			select	@ownOrd = coalesce(max([OwnOrd$])+1, 1)
			from	[CmObject] with (serializable)
			where	[Owner$] = @Owner
				and [OwnFlid$] = @OwnFlid
		end
		else begin
			-- get the ordinal value of the object that is located where the new object is to be inserted
			select	@OwnOrd = [OwnOrd$]
			from	[CmObject] with (repeatableread)
			where	[Id] = @StartObj
			if @OwnOrd is null begin
				raiserror(''The start object does not exist in the owning sequence: Owner=%d, OwnFlid=%d, StartObj=%d'', 16, 1, @Owner, @OwnFlid, @StartObj)
				set @Err = 50006
				goto LCleanUp
			end

			-- increment the ordinal value(s) of the object(s) in the sequence that occur at or after 
			--	the new object(s)
			update	[CmObject] with (serializable)
			set	[OwnOrd$] = [OwnOrd$] + 1
			where	[Owner$] = @Owner
				and [OwnFlid$] = @OwnFlid
				and [OwnOrd$] >= @OwnOrd
		end
	end
	-- determine if the object is being added to an atomic owning relationship
	else if @Type = 23 begin
		-- make sure there isn''t already an object owned by @Owner
		if exists (
			select	*
			from	[CmObject] with 
			where	[Owner$] = @Owner and [OwnFlid$] = @OwnFlid
			) begin
			raiserror(''An object is already owned by the atomic relationship: Owner=%d, OwnFlid=%d'', 16, 1, @Owner, @OwnFlid)
			set @Err = 50007
			goto LCleanUp
		end
	end

	set @guid = newid()
	insert into [CmObject] with (rowlock) ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
		values (@guid, '+convert(nvarchar(11), @clid)+N', @Owner, @OwnFlid, @OwnOrd)
	set @Err = @@error
	set @ObjId = @@identity	
	if @Err <> 0 begin
		raiserror(''SQL Error %d: Unable to create the new object'', 16, 1, @Err)
		goto LCleanUp
	end

'
	set @sDynSQL5 = 
N'	

	-- set the output paramters
	set @NewObjId = @ObjId
	set @NewObjGuid = @guid
	if @fReturnTimestamp = 1 begin
		select	@NewObjTimestamp = [UpdStmp]
		from	[CmObject]
		where	[Id] = @NewObjId
	end

LCleanUp:

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- determine if a transaction or savepoint was created
	if @nTrnCnt is not null begin
		if @Err = 0 begin
			-- if a transaction was created within this procedure commit it
			if @nTrnCnt = 0 commit tran @sTranName 
		end
		else begin
			rollback tran @sTranName 
		end
	end

	return @Err
'

	--
	-- execute the dynamic SQL
	--
	exec (@sDynSQLParamList+@sDynSql1+@sDynSQL2+@sDynSQL3+@sDynSQL4+@sDynSQL5)
	set @Err = @@error
	if @Err <> 0 begin
		raiserror ('SQL Error %d: Unable to create procedure for class %s', 16, 1, @Err, @sClass)
		goto LCleanUp
	end	

LCleanUp:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	return @Err
go
















if object_id('CreateObject$') is not null begin
	print 'removing proc CreateObject$'
	drop proc [CreateObject$]
end
go
print 'creating proc CreateObject$'
go
create proc [CreateObject$]
	@clid int,
	@id int output,
	@guid uniqueidentifier output
as
	declare @err int, @tc int, @tn varchar(10) set @tc = @@trancount set @tn = 'tr' + convert(varchar(8), @@nestlevel) if @tc = 0 begin tran @tn else save tran @tn

	declare @ObjId int
	declare @depth int
	declare @sSql nvarchar(400), @sTbl nvarchar(100), @sId nvarchar(11)
	declare @fAbs bit

	if @guid is null set @guid = NewId()

	select @fAbs = [Abstract], @sTbl = [Name] from [Class$] where [Id] = @clid
	if @@rowcount <> 1 begin
		RaisError('Bad Class ID: %d', 16, 1, @clid)
		set @err = @@error
		goto LFail
	end

	if @fAbs <> 0 begin
		RaisError('Cannot instantiate abstract class: @s', 16, 1, @sTbl)
		set @err = @@error
		goto LFail
	end

	select @depth = [Depth] from [ClassPar$] where [Src] = @clid and [Dst] = 0
	if @@rowcount <> 1 begin
		RaisError('Bad Class Id or corrupt ClassPar$ table: %d', 16, 1, @clid)
		set @err = @@error
		goto LFail
	end

	-- if an Id was supplied assume that the IDENTITY_INSERT setting is turned on and the incoming Id is legal
	if @id is null begin
		insert into [CmObject] ([Guid$], [Class$], [OwnOrd$])
			values(@guid, @clid, null)
		if @@error <> 0 begin set @err = @@error goto LFail end

		set @id = @@identity
	end
	else begin
		insert into [CmObject] ([Guid$], [Id], [Class$], [OwnOrd$])
			values(@guid, @id, @clid, null)
		if @@error <> 0 begin set @err = @@error goto LFail end
	end
	set @sId = convert(nvarchar(11), @id)

	while @depth > 0 begin
		set @depth = @depth - 1

		select @sTbl = c.[Name]
		from [ClassPar$] cp join [Class$] c on c.[Id] = cp.[Dst]
		where cp.[Src] = @clid and cp.[Depth] = @depth

		if @@rowcount <> 1 begin
			RaisError('Corrupt ClassPar$ table: %d', 16, 1, @clid)
			set @err = @@error
			goto LFail
		end

		set @sSql = 'insert into [' + @sTbl + '] with (rowlock) ([Id]) values(' + @sId + ')'
		exec (@sSql)
		if @@error <> 0 begin set @err = @@error goto LFail end
	end

	if @tc = 0 commit tran @tn return 0 LFail: rollback tran @tn return @err
go

















if object_id('CreateOwnedObject$') is not null begin
	print 'removing proc CreateOwnedObject$'
	drop proc CreateOwnedObject$
end
go
print 'creating proc CreateOwnedObject$'
go
create proc [CreateOwnedObject$]
	@clid int,
	@id int output,
	@guid uniqueidentifier output,
	@owner int,
	@ownFlid int,
	@type int,			-- type of field (atomic, collection, or sequence)
	@StartObj int = null,		-- object to insert before - owned sequences
	@fGenerateResults tinyint = 0,	-- default to not generating results
	@nNumObjects int = 1,		-- number of objects to create
	@uid uniqueidentifier = null output
as
	declare @err int, @nTrnCnt int, @sTranName varchar(50) 
	declare @depth int, @fAbs bit
	declare @sDynSql nvarchar(4000), @sTbl sysname, @sId varchar(11)
	declare @OwnOrd int
	declare @i int, @currId int, @currOrd int, @currListOrd int
	declare	@fIsNocountOn int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- validate the class
	select	@fAbs = [Abstract], 
		@sTbl = [Name] 
	from	[Class$] 
	where	[Id] = @clid
	if @fAbs <> 0 begin
		RaisError('Cannot instantiate abstract class: %s', 16, 1, @sTbl)
		return 50001
	end
	-- get the inheritance depth
	select	@depth = [Depth] 
	from	[ClassPar$] 
	where	[Src] = @clid 
		and [Dst] = 0

	-- determine if a transaction already exists; if one does then create a savepoint, otherwise create a 
	--	transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'CreateOwnedObject$_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName

	-- determine if the object is being added to a sequence
	if @type = 27 begin

		-- determine if the object(s) should be added to the end of the sequence
		if @StartObj is null begin
			select	@ownOrd = coalesce(max([OwnOrd$])+1, 1)
			from	[CmObject] with (serializable)
			where	[Owner$] = @Owner
				and [OwnFlid$] = @OwnFlid
		end
		else begin
			-- get the ordinal value of the object that is located where the new object is to be inserted
			select	@OwnOrd = [OwnOrd$]
			from	[CmObject] with (repeatableread)
			where	[Id] = @StartObj

			-- increment the ordinal value(s) of the object(s) in the sequence that occur at or after the new object(s)
			update	[CmObject] with (serializable)
			set 	[OwnOrd$]=[OwnOrd$]+@nNumObjects
			where 	[Owner$] = @owner
				and [OwnFlid$] = @OwnFlid
				and [OwnOrd$] >= @OwnOrd
		end
	end

	-- determine if more than one object should be created; if more than one object is created the created objects IDs are stored
	--	in the ObjListTbl$ table so that the calling procedure/application can determine the IDs (the calling procedure or
	--	application is responsible for cleaning up the ObjListTlb$), otherwise if only one object is created the new object's
	--	ID is passed back to the calling procedure/application through output parameters -- the two approaches are warranted
	--	because it is ideal to avoid using the ObjListTbl$ if only one object is being created, also this maintains backward
	--	compatibility with existing code
	if @nNumObjects > 1 begin

		set @uid = NewId()

		set @i = 0
		set @currListOrd = coalesce(@ownOrd, 0)

		-- if an Id was supplied assume that the IDENTITY_INSERT setting is turned on and the incoming Id is legal
		if @id is not null begin
			while @i < @nNumObjects begin
				set @currId = @id + @i
				set @currOrd = @ownOrd + @i

				insert into [CmObject] ([Guid$], [Id], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
					values(newid(), @currId, @clid, @owner, @ownFlid, @currOrd)
				set @err = @@error
				if @Err <> 0 begin 
					raiserror('Unable to create object: ID=%d, Class=%d, Owner=%d, OwnFlid=%d, OwnOrd=%d', 16, 1,
							@currId, @clid, @owner, @ownFlid, @currOrd)
					goto LFail 
				end

				-- add the new object to the list of created objects
				insert into ObjListTbl$ with (rowlock) (uid, ObjId, Ord, Class) 
					values (@uid, @id + @i, @currListOrd + @i, @clid)

				set @i = @i + 1
			end
		end
		else begin
			while @i < @nNumObjects begin
				set @currOrd = @ownOrd + @i
				
				insert into [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
					values(newid(), @clid, @owner, @ownFlid, @currOrd)
				set @err = @@error 
				if @Err <> 0 begin 
					raiserror('Unable to create object: Class=%d, Owner=%d, OwnFlid=%d, OwnOrd=%d', 16, 1,
							@clid, @owner, @ownFlid, @currOrd)
					goto LFail 
				end
				set @id = @@identity

				-- add the new object to the list of created objects
				insert into ObjListTbl$ with (rowlock) (uid, ObjId, Ord, Class) 
					values (@uid, @id, @currListOrd + @i, @clid)
				set @i = @i + 1
			end
		end

		-- insert the objects' Ids into all of the base classes
		while @depth > 0 begin
			set @depth = @depth - 1

			select	@sTbl = c.[Name]
			from	[ClassPar$] cp join [Class$] c on c.[Id] = cp.[Dst]
			where	cp.[Src] = @clid 
				and cp.[Depth] = @depth
			set @sDynSql =  'insert into [' + @sTbl + '] ([Id]) '+
					'select [ObjId] ' +
					'from [ObjListTbl$]  '+
					'where [uid] = '''+convert(varchar(250), @uid)+''''
			exec (@sDynSql)
			set @err = @@error 
			if @Err <> 0 begin 
				raiserror('Unable to add rows to the base table %s', 16, 1, @sTbl) 
				goto LFail 
			end
		end		

		if @fGenerateResults = 1 begin
			select	ObjId
			from	ObjListTbl$ 
			where	uid=@uid
			order by Ord
		end
	end
	else begin
		if @guid is null set @guid = NewId()

		-- if an Id was supplied assume that the IDENTITY_INSERT setting is turned on and the incoming Id is legal
		if @id is not null begin
			insert into [CmObject] ([Guid$], [Id], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
				values(@guid, @id, @clid, @owner, @ownFlid, @ownOrd)
			set @err = @@error 
			if @Err <> 0 goto LFail 
		end
		else begin
			insert into [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
				values(@guid, @clid, @owner, @ownFlid, @ownOrd)
			set @err = @@error 
			if @Err <> 0 goto LFail 
			set @id = @@identity
		end

		-- insert the object's Id into all of the base classes
		set @sId = convert(varchar(11), @id)
		while @depth > 0 begin
			set @depth = @depth - 1

			select	@sTbl = c.[Name]
			from	[ClassPar$] cp join [Class$] c on c.[Id] = cp.[Dst]
			where	cp.[Src] = @clid 
				and cp.[Depth] = @depth
			if @@rowcount <> 1 begin
				raiserror('Corrupt ClassPar$ table: %d', 16, 1, @clid)
				set @err = @@error
				goto LFail
			end
	
			set @sDynSql = 'insert into [' + @sTbl + '] with (rowlock) ([Id]) values (' + @sId + ')'
			exec (@sDynSql)
			set @err = @@error 
			if @Err <> 0 begin 
				raiserror('Unable to add a row to the base table %s: ID=%s', 16, 1, @sTbl, @sId) 
				goto LFail 
			end
		end

		if @fGenerateResults = 1 begin
			select @id [Id], @guid [Guid]
		end	
	end

	-- update the date/time of the owner
	UPDATE [CmObject] SET [UpdDttm] = GetDate()
		FROM [CmObject] WHERE [Id] = @owner
	
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	-- if a transaction was created within this procedure commit it
	if @nTrnCnt = 0 commit tran @sTranName 
	return 0 

LFail: 
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	rollback tran @sTranName 
	return @err
go













IF OBJECT_ID('CopyObj$') IS NOT NULL BEGIN
   	PRINT 'removing procedure CopyObj$'
   	DROP PROC [CopyObj$]
END
GO
PRINT 'creating procedure CopyObj$'
GO
CREATE PROCEDURE [CopyObj$]
   	@nTopSourceObjId INT,  	--( the top owning object
   	@nTopDestOwnerId INT,	--( The ID of the owner of the top object we're creating here
   	@nTopDestOwnerFlid INT,		--( The owning field ID of the top object we're creating here
   	@nTopDestObjId INT OUTPUT	--( the ID for the new object we're creating here
AS
   
   	DECLARE 
   		@nSourceObjId INT,
   		@nOwnerID INT,
   		@nOwnerFieldId INT, --(owner flid
   		@nRelObjId INT,
   		@nRelObjFieldId INT,  --( related object flid
   		@guidNew UNIQUEIDENTIFIER,
   		@nFirstOuterLoop TINYINT,
   		@nDestObjId INT,
   		@nOwnerDepth INT,
   		@nInheritDepth INT,
   		@nClass INT,
   		@nvcClassName NVARCHAR(100),
   		@nvcQuery NVARCHAR(4000)
   	
   	DECLARE
   		@nvcFieldsList NVARCHAR(4000),
   		@nvcValuesList NVARCHAR(4000),
   		@nColumn INT,
   		@sysColumn SYSNAME,
   		@nFlid INT,
   		@nType INT,
   		@nSourceClassId INT,
   		@nDestClassId INT,
   		@nvcFieldName NVARCHAR(100),
  		@nvcTableName NVARCHAR(100)
	
   	CREATE TABLE #SourceObjs (
   		[ObjId]			INT		not null,
   		[ObjClass]		INT		null,
   		[InheritDepth]	INT		null		DEFAULT(0),
   		[OwnerDepth]	INT		null		DEFAULT(0),
   		[RelObjId]		INT		null,
   		[RelObjClass]	INT		null,
   		[RelObjField]	INT		null,
   		[RelOrder]		INT		null,
   		[RelType]		INT		null,
   		[OrdKey]		VARBINARY(250)	null	DEFAULT(0),
   		[ClassName]		NVARCHAR(100),
   		[DestinationID]	INT		NULL)
   	
   	SET @nFirstOuterLoop = 1
   	SET @nOwnerId = @nTopDestOwnerId
   	SET @nOwnerFieldId = @nTopDestOwnerFlid
   	
   	--== Get the Object Tree ==--
   	
   	INSERT INTO #SourceObjs
   		SELECT oo.*, c.[Name], NULL
   		FROM dbo.fnGetOwnedObjects$(@nTopSourceObjId, NULL, NULL, 1, 0, 1, null, 1) oo
   		JOIN Class$ c ON c.[Id] = oo.[ObjClass]
   		ORDER BY [OwnerDepth], [InheritDepth] DESC, [ObjClass]
   	
   	--== Create CmObject Records ==--
   	
   	--( Create all the CmObjects for all the objects copied
   	
   	DECLARE curNewCmObjects CURSOR FAST_FORWARD FOR
  		SELECT DISTINCT [ObjId], [RelObjId], [RelObjField] FROM #SourceObjs
	
   	OPEN curNewCmObjects 
   	FETCH curNewCmObjects INTO @nSourceObjId, @nRelObjId, @nRelObjFieldId
   	WHILE @@FETCH_STATUS = 0 BEGIN
   		SET @guidNew = NEWID()
   		
   		INSERT INTO CmObject WITH (ROWLOCK) ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
   			SELECT @guidNew, [Class$], @nOwnerId, @nOwnerFieldId, [OwnOrd$]
   			FROM CmObject
   			WHERE [Id] = @nSourceObjId
   		
   		SET @nDestObjId = @@IDENTITY
   		
   		UPDATE #SourceObjs SET [DestinationID] = @nDestObjId WHERE [ObjId] = @nSourceObjID
   		
   		--== Copy records in "multi" string tables ==--
		
		--( Tables of the former MultiTxt$ table are now  set in a separate loop.
		
   		INSERT INTO MultiStr$ WITH (ROWLOCK) ([Flid], [Obj], [Ws], [Txt], [Fmt])
   		SELECT [Flid], @nDestObjID, [WS], [Txt], [Fmt]
   		FROM MultiStr$  
   		WHERE [Obj] = @nSourceObjId
   		
   		--( As of this writing, MultiBigTxt$ is not used anywhere in the conceptual
   		--( model, and it is impossible to use it through the interface.
   		
   		INSERT INTO MultiBigTxt$ WITH (ROWLOCK) ([Flid], [Obj], [Ws], [Txt])
   		SELECT [Flid], @nDestObjID, [WS], [Txt]
   		FROM MultiBigTxt$ 
   		WHERE [Obj] = @nSourceObjId
   		
   		INSERT INTO MultiBigStr$ WITH (ROWLOCK) ([Flid], [Obj], [Ws], [Txt], [Fmt])
   		SELECT [Flid], @nDestObjID, [WS], [Txt], [Fmt]
   		FROM MultiBigStr$ 
   		WHERE [Obj] = @nSourceObjId
   		
   		--( If the object ID = the top owning object ID
   		IF @nFirstOuterLoop = 1
   			SET @nTopDestObjId = @nDestObjID --( sets the output parameter
   		
   		SET @nFirstOuterLoop = 0
   		
   		--( This fetch is different than the one at the top of the loop!
  		FETCH curNewCmObjects INTO @nSourceObjId, @nRelObjId, @nOwnerFieldId
		
   		SELECT @nOwnerId = [DestinationId] FROM #SourceObjs WHERE ObjId = @nRelObjId
   	END
   	CLOSE curNewCmObjects
   	DEALLOCATE curNewCmObjects
   	
   	--== Create All Other Records ==--
   	
   	DECLARE curRecs CURSOR FAST_FORWARD FOR 
   		SELECT DISTINCT [OwnerDepth], [InheritDepth], [ObjClass], [ClassName]
   		FROM #SourceObjs
   		ORDER BY [OwnerDepth], [InheritDepth] DESC, [ObjClass]
   	
   	OPEN curRecs
   	FETCH curRecs INTO 	@nOwnerDepth, @nInheritDepth, @nClass, @nvcClassName
   	WHILE @@FETCH_STATUS = 0 BEGIN
   		SET @nvcFieldsList = N''
   		SET @nvcValuesList = N''
   		SET @nColumn = 1
   		SET @sysColumn = COL_NAME(OBJECT_ID(@nvcClassName), @nColumn)
   		WHILE @sysColumn IS NOT NULL BEGIN
   			IF @nColumn > 1 BEGIN --( not the first time in loop
   				SET @nvcFieldsList = @nvcFieldsList + N', '
   				SET @nvcValuesList = @nvcValuesList + N', '
   			END
   			SET @nvcFieldName = N'[' + UPPER(@sysColumn) + N']'
   			
   			--( Field list for insert
   			SET @nvcFieldsList = @nvcFieldsList + @nvcFieldName
   			
   			--( Vales to put into those fields
   			IF @nvcFieldName = '[ID]'
   				SET @nvcValuesList = @nvcValuesList + N' so.[DestinationId] '
   			ELSE IF @nvcFieldName = N'[DATECREATED]' OR @nvcFieldName = N'[DATEMODIFIED]'
   				SET @nvcValuesList = @nvcValuesList + N'CURRENT_TIMESTAMP'
   			ELSE
   				SET @nvcValuesList = @nvcValuesList + @nvcFieldName
   			
   			SET @nColumn = @nColumn + 1
   			SET @sysColumn = COL_NAME(OBJECT_ID(@nvcClassName), @nColumn)
   		END
   		
   		SET @nvcQuery = 
   			N'INSERT INTO ' + @nvcClassName + ' WITH (ROWLOCK) (
   				' + @nvcFieldsList + ') 
   			SELECT ' + @nvcValuesList + N'
   			FROM ' + @nvcClassName + ' cn 
   			JOIN #SourceObjs so ON 
   				so.[OwnerDepth] = ' + STR(@nOwnerDepth) + N' AND
   				so.[InheritDepth] = ' + STR(@nInheritDepth) + N' AND
   				so.[ObjClass] = ' + STR(@nClass) + N' AND
   				so.[ObjId] = cn.[Id]'
   		
   		EXEC (@nvcQuery)
		
   		--== Copy References ==--
   		
   		DECLARE curReferences CURSOR LOCAL STATIC FORWARD_ONLY READ_ONLY FOR
   		SELECT f.[Id], f.[Type], f.[Name]
   		FROM Field$ f 
   		WHERE f.[Class] = @nClass AND 
   			(f.[Type] = 26 OR f.[Type] = 28)
   		
   		OPEN curReferences
   		FETCH curReferences INTO @nFlid, @nType, @nvcFieldName
   		WHILE @@FETCH_STATUS = 0 BEGIN
   			
   			SET @nvcQuery = N'INSERT INTO ' + @nvcClassName + N'_' + @nvcFieldName + N' ([Src], [Dst]'
   			
   			IF @nType = 26
   				SET @nvcQuery = @nvcQuery + N') 
   					SELECT DestinationId, r.[Dst] 
   					FROM '
   			ELSE --( IF @nType = 28
   				SET @nvcQuery = @nvcQuery + N', [Ord]) 
   					SELECT DestinationId, r.[Dst], r.[Ord]
   					FROM '
   			
    			SET @nvcQuery = @nvcQuery + @nvcClassName + N'_' + @nvcFieldName + N' r  
     				JOIN #SourceObjs ON 
     					[OwnerDepth] = @nOwnerDepth AND
     					[InheritDepth] =  @nInheritDepth AND
     					[ObjClass] = @nClass AND
     					[ObjId] = r.[Src]'
    			
    			EXEC sp_executesql @nvcQuery,
	   				N'@nOwnerDepth INT, @nInheritDepth INT, @nClass INT', 
   					@nOwnerDepth, @nInheritDepth, @nClass
			
   			FETCH curReferences INTO @nFlid, @nType, @nvcFieldName
   		END
   		CLOSE curReferences
   		DEALLOCATE curReferences
   		
   		FETCH curRecs INTO 	@nOwnerDepth, @nInheritDepth, @nClass, @nvcClassName
   	END
   	CLOSE curRecs
   	DEALLOCATE curRecs
   		
   	--== References to Copied Objects ==--
   	
   	--( objects can point to themselves. For instance, the People list has a 
    	--( researcher that points back to the People list. For copies, this reference
    	--( back to itself needs to have the new object, not the old source object. For
    	--( all other reference properties, the old object will do fine.
   	
   	DECLARE curRefs2CopiedObjs CURSOR LOCAL STATIC FORWARD_ONLY READ_ONLY FOR
   		SELECT DISTINCT c.[Name] + N'_' + f.[Name]
   		FROM Class$ c
   		JOIN Field$ f ON f.[Class] = c.[Id]
   		JOIN #SourceObjs s ON s.[ObjClass] = c.[Id]
   		WHERE f.[Type] = 26 OR f.[Type] = 28
   	
   	OPEN curRefs2CopiedObjs
   	FETCH curRefs2CopiedObjs INTO @nvcTableName
   	WHILE @@FETCH_STATUS = 0 BEGIN
   		SET @nvcQuery = N'UPDATE ' + @nvcTableName + N' 
   			SET [Dst] = #SourceObjs.[DestinationId]
   			FROM ' + @nvcTableName + N', #SourceObjs
   			WHERE ' + @nvcTableName + N'.[Dst] = #SourceObjs.[ObjId]'
   		
  		EXEC sp_executesql @nvcQuery
		
   		FETCH curRefs2CopiedObjs INTO @nvcTableName
   	END
   	CLOSE curRefs2CopiedObjs
   	DEALLOCATE curRefs2CopiedObjs

	--== MultiTxt$ Records ==--
	
	DECLARE curMultiTxt CURSOR FAST_FORWARD FOR 
		SELECT DISTINCT ObjId, ObjClass, ClassName, DestinationId
		FROM #SourceObjs
	
	--( First get the object IDs and their class we're working with
	OPEN curMultiTxt
	FETCH curMultiTxt INTO @nSourceObjId, @nClass, @nvcClassName, @nDestObjId
	WHILE @@FETCH_STATUS = 0 BEGIN
		
		--( Now copy into each of the multitxt fields
		SELECT TOP 1 @nFlid = [Id], @nvcFieldName = [Name]
		FROM Field$
		WHERE Class = @nClass AND Type = 16
		ORDER BY [Id]
		
		WHILE @@ROWCOUNT > 0 BEGIN
			SET @nvcQuery = 
				N'INSERT INTO ' + @nvcClassName + N'_' + @nvcFieldName + N' ' +
				N'WITH (ROWLOCK) (Obj, Ws, Txt)' + CHAR(13) +
				CHAR(9) + N'SELECT @nDestObjId, WS, Txt' + CHAR(13) +
				CHAR(9) + N'FROM ' + @nvcClassName + N'_' + @nvcFieldName + ' ' + CHAR(13) + 
				CHAR(9) + N'WHERE Obj = @nSourceObjId'
			
			EXECUTE sp_executesql @nvcQuery,
				N'@nDestObjId INT, @nSourceObjId INT',
				@nDestObjID, @nSourceObjId
			
			SELECT TOP 1 @nFlid = [Id], @nvcFieldName = [Name]
			FROM Field$
			WHERE [Id] > @nFlid AND Class = @nClass AND Type = 16
			ORDER BY [Id]
		END
		
		FETCH curMultiTxt INTO @nSourceObjId, @nClass, @nvcClassName, @nDestObjId
	END
	CLOSE curMultiTxt
	DEALLOCATE curMultiTxt
		
	DROP TABLE #SourceObjs
GO
































if object_id('DeleteObj$') is not null begin
	print 'removing proc DeleteObj$'
	drop proc [DeleteObj$]
end
go
print 'creating proc DeleteObj$'
go
create proc [DeleteObj$]
	@objId int = null,
	@hXMLDocObjList int=null
as
	declare @Err int, @nRowCnt int, @nTrnCnt int
	declare	@sQry nvarchar(4000)
	declare	@nObjClass int, @nInheritDepth int, @nOwnerDepth int, @nOrdrAndType tinyint, 
		@sDelClass nvarchar(100), @sDelField nvarchar(100)
	declare	@fIsNocountOn int
	
	DECLARE
		@nObj INT,
		@nvcTableName NVARCHAR(60),
		@nFlid INT
		

	set @Err = 0
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- create a temporary table to hold the object hierarchy
	create table [#ObjInfoTbl$]
	(
		[ObjId]		int		not null,
		[ObjClass]	int		null,
		[InheritDepth]	int		null		default(0),
		[OwnerDepth]	int		null		default(0),
		[RelObjId]	int		null,
		[RelObjClass]	int		null,
		[RelObjField]	int		null,
		[RelOrder]	int		null,
		[RelType]	int		null,
		[OrdKey]	varbinary(250)	null		default(0)
	)
	create nonclustered index #ObjInfoTbl$_Ind_ObjId on [#ObjInfoTbl$] (ObjId)
	create nonclustered index #ObjInfoTbl$_Ind_ObjClass on [#ObjInfoTbl$] (ObjClass)

	-- determine if the procedure was called within a transaction; if yes then create a savepoint, 
	--    otherwise create a transaction
	set @nTrnCnt = @@trancount
	if @nTrnCnt = 0 begin tran DelObj$_Tran
	else save tran DelObj$_Tran
	set @Err = @@error
	if @Err <> 0 begin
		raiserror ('DeleteObj$: SQL Error %d; Unable to create a transaction.', 16, 1, @Err)
		goto LFail
	end	

	-- make sure objects were specified either in the XML or through the @ObjId parameter
	if ( @ObjId is null and @hXMLDocObjList is null ) or ( @ObjId is not null and @hXMLDocObjList is not null ) goto LFail

	-- get the owned objects
	insert into #ObjInfoTbl$
	select	*
	from	dbo.fnGetOwnedObjects$(@ObjId, @hXMLDocObjList, null, 1, 1, 1, null, 0)

	--
	-- remove strings associated with the objects that will be deleted
	--
	delete	MultiStr$ with (serializable)
	from [#ObjInfoTbl$] oi 
	join [MultiStr$] ms  on oi.[ObjId] = ms.[obj]
	set @Err = @@error
	if @Err <> 0 begin
		raiserror ('DeleteObj$: SQL Error %d; Unable to remove strings from the MultiStr$ table.', 16, 1, @Err)
		goto LFail
	end
	
	--( This query finds the class of the object, and from there deteremines
	--( which multitxt fields need deleting. It gets the first property first.
	--( Any remaining multitxt properties are found in the loop.
	
	SELECT TOP 1
		@nObj = oi.ObjId,
		@nFlid = f.[Id],
		@nvcTableName = c.[Name] + '_' + f.[Name]
	FROM Field$ f
	JOIN Class$ c ON c.[Id] = f.Class
	JOIN CmObject o  ON o.Class$ = f.Class AND Type = 16
	JOIN #ObjInfoTbl$ oi  ON oi.ObjId = o.[Id]
	ORDER BY f.[Id]
	
	SET @nRowCnt = @@ROWCOUNT
	WHILE @nRowCnt > 0 BEGIN
		SET @sQry = 
			N'DELETE ' + @nvcTableName + N' WITH (SERIALIZABLE) ' + CHAR(13) +
			CHAR(9) + N'FROM #ObjInfoTbl$ oi ' + CHAR(13) +
			CHAR(9) + N'JOIN ' + @nvcTableName + ' x  ON x.Obj = @nObj'
		
		EXECUTE sp_executesql @sQry, N'@nObj INT', @nObj
		
		set @Err = @@error
		if @Err <> 0 begin
			raiserror ('DeleteObj$: SQL Error %d; Unable to remove strings from the MultiTxt$ table', 16, 1, @Err)
			goto LFail
		end
		
		SELECT TOP 1
			@nObj = oi.ObjId,
			@nFlid = f.[Id],
			@nvcTableName = c.[Name] + '_' + f.[Name]
		FROM Field$ f
		JOIN Class$ c ON c.[Id] = f.Class
		JOIN CmObject o  ON o.Class$ = f.Class AND Type = 16
		JOIN #ObjInfoTbl$ oi  ON oi.ObjId = o.[Id]
		WHERE f.[Id] > @nFlid
		ORDER BY f.[Id]
		
		SET @nRowCnt = @@ROWCOUNT
	END
	
	delete MultiBigStr$ with (serializable)
	from [#ObjInfoTbl$] oi 
	join [MultiBigStr$] ms  on oi.[ObjId] = ms.[obj]
	set @Err = @@error
	if @Err <> 0 begin
		raiserror ('DeleteObj$: SQL Error %d; Unable to remove strings from the MultiBigStr$ table.', 16, 1, @Err)
		goto LFail
	end
	delete MultiBigTxt$ with (serializable)
	from [#ObjInfoTbl$] oi 
	 join [MultiBigTxt$] ms  on oi.[ObjId] = ms.[obj]
	set @Err = @@error
	if @Err <> 0 begin
		raiserror ('DeleteObj$: SQL Error %d; Unable to remove strings from the MultiBigTxt$ table.', 16, 1, @Err)
		goto LFail
	end
	
	--
	-- loop through the objects and delete all owned objects and clean-up all relationships
	--
	declare Del_Cur cursor fast_forward local for
	-- get the classes that reference (atomic, sequences, and collections) one of the owned classes
	select	oi.[ObjClass], 
		min(oi.InheritDepth) as InheritDepth, 
		max(oi.OwnerDepth) as OwnerDepth, 
		c.[Name] as DelClassName,
		f.[Name] as DelFieldName,
		case f.[Type]
			when 24 then 1		-- atomic reference
			when 26 then 2	-- reference collection 
			when 28 then 3	-- reference sequence
		end as OrdrAndType
	from	#ObjInfoTbl$ oi (serializable)
			join [Field$] f on oi.[ObjClass] = f.[DstCls] and f.[Type] in (24, 26, 28)
			join [Class$] c on f.[Class] = c.[Id]
	group by oi.[ObjClass], c.[Name], f.[Name], f.[Type]
	union all
	-- get the classes that are referenced by the owning classes
	select	oi.[ObjClass],
		min(oi.[InheritDepth]) as InheritDepth,
		max(oi.[OwnerDepth]) as OwnerDepth,
		c.[Name] as DelClassName,
		f.[Name] as DelFieldName,
		case f.[Type]
			when 26 then 4	-- reference collection 
			when 28 then 5	-- reference sequence
		end as OrdrAndType
	from	[#ObjInfoTbl$] oi (serializable)
			join [Class$] c on c.[Id] = oi.[ObjClass]
			join [Field$] f on f.[Class] = c.[Id] and f.[Type] in (26, 28)
	group by oi.[ObjClass], c.[Name], f.[Name], f.[Type]
	union all
	-- get the owned classes
	select	oi.[ObjClass], 
		min(oi.[InheritDepth]) as InheritDepth, 
		max(oi.[OwnerDepth]) as OwnerDepth, 
		c.[Name] as DelClassName,
		NULL,
		6 as OrdrAndType
	from	#ObjInfoTbl$ oi (serializable)
			join Class$ c on oi.ObjClass = c.Id
	group by oi.[ObjClass], c.Name
	order by OrdrAndType, InheritDepth asc, OwnerDepth desc, DelClassName

	open Del_Cur
	fetch Del_Cur into @nObjClass, @nInheritDepth, @nOwnerDepth, @sDelClass, @sDelField, @nOrdrAndType

	while @@fetch_status = 0 begin
	
		-- classes that contain refence pointers to this class
		if @nOrdrAndType = 1 begin
			set @sQry='update ['+@sDelClass+'] with (serializable) set ['+@sDelField+']=NULL '+
				'from ['+@sDelClass+'] r  '+
					'join [#ObjInfoTbl$] oi  on r.['+@sDelField+'] = oi.[ObjId] '
		end
		-- classes that contain sequence or collection references to this class
		else if @nOrdrAndType = 2 or @nOrdrAndType = 3 begin
			set @sQry='delete ['+@sDelClass+'_'+@sDelField+'] with (serializable) '+
				'from ['+@sDelClass+'_'+@sDelField+'] c  '+
					'join [#ObjInfoTbl$] oi  on c.[Dst] = oi.[ObjId] '
		end
		-- classes that are referenced by this class's collection or sequence references
		else if @nOrdrAndType = 4 or @nOrdrAndType = 5 begin
			set @sQry='delete ['+@sDelClass+'_'+@sDelField+'] with (serializable) '+
				'from ['+@sDelClass+'_'+@sDelField+'] c  '+
					'join [#ObjInfoTbl$] oi  on c.[Src] = oi.[ObjId] '
		end
		-- remove class data
		else if @nOrdrAndType = 6 begin
			set @sQry='delete ['+@sDelClass+'] with (serializable) '+ 
				'from ['+@sDelClass+'] o  '+
					'join [#ObjInfoTbl$] oi  on o.[id] = oi.[ObjId] '
		end

		set @sQry = @sQry +
				'where oi.[ObjClass]='+convert(nvarchar(11),@nObjClass)
		exec(@sQry)
		select @Err = @@error, @nRowCnt = @@rowcount

		if @Err <> 0 begin
			raiserror ('DeleteObj$: SQL Error %d; Unable to execute dynamic SQL.', 16, 1, @Err)
			goto LFail
		end

		fetch Del_Cur into @nObjClass, @nInheritDepth, @nOwnerDepth, @sDelClass, @sDelField, @nOrdrAndType
	end

	close Del_Cur
	deallocate Del_Cur

	--
	-- delete the objects in CmObject
	--
	delete CmObject with (serializable)
	from #ObjInfoTbl$ do 
	join CmObject co  on do.[ObjId] = co.[id]
	set @Err = @@error
	if @Err <> 0 begin
		raiserror ('DeleteObj$: SQL Error %d; Unable to remove the objects from CmObject.', 16, 1, @Err)
		goto LFail
	end

	-- remove the temporary table used to hold the delete objects' information
	drop table #ObjInfoTbl$
	
	if @nTrnCnt = 0 commit tran DelObj$_Tran
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return 0

LFail:
	-- because the #ObjInfoTbl$ is a temporary table created within a procedure it is automatically
	--	removed by SQL Server, so it does not need to be explicitly deleted here

	rollback tran DelObj$_Tran
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @Err
go





















if object_id('DeleteObject$') is not null begin
	print 'removing proc DeleteObject$'
	drop proc [DeleteObject$]
end
go
print 'creating proc DeleteObject$'
go

create proc [DeleteObject$]
	@uid uniqueidentifier output,
	@objId int = null,
	@fRemoveObjInfo tinyint = 1
as
	declare @Err int, @nRowCnt int, @nTrnCnt int
	declare	@sQry nvarchar(400), @sUid nvarchar(50)
	declare	@nObjClass int, @nInheritDepth int, @nOwnerDepth int, @nOrdrAndType tinyint, @sDelClass nvarchar(100), @sDelField nvarchar(100)
	declare	@fIsNocountOn int
	
	DECLARE
		@nObj INT,
		@nvcTableName NVARCHAR(60),
		@nFlid INT
	
	set @Err = 0
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- determine if the procedure was called within a transaction; if yes then create a savepoint, 
	--    otherwise create a transaction
	set @nTrnCnt = @@trancount
	if @nTrnCnt = 0 begin tran DelObj$_Tran
	else save tran DelObj$_Tran
	set @Err = @@error
	if @Err <> 0 begin
		raiserror ('DeleteObject$: SQL Error %d; Unable to create a transaction.', 16, 1, @Err)
		goto LFail
	end	

	-- get the ownership heirarchy
	exec @Err = GetOwnershipPath$ @uid output, @ObjId, 1, 1, 0
	if @Err <> 0 begin
		set @sUid = convert(nvarchar(50), @Uid)
		raiserror ('DeleteObject$: SQL Error %d; Unable to get the owning hierarchy (UID=%s).', 16, 1, @Err, @sUid)
		goto LFail
	end

	-- get all of the base classes of the object(s)
	insert	into ObjInfoTbl$ with (rowlock)
		(uid, ObjId, ObjClass, InheritDepth, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType)
	select	@uid, oi.[ObjId], p.[Dst], p.[Depth], oi.[OwnerDepth], oi.[RelObjId], oi.[RelObjClass], oi.[RelObjField], oi.[RelOrder], oi.[RelType]
	from	[ObjInfoTbl$] oi 
			join [ClassPar$] p on oi.[ObjClass] = p.[Src]
			join [Class$] c on c.[id] = p.[Dst]
	where	p.[Depth] > 0 and p.[Dst] <> 0
		and [Uid]=@uid
	set @Err = @@error
	if @Err <> 0 begin
		set @sUid = convert(nvarchar(50), @Uid)
		raiserror ('DeleteObject$: SQL Error %d; Unable to get the base class object(s) of the object(s) in the owning hierarchy (UID=%s).', 16, 1, @Err, @sUid)
		goto LFail
	end
	-- get all of the sub classes of the object(s)
	insert	into ObjInfoTbl$ with (rowlock)
		(uid, ObjId, ObjClass, InheritDepth, OwnerDepth, RelObjId, RelObjClass, RelObjField, RelOrder, RelType)
	select	@uid, oi.[ObjId], p.[Src], -p.[Depth], oi.[OwnerDepth], oi.[RelObjId], oi.[RelObjClass], oi.[RelObjField], oi.[RelOrder], oi.[RelType]
	from	[ObjInfoTbl$] oi 
			join [ClassPar$] p on oi.[ObjClass] = p.[Dst] and InheritDepth = 0
			join [Class$] c on c.[id] = p.[Dst]
	where	p.[Depth] > 0 and p.[Dst] <> 0
		and [Uid] = @uid
	set @Err = @@error
	if @Err <> 0 begin
		set @sUid = convert(nvarchar(50), @Uid)
		raiserror ('DeleteObject$: SQL Error %d; Unable to get the sub class object(s) of the object(s) in the owning hierarchy (UID=%s).', 16, 1, @Err, @sUid)
		goto LFail
	end

	--
	-- remove strings associated with the objects that will be deleted
	--
	delete	MultiStr$ with (serializable)
	from [ObjInfoTbl$] oi 
	join [MultiStr$] ms  on oi.[ObjId] = ms.[obj]
	where oi.[Uid] = @uid
	set @Err = @@error
	if @Err <> 0 begin
		set @sUid = convert(nvarchar(50), @Uid)
		raiserror ('DeleteObject$: SQL Error %d; Unable to remove strings from the MultiStr$ table (UID=%s).', 16, 1, @Err, @sUid)
		goto LFail
	end
	
	--( This query finds the class of the object, and from there deteremines
	--( which multitxt fields need deleting. It gets the first property first.
	--( Any remaining multitxt properties are found in the loop.
	
	SELECT TOP 1
		@nObj = oi.ObjId,
		@nFlid = f.[Id],
		@nvcTableName = c.[Name] + '_' + f.[Name]
	FROM Field$ f
	JOIN Class$ c ON c.[Id] = f.Class
	JOIN CmObject o ON o.Class$ = f.Class AND Type = 16
	JOIN ObjInfoTbl$ oi ON oi.ObjId = o.[Id]
	ORDER BY f.[Id]
	
	SET @nRowCnt = @@ROWCOUNT
	WHILE @nRowCnt > 0 BEGIN
		SET @sQry = 
			N'DELETE ' + @nvcTableName + N' WITH (SERIALIZABLE) ' + CHAR(13) +
			CHAR(9) + N'FROM ObjInfoTbl$ oi ' + CHAR(13) +
			CHAR(9) + N'JOIN ' + @nvcTableName + ' x  ON x.Obj = @nObj'
		
		EXECUTE sp_executesql @sQry, N'@nObj INT', @nObj
		
		set @Err = @@error
		if @Err <> 0 begin
			raiserror ('DeleteObj$: SQL Error %d; Unable to remove strings from the MultiTxt table', 16, 1, @Err)
			goto LFail
		end
		
		SELECT TOP 1
			@nObj = oi.ObjId,
			@nFlid = f.[Id],
			@nvcTableName = c.[Name] + '_' + f.[Name]
		FROM Field$ f
		JOIN Class$ c ON c.[Id] = f.Class
		JOIN CmObject o ON o.Class$ = f.Class AND Type = 16
		JOIN ObjInfoTbl$ oi ON oi.ObjId = o.[Id]
		WHERE f.[Id] > @nFlid
		ORDER BY f.[Id]
		
		SET @nRowCnt = @@ROWCOUNT
	END
	
	delete MultiBigStr$ with (serializable)
	from [ObjInfoTbl$] oi 
	join [MultiBigStr$] ms  on oi.[ObjId] = ms.[obj]
	where oi.[Uid] = @uid
	set @Err = @@error
	if @Err <> 0 begin
		set @sUid = convert(nvarchar(50), @Uid)
		raiserror ('DeleteObject$: SQL Error %d; Unable to remove strings from the MultiBigStr$ table (UID=%s).', 16, 1, @Err, @sUid)
		goto LFail
	end
	delete MultiBigTxt$ with (serializable)
	from [ObjInfoTbl$] oi 
	join [MultiBigTxt$] ms  on oi.[ObjId] = ms.[obj]
	where oi.[Uid] = @uid
	set @Err = @@error
	if @Err <> 0 begin
		set @sUid = convert(nvarchar(50), @Uid)
		raiserror ('DeleteObject$: SQL Error %d; Unable to remove strings from the MultiBigTxt$ table (UID=%s).', 16, 1, @Err, @sUid)
		goto LFail
	end
	
	--
	-- loop through the objects and delete all owned objects and clean-up all relationships
	--
	declare Del_Cur cursor fast_forward local for
	-- get the classes that reference (atomic, sequences, and collections) one of the owned classes
	select	oi.[ObjClass], 
		min(oi.InheritDepth) as InheritDepth, 
		max(oi.OwnerDepth) as OwnerDepth, 
		c.[Name] as DelClassName,
		f.[Name] as DelFieldName,
		case f.[Type]
			when 24 then 1		-- atomic reference
			when 26 then 2	-- reference collection 
			when 28 then 3	-- reference sequence
		end as OrdrAndType
	from	ObjInfoTbl$ oi (serializable)
			join [Field$] f on oi.[ObjClass] = f.[DstCls] and f.[Type] in (24, 26, 28)
			join [Class$] c on f.[Class] = c.[Id]
	where	oi.[Uid] = @uid
	group by oi.[ObjClass], c.[Name], f.[Name], f.[Type]
	union all
	-- get the classes that are referenced by the owning classes
	select	oi.[ObjClass],
		min(oi.[InheritDepth]) as InheritDepth,
		max(oi.[OwnerDepth]) as OwnerDepth,
		c.[Name] as DelClassName,
		f.[Name] as DelFieldName,
		case f.[Type]
			when 26 then 4	-- reference collection 
			when 28 then 5	-- reference sequence
		end as OrdrAndType
	from	[ObjInfoTbl$] oi (serializable)
			join [Class$] c on c.[Id] = oi.[ObjClass]
			join [Field$] f on f.[Class] = c.[Id] and f.[Type] in (26, 28)
	where	oi.[Uid] = @uid
	group by oi.[ObjClass], c.[Name], f.[Name], f.[Type]
	union all
	-- get the owned classes
	select	oi.[ObjClass], 
		min(oi.[InheritDepth]) as InheritDepth, 
		max(oi.[OwnerDepth]) as OwnerDepth, 
		c.[Name] as DelClassName,
		NULL,
		6 as OrdrAndType
	from	ObjInfoTbl$ oi (serializable)
			join Class$ c on oi.ObjClass = c.Id
	where	oi.[Uid] = @uid
	group by oi.[ObjClass], c.Name
	order by OrdrAndType, InheritDepth asc, OwnerDepth desc, DelClassName

	open Del_Cur
	fetch Del_Cur into @nObjClass, @nInheritDepth, @nOwnerDepth, @sDelClass, @sDelField, @nOrdrAndType

	while @@fetch_status = 0 begin
	
		-- classes that contain refence pointers to this class
		if @nOrdrAndType = 1 begin
			set @sQry='update ['+@sDelClass+'] with (serializable) set ['+@sDelField+']=NULL '+
				'from ['+@sDelClass+'] r  '+
					'join [ObjInfoTbl$] oi  on r.['+@sDelField+'] = oi.[ObjId] '
		end
		-- classes that contain sequence or collection references to this class
		else if @nOrdrAndType = 2 or @nOrdrAndType = 3 begin
			set @sQry='delete ['+@sDelClass+'_'+@sDelField+'] with (serializable)'+
				'from ['+@sDelClass+'_'+@sDelField+'] c  '+
					'join [ObjInfoTbl$] oi  on c.[Dst] = oi.[ObjId] '
		end
		-- classes that are referenced by this class's collection or sequence references
		else if @nOrdrAndType = 4 or @nOrdrAndType = 5 begin
			set @sQry='delete ['+@sDelClass+'_'+@sDelField+'] with (serializable)'+
				'from ['+@sDelClass+'_'+@sDelField+'] c  '+
					'join [ObjInfoTbl$] oi  on c.[Src] = oi.[ObjId] '
		end
		-- remove class data
		else if @nOrdrAndType = 6 begin
			set @sQry='delete ['+@sDelClass+'] with (serializable)'+ 
				'from ['+@sDelClass+'] o  '+
					'join [ObjInfoTbl$] oi  on o.[id] = oi.[ObjId] '
		end

		set @sQry = @sQry +
				'where oi.[ObjClass]='+convert(nvarchar(11),@nObjClass)+' '+
					'and oi.[Uid]='''+convert(varchar(250), @uid)+''''
		exec(@sQry)
		select @Err = @@error, @nRowCnt = @@rowcount

		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('DeleteObject$: SQL Error %d; Unable to execute dynamic SQL (UID=%s).', 16, 1, @Err, @sUid)
			goto LFail
		end

		fetch Del_Cur into @nObjClass, @nInheritDepth, @nOwnerDepth, @sDelClass, @sDelField, @nOrdrAndType
	end

	close Del_Cur
	deallocate Del_Cur

	--
	-- delete the objects in CmObject
	--
	delete CmObject with (serializable)
	from ObjInfoTbl$ do 
	join CmObject co  on do.[ObjId] = co.[id] and do.[uid] = @uid
	set @Err = @@error
	if @Err <> 0 begin
		set @sUid = convert(nvarchar(50), @Uid)
		raiserror ('DeleteObject$: SQL Error %d; Unable to remove the objects from CmObject (UID=%s).', 16, 1, @Err, @sUid)
		goto LFail
	end

	-- determine if the ObjInfoTbl$ should be cleaned up
	if @fRemoveObjInfo = 1 begin 
		exec @Err=CleanObjInfoTbl$ @uid
		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('DeleteObject$: SQL Error %d; Unable to remove rows from the ObjInfoTbl$ table (UID=%s).', 16, 1, @Err, @sUid)
			goto LFail
		end
	end
	
	if @nTrnCnt = 0 commit tran DelObj$_Tran
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return 0

LFail:
	rollback tran DelObj$_Tran
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @Err
go

















if object_id('DeletePrepDelObjects$') is not null begin
	print 'removing proc DeletePrepDelObjects$'
	drop proc [DeletePrepDelObjects$]
end
go
print 'creating proc DeletePrepDelObjects$'
go
create proc [DeletePrepDelObjects$]
	@uid uniqueidentifier,
	@fRemoveObjInfo tinyint = 1
as
	declare @Err int, @nRowCnt int, @nTrnCnt int
	declare	@sQry nvarchar(400), @sUid nvarchar(50)
	declare	@nObjClass int, @nInheritDepth int, @nOwnerDepth int, @nOrdrAndType tinyint, @sDelClass nvarchar(100), @sDelField nvarchar(100)
	declare	@fIsNocountOn int
	
	DECLARE
		@nObj INT,
		@nvcTableName NVARCHAR(60),
		@nFlid INT
	
	set @Err = 0
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- determine if the procedure was called within a transaction; if yes then create a savepoint, 
	--    otherwise create a transaction
	set @nTrnCnt = @@trancount
	if @nTrnCnt = 0 begin tran DelObj$_Tran
	else save tran DelObj$_Tran
	set @Err = @@error
	if @Err <> 0 begin
		raiserror ('DeletePrepDelObjects$: SQL Error %d; Unable to create a transaction.', 16, 1, @Err)
		goto LFail
	end	

	--
	-- remove strings associated with the objects that will be deleted
	--
	delete	MultiStr$
	from [ObjInfoTbl$] oi join [MultiStr$] ms on oi.[ObjId] = ms.[obj]
	where oi.[Uid] = @uid
	set @Err = @@error
	if @Err <> 0 begin
		set @sUid = convert(nvarchar(50), @Uid)
		raiserror ('DeletePrepDelObjects$: SQL Error %d; Unable to remove strings from the MultiStr$ table (UID=%s).', 16, 1, @Err, @sUid)
		goto LFail
	end

	--( This query finds the class of the object, and from there deteremines
	--( which multitxt fields need deleting. It gets the first property first.
	--( Any remaining multitxt properties are found in the loop.
	
	SELECT TOP 1
		@nObj = oi.ObjId,
		@nFlid = f.[Id],
		@nvcTableName = c.[Name] + '_' + f.[Name]
	FROM Field$ f
	JOIN Class$ c ON c.[Id] = f.Class
	JOIN CmObject o ON o.Class$ = f.Class AND Type = 16
	JOIN ObjInfoTbl$ oi ON oi.ObjId = o.[Id]
	ORDER BY f.[Id]
	
	SET @nRowCnt = @@ROWCOUNT
	WHILE @nRowCnt > 0 BEGIN
		SET @sQry = 
			N'DELETE ' + @nvcTableName + N' WITH (SERIALIZABLE) ' + CHAR(13) +
			CHAR(9) + N'FROM ObjInfoTbl$ oi ' + CHAR(13) +
			CHAR(9) + N'JOIN ' + @nvcTableName + ' x  ON x.Obj = @nObj'
		
		EXECUTE sp_executesql @sQry, N'@nObj INT', @nObj
		
		set @Err = @@error
		if @Err <> 0 begin
			raiserror ('DeleteObj$: SQL Error %d; Unable to remove strings from the MultiTxt table ', 16, 1, @Err)
			goto LFail
		end
		
		SELECT TOP 1
			@nObj = oi.ObjId,
			@nFlid = f.[Id],
			@nvcTableName = c.[Name] + '_' + f.[Name]
		FROM Field$ f
		JOIN Class$ c ON c.[Id] = f.Class
		JOIN CmObject o ON o.Class$ = f.Class AND Type = 16
		JOIN ObjInfoTbl$ oi ON oi.ObjId = o.[Id]
		WHERE f.[Id] > @nFlid
		ORDER BY f.[Id]
		
		SET @nRowCnt = @@ROWCOUNT
	END
	
	delete MultiBigStr$
	from [ObjInfoTbl$] oi join [MultiBigStr$] ms on oi.[ObjId] = ms.[obj]
	where oi.[Uid] = @uid
	set @Err = @@error
	if @Err <> 0 begin
		set @sUid = convert(nvarchar(50), @Uid)
		raiserror ('DeletePrepDelObjects$: SQL Error %d; Unable to remove strings from the MultiBigStr$ table (UID=%s).', 16, 1, @Err, @sUid)
		goto LFail
	end
	delete MultiBigTxt$
	from [ObjInfoTbl$] oi join [MultiBigTxt$] ms on oi.[ObjId] = ms.[obj]
	where oi.[Uid] = @uid
	set @Err = @@error
	if @Err <> 0 begin
		set @sUid = convert(nvarchar(50), @Uid)
		raiserror ('DeletePrepDelObjects$: SQL Error %d; Unable to remove strings from the MultiBigTxt$ table (UID=%s).', 16, 1, @Err, @sUid)
		goto LFail
	end

	--
	-- loop through the objects and delete all owned objects and clean-up all relationships
	--
	declare Del_Cur cursor fast_forward local for
	-- get the external classes that reference (atomic, sequences, and collections) one of the owned classes
	select	oi.ObjClass, 
		min(oi.InheritDepth) as InheritDepth, 
		max(oi.OwnerDepth) as OwnerDepth, 
		c.Name as DelClassName,
		f.Name as DelFieldName,
		case oi.[RelType]
			when 24 then 1		-- atomic reference
			when 26 then 2	-- reference collection 
			when 28 then 3	-- reference sequence
		end as OrdrAndType
	from	ObjInfoTbl$ oi (serializable) join Class$ c on oi.RelObjClass = c.Id
			join Field$ f on oi.RelObjField = f.Id
	where	oi.[Uid] = @uid
		and oi.[RelType] in (24,26,28)
	group by oi.ObjClass, c.Name, f.Name, oi.RelType
	union all
	-- get internal references - the call to GetIncomingRefsPrepDel$ only found external references
	select	oi.ObjClass, 
		min(oi.InheritDepth) as InheritDepth, 
		max(oi.OwnerDepth) as OwnerDepth, 
		c.Name as DelClassName,
		f.Name as DelFieldName,
		case oi.[RelType]
			when 24 then 1		-- atomic reference
			when 26 then 2	-- reference collection 
			when 28 then 3	-- reference sequence
		end as OrdrAndType
	from	ObjInfoTbl$ oi (serializable) join Field$ f on f.[DstCls] = oi.[ObjClass] and f.Type in (24,26,28)
			join Class$ c on c.[Id] = f.[Class]
	where	oi.[Uid] = @uid
		and exists (
			select	*
			from	ObjInfoTbl$ oi2 
			where	oi2.[Uid] = @uid
				and oi2.[ObjClass] = f.[Class]
		)
	group by oi.ObjClass, c.Name, f.Name, oi.RelType
	union all
	-- get the classes that are referenced by the owning classes
	select	oi.ObjClass,
		min(oi.InheritDepth) as InheritDepth,
		max(oi.OwnerDepth) as OwnerDepth,
		c.Name as DelClassName,
		f.Name as DelFieldName,
		case f.[Type]
			when 26 then 4	-- reference collection 
			when 28 then 5	-- reference sequence
		end as OrdrAndType
	from	[ObjInfoTbl$] oi (serializable) join [Class$] c on c.[Id] = oi.[ObjClass]
			join [Field$] f on f.[Class] = c.[Id] and f.[Type] in (26, 28)
	where	oi.[Uid] = @uid
		and ( oi.[RelType] in (23,25,27) or oi.[RelType] is null )
	group by oi.ObjClass, c.Name, f.Name, f.[Type]
	union all
	-- get the owned classes
	select	oi.ObjClass, 
		min(oi.InheritDepth) as InheritDepth, 
		max(oi.OwnerDepth) as OwnerDepth, 
		c.Name as DelClassName,
		NULL,
		6 as OrdrAndType
	from	ObjInfoTbl$ oi (serializable) join Class$ c on oi.ObjClass = c.Id
	where	oi.[Uid] = @uid
		and ( oi.[RelType] in (23,25,27) or oi.[RelType] is null )
	group by oi.ObjClass, c.Name
	order by OrdrAndType, InheritDepth asc, OwnerDepth desc, DelClassName

	open Del_Cur
	fetch Del_Cur into @nObjClass, @nInheritDepth, @nOwnerDepth, @sDelClass, @sDelField, @nOrdrAndType

	while @@fetch_status = 0 begin
	
		-- classes that contain refence pointers to this class
		if @nOrdrAndType = 1 begin
			set @sQry='update ['+@sDelClass+'] set ['+@sDelField+']=NULL '+
				'from ['+@sDelClass+'] r '+
					'join [ObjInfoTbl$] oi  on r.['+@sDelField+'] = oi.[ObjId] '
		end
		-- classes that contain sequence or collection references to this class
		else if @nOrdrAndType = 2 or @nOrdrAndType = 3 begin
			set @sQry='delete ['+@sDelClass+'_'+@sDelField+'] '+
				'from ['+@sDelClass+'_'+@sDelField+'] c '+
					'join [ObjInfoTbl$] oi  on c.[Dst] = oi.[ObjId] '
		end
		-- classes that are referenced by this class's collection or sequence references
		else if @nOrdrAndType = 4 or @nOrdrAndType = 5 begin
			set @sQry='delete ['+@sDelClass+'_'+@sDelField+'] '+
				'from ['+@sDelClass+'_'+@sDelField+'] c '+
					'join [ObjInfoTbl$] oi  on c.[Src] = oi.[ObjId] '
		end
		-- remove class data
		else if @nOrdrAndType = 6 begin
			set @sQry='delete ['+@sDelClass+'] '+ 
				'from ['+@sDelClass+'] o '+
					'join [ObjInfoTbl$] oi  on o.[id] = oi.[ObjId] '
		end

		set @sQry = @sQry +
				'where oi.[ObjClass]='+convert(nvarchar(11),@nObjClass)+' '+
					'and oi.[Uid]='''+convert(varchar(250), @uid)+''''
		exec(@sQry)
		select @Err = @@error, @nRowCnt = @@rowcount

		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('DeletePrepDelObjects$: SQL Error %d; Unable to execute dynamic SQL (UID=%s).', 16, 1, @Err, @sUid)
			goto LFail
		end

		fetch Del_Cur into @nObjClass, @nInheritDepth, @nOwnerDepth, @sDelClass, @sDelField, @nOrdrAndType
	end

	close Del_Cur
	deallocate Del_Cur

	--
	-- delete the objects in CmObject
	--
	delete CmObject
	from ObjInfoTbl$ do join CmObject co on do.[ObjId] = co.[id]

	set @Err = @@error
	if @Err <> 0 begin
		set @sUid = convert(nvarchar(50), @Uid)
		raiserror ('DeletePrepDelObjects$: SQL Error %d; Unable to remove the objects from the CmObject table (UID=%s).', 16, 1, @Err, @sUid)
		goto LFail
	end

	-- determine if the ObjInfoTbl$ should be cleaned up
	if @fRemoveObjInfo = 1 begin 
		exec @Err=CleanObjInfoTbl$ @uid
		if @Err <> 0 begin
			set @sUid = convert(nvarchar(50), @Uid)
			raiserror ('DeleteObject$: SQL Error %d; Unable to remove rows from the ObjInfoTbl$ table (UID=%s).', 16, 1, @Err, @sUid)
			goto LFail
		end
	end

	if @nTrnCnt = 0 commit tran DelObj$_Tran

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return 0

LFail:
	rollback tran DelObj$_Tran
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @Err
go



















if object_id('DefineReplaceRefCollPrc$') is not null begin
	print 'removing proc DefineReplaceRefCollProc$'
	drop proc [DefineReplaceRefCollProc$]
end
go
print 'Creating proc DefineReplaceRefCollProc$'
go
create proc [DefineReplaceRefCollProc$]
	@sTbl sysname
as
	declare @sDynSql nvarchar(4000), @sDynSql2 nvarchar(4000)
	declare @err int

	if object_id('ReplaceRefColl_' + @sTbl ) is not null begin
		set @sDynSql = 'alter '
	end
	else begin
		set @sDynSql = 'create '
	end

set @sDynSql = @sDynSql + N'
proc ReplaceRefColl_' + @sTbl +'
	@SrcObjId int,
	@hXMLDocInsert int = null,
	@hXMLDocDelete int = null,
	@fRemoveXMLDocs tinyint = 1
as
	declare	@fIsNocountOn int, @Err int, @nTrnCnt int, @sTranName varchar(300)
	declare @i int, @RowsAffected int

	set @Err = 0

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on
	
	-- determine if the procedure was called within a transaction; if yes then create a savepoint, 
	--	otherwise create a transaction
	set @sTranName = ''ReplaceRef$_'+@sTbl+''' + convert(varchar(11), @@trancount)
	set @nTrnCnt = @@trancount
	if @nTrnCnt = 0 begin tran @sTranName
	else save tran @sTranName
	set @Err = @@error
	if @Err <> 0 begin
		raiserror(''ReplaceRefSeq_'+@sTbl+': SQL Error %d; Unable to create a transaction'', 16, 1, @Err)
		goto LCleanup
	end

	-- determine if any object references should be removed
	if @hXMLDocDelete is not null begin
		-- objects may be listed in a collection more than once, and the delete list specifies how many
		--	occurrences of an object need to be removed; the above delete however removed all occurences,
		--	so the appropriate number of certain objects may need to be added back in

		-- create a temporary table to hold objects that are referenced more than once and at least one
		--	of the references is to be removed
		declare @t table (
			DstObjId int,
			Occurrences int,
			DelOccurrences int
		)
		set @Err = @@error
		if @Err <> 0 begin
			raiserror(''ReplaceRefColl_'+@sTbl+': SQL Error %d; Unable to create a temporary table'', 16, 1, @Err)
			goto LCleanup
		end

		-- get the objects that are referenced more than once along with the actual number of references; do this
		--	only for the objects where at least one reference is going to be removed
		insert into @t (DstObjId, DelOccurrences, Occurrences)
		select	jt.[Dst], ol.[DelCnt], count(*)
		from	['+@sTbl+'] jt (serializable)
			join (
				select	[Id] ObjId, count(*) DelCnt
				from	openxml(@hXMLDocDelete, ''/root/Obj'') with ([Id] int)
				group by [Id]
			) as ol on jt.[Dst] = ol.[ObjId]
		where	jt.[Src] = @SrcObjid
		group by jt.[Dst], ol.[DelCnt]
		having count(*) > 1
		set @Err = @@error
		if @Err <> 0 begin
			raiserror(''ReplaceRefColl_'+@sTbl+': SQL Error %d; Unable to insert objects that are referenced more than once: SrcObjId(src) = %d'', 
					16, 1, @Err, @SrcObjId)
			goto LCleanup
		end
'
set @sDynSql2 = N'
		-- remove the object references
		-- for some reason the preferable DELETE...FROM query generates server exceptions when the openxml statement is
		--	used, so the only alternative is to use IN (...)
		delete	['+@sTbl+']
		where	[Src] = @SrcObjId
			and [Dst] in (
				select	[Id]
				from	openxml(@hXMLDocDelete, ''/root/Obj'') with ([Id] int)
			)
		set @Err = @@error
		if @Err <> 0 begin
			raiserror(''ReplaceRefColl_'+@sTbl+': SQL Error %d; Unable to delete objects from a reference collection: SrcObjId(src) = %d'', 
					16, 1, @Err, @SrcObjId)
			goto LCleanup
		end

		-- reinsert the appropriate number of objects that had multiple references
		set @i = 0
		set @RowsAffected = 1 -- set to 1 to get inside of the loop
		while @RowsAffected > 0 begin
			insert into ['+@sTbl+'] with (serializable) ([Src], [Dst])
			select	@SrcObjid, [DstObjId]
			from	@t
			where	Occurrences - DelOccurrences > @i
			select @Err = @@error, @RowsAffected = @@rowcount
			if @Err <> 0 begin
				raiserror(''ReplaceRefColl_'+@sTbl+': SQL Error %d; Unable to reinsert objects into a reference collection: SrcObjId(src) = %d'', 
						16, 1, @Err, @SrcObjId)
				goto LCleanup
			end
			set @i = @i + 1
		end

	end

	-- determine if any object references should be inserted
	if @hXMLDocInsert is not null begin

		insert into ['+@sTbl+'] with (serializable) ([Src], [Dst])
		select	@SrcObjId, ol.[Id]
		from	openxml(@hXMLdocInsert, ''/root/Obj'') with (Id int) as ol
		set @Err = @@error
		if @Err <> 0 begin
			raiserror(''ReplaceRefColl_'+@sTbl+': SQL Error %d; Unable to insert objects into a reference collection: SrcObjId(src) = %d'', 
					16, 1, @Err, @SrcObjId)
			goto LCleanup
		end
	end	

LCleanup:
	if @Err <> 0 rollback tran @sTranName
	else if @nTrnCnt = 0 commit tran @sTranName

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	-- determine if the XML documents should be removed
	if @fRemoveXMLDocs = 1 begin
		if @hXMLdocInsert is not null exec sp_xml_removedocument @hXMLdocInsert
		if @hXMLdocDelete is not null and @hXMLdocDelete <> @hXMLdocInsert exec sp_xml_removedocument @hXMLdocDelete
	end

	return @Err
'

	exec ( @sDynSql + @sDynSql2 )
	set @Err = @@error
	if @Err <> 0 begin
		raiserror('DefineReplaceRefCollProc: SQL Error %d: Unable to create or alter the procedure ReplaceRefColl_%s$',
				16, 1, @Err, @sTbl)
		return @err
	end

	return 0
go



























if object_id('ReplaceRefColl$') is not null begin
	print 'removing proc ReplaceRefColl$'
	drop proc [ReplaceRefColl$]
end
go
print 'creating proc ReplaceRefColl$'
go
create proc [ReplaceRefColl$]
	@flid int,
	@SrcObjId int,
	@hXMLDocInsert int = null,
	@hXMLDOcDelete int = null,
	@fRemoveXMLDocs tinyint = 1
as
	declare @Err int
	declare	@sDynSql varchar(500)

	select	@sDynSql = 'exec ReplaceRefColl_' + c.[Name] + '_' + f.[Name] + ' ' +
			coalesce(convert(varchar(11), @SrcObjId), 'null') + ',' +
			coalesce(convert(varchar(11), @hXMLDocInsert), 'null') + ',' +
			coalesce(convert(varchar(11), @hXMLDOcDelete), 'null') + ',' +
			coalesce(convert(varchar(3), @fRemoveXMLDocs), 'null')
	from	Field$ f join Class$ c on f.[Class] = c.[Id]
	where	f.[Id] = @flid and f.[Type] = 26

	if @@rowcount <> 1 begin
		raiserror('ReplaceRefColl$: Invalid flid: %d', 16, 1, @flid)
		return 50000
	end

	exec (@sDynSql)
	set @Err = @@error
	if @Err <> 0 begin
		raiserror('ReplaceRefColl$: SQL Error %d: Unable to perform replace: %d', 16, 1, @Err, @sDynSql)
		return @Err
	end

	return 0
go















if object_id('DefineReplaceRefSeqProc$') is not null begin
	print 'removing proc DefineReplaceRefSeqProc$'
	drop proc [DefineReplaceRefSeqProc$]
end
go
print 'Creating proc DefineReplaceRefSeqProc$'
go
create proc [DefineReplaceRefSeqProc$]
	@sTbl sysname,
	@flid int
as
	declare @sDynSql nvarchar(4000), @sDynSql2 nvarchar(4000), @sDynSql3 nvarchar(4000), @sDynSql4 nvarchar(4000)
	declare @err int

	if object_id('ReplaceRefSeq_' + @sTbl) is not null begin
		set @sDynSql = 'alter '
	end
	else begin
		set @sDynSql = 'create '
	end

set @sDynSql = @sDynSql +
N'proc ReplaceRefSeq_' + @sTbl +'
	@SrcObjId int,
	@ListStmp int,
	@hXMLdoc int = null,
	@StartObj int = null,
	@StartObjOccurrence int = 1,
	@EndObj int = null,
	@EndObjOccurrence int = 1,
	@fRemoveXMLdoc tinyint = 1
as
	declare	@fIsNocountOn int, @Err int, @nTrnCnt int, @sTranName varchar(300)
	declare @nNumObjs int, @iCurObj int, @nMinOrd int, @StartOrd int, @EndOrd int
	declare @nSpaceAvail int
	declare @UpdStmp int

	set @Err = 0

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on
'









set @sDynSql = @sDynSql +
N'
	-- determine if the procedure was called within a transaction; if yes then create a savepoint, 
	--	otherwise create a transaction
	set @sTranName = ''ReplaceRefSeq_'+@sTbl+''' + convert(varchar(11), @@trancount)
	set @nTrnCnt = @@trancount
	if @nTrnCnt = 0 begin tran @sTranName
	else save tran @sTranName
	set @Err = @@error
	if @Err <> 0 begin
		raiserror(''ReplaceRefSeq_'+@sTbl+': SQL Error %d; Unable to create a transaction'', 16, 1, @Err)
		goto LFail
	end

	-- get the starting and ending ordinal values
	set @EndOrd = null
	set @StartOrd = null
	if @StartObj is null begin
		-- since the @StartObj is null the list of objects should be added to the end of the sequence, so
		--	get the maximum ord value and add 1
		select	@StartOrd = coalesce(max([Ord]), 0) + 1
		from	['+@sTbl+'] with (serializable)
		where	[Src] = @SrcObjId
	end
	else begin
		-- create a temporary table to hold all of the ord values associated with Src=@SrcObjId and (Dst=
		--	@StartObj or Dst=@EndObj); this table will have an identity column so subsequent queries
		--	can easily determine which ord value is associated with a particular position in a sequence
		declare @t table (
			Occurrence int identity(1,1),
			IsStart	tinyint,
			Ord int
		)

'
set @sDynSql2 = N'			
		-- determine if an end object was not specified, or if the start and end object are the same
		if @EndObj is null or (@EndObj = @StartObj) begin
			-- only collect occurrences for the start object

			-- limit the number of returned rows from a select based on the desired occurrence; this will
			--	avoid processing beyond the desired occurrence
			if @EndObj is null set rowcount @StartObjOccurrence
			else set rowcount @EndObjOccurrence

			-- insert all of the Ord values associated with @StartObj
			insert into @t (IsStart, Ord)
			select	1, [Ord]
			from	[' + @sTbl + '] 
			where	[Src] = @SrcObjId
				and [Dst] = @StartObj
			order by [Ord]
			set @Err = @@error
			if @Err <> 0 begin
				raiserror(''ReplaceRefSeq_'+@sTbl+': SQL Error %d; Unable to insert ord values into the temporary table'', 16, 1, @Err)
				goto LFail
			end

			-- make selects return all rows
			set rowcount 0

			-- determine if the end and start objects are the same; if they are then search for the
			--	end object''s ord value based on the specified occurrence
			if @EndObj = @StartObj begin
				select	@EndOrd = [Ord]
				from	@t
				where	[Occurrence] = @EndObjOccurrence
			end
		end
		else begin
			-- insert Ord values associated with @StartObj and @EndObj
			insert into @t ([IsStart], [Ord])
			select	case [Dst]
					when @StartObj then 1
					else 0
				end, 
				[Ord]
			from	[' + @sTbl + '] 
			where	[Src] = @SrcObjId
				and ( [Dst] = @StartObj
					or [Dst] = @EndObj )
			order by 1 desc, [Ord]
			set @Err = @@error
			if @Err <> 0 begin
				raiserror(''ReplaceRefSeq_'+@sTbl+': SQL Error %d; Unable to insert ord values into the temporary table'', 16, 1, @Err)
				goto LFail
			end
			
			-- get the end ord value associated with @EndObjOccurrence
			select	@EndOrd = [Ord]
			from	@t
			where	[IsStart] = 0
				and [Occurrence] = @EndObjOccurrence +
					( select max([Occurrence]) from @t where [IsStart] = 1 )
		end

		-- get the start ord value associated with @StartObjOccurrence
		select	@StartOrd = [Ord]
		from	@t
		where	[IsStart] = 1
			and [Occurrence] = @StartObjOccurrence

	end
'
set @sDynSql3 = N'
	-- validate the arguments
	if @StartOrd is null begin
		raiserror(''ReplaceRefSeq_'+@sTbl+': Unable to locate ordinal value: SrcObjId(Src) = %d, StartObj(Dst) = %d, StartObjOccurrence = %d'', 
				16, 1, @SrcObjId, @StartObj, @StartObjOccurrence)
		set @Err = 50001
		goto LFail
	end
	if @EndOrd is null and @EndObj is not null begin
		raiserror(''ReplaceRefSeq_'+@sTbl+': Unable to locate ordinal value: SrcObjId(Src) = %d, EndObj(Dst) = %d, EndObjOccurrence = %d'', 
				16, 1, @SrcObjId, @EndObj, @EndObjOccurrence)
		set @Err = 50002
		goto LFail
	end
	if @EndOrd is not null and @EndOrd < @StartOrd begin
		raiserror(''ReplaceRefSeq_'+@sTbl+': The starting ordinal value %d is greater than the ending ordinal value %d: SrcObjId(Src) = %d, StartObj(Dst) = %d, StartObjOccurrence = %d, EndObj(Dst) = %d, EndObjOccurrence = %d'', 
				16, 1, @StartOrd, @EndOrd, @SrcObjId, @StartObj, @StartObjOccurrence, @EndObj, @EndObjOccurrence)
		set @Err = 50003
		goto LFail
	end

	-- check for a delete/replace
	if @EndObj is not null begin
		
		delete	[' + @sTbl + '] with (serializable)
		where	[Src] = @SrcObjId
			and [Ord] >= @StartOrd
			and [Ord] <= @EndOrd
		set @Err = @@error
		if @Err <> 0 begin
			raiserror(''ReplaceRefSeq_'+@sTbl+': SQL Error %d; Unable to remove objects between %d and %d for source = %d'', 
					16, 1, @Err, @StartOrd, @EndOrd, @SrcObjId)
			goto LFail
		end
	end

	-- determine if any objects are going to be inserted
	if @hXMLDoc is not null begin
		-- get the number of objects to be inserted
		select	@nNumObjs = count(*)
		from 	openxml(@hXMLdoc, ''/root/Obj'') with (Id int)
		set @Err = @@error
		if @Err <> 0 begin
			raiserror(''ReplaceRefSeq_'+@sTbl+': SQL Error %d; Unable to process XML document: document handle = %d'', 
					16, 1, @hXMLdoc)
			goto LFail
		end
'
set @sDynSql4 = N'
		-- if the objects are not appended to the end of the list then determine if there is enough room
		if @StartObj is not null begin

			-- find the largest ordinal value less than the start object''s ordinal value
			select	@nMinOrd = coalesce(max([Ord]), -1) + 1
			from	['+@sTbl+'] with (serializable)
			where	[Src] = @SrcObjId
				and [Ord] < @StartOrd

			-- determine if a range of objects was deleted; if objects were deleted then there is more room
			--	available
			if @EndObj is not null begin
				-- the actual space available could be determined, but this would involve another
				--	query (this query would look for the minimum Ord value greater than @EndOrd); 
				--	however, it is known that at least up to the @EndObj is available

				set @nSpaceAvail = @EndOrd - @nMinOrd
				if @nMinOrd > 0 set @nSpaceAvail = @nSpaceAvail + 1
			end
			else begin
				set @nSpaceAvail = @StartOrd - @nMinOrd
			end

			-- determine if space needs to be made
			if @nSpaceAvail < @nNumObjs begin
				update	[' + @sTbl + '] with (serializable)
				set	[Ord] = [Ord] + @nNumObjs - @nSpaceAvail
				where	[Src] = @SrcObjId
					and [Ord] >= @nMinOrd
				set @Err = @@error
				if @Err <> 0 begin
					raiserror(''ReplaceRefSeq_'+@sTbl+': SQL Error %d; Unable to increment the ordinal values; src = %d'', 
							16, 1, @Err, @SrcObjId)
					goto LFail
				end
			end
		end
		else begin
			-- find the largest ordinal value plus one
			select	@nMinOrd = coalesce(max([Ord]), -1) + 1
			from	['+@sTbl+'] with (serializable)
			where	[Src] = @SrcObjId
		end

		insert into [' + @sTbl + '] with (serializable) ([Src], [Dst], [Ord])
		select	@SrcObjId, ol.[Id], ol.[Ord] + @nMinOrd
		from 	openxml(@hXMLdoc, ''/root/Obj'') with (Id int, Ord int) ol
		set @Err = @@error
		if @Err <> 0 begin
			raiserror(''ReplaceRefSeq_'+@sTbl+': SQL Error %d; Unable to insert objects into the reference sequence table'', 
					16, 1, @Err)
			goto LFail
		end
	end

	if @nTrnCnt = 0 commit tran @sTranName

	-- determine if the XML document should be removed
	if @fRemoveXMLdoc = 1 and @hXMLDoc is not null exec sp_xml_removedocument @hXMLDoc

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return 0

LFail:
	rollback tran @sTranName

	-- determine if the XML document should be removed
	if @fRemoveXMLdoc = 1 and @hXMLDoc is not null exec sp_xml_removedocument @hXMLDoc

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @Err
'

	exec ( @sDynSql + @sDynSql2 + @sDynSql3 + @sDynSql4 )
	set @Err = @@error
	if @Err <> 0 begin
		raiserror('DefineReplaceRefSeqProc: SQL Error %d: Unable to create or alter the procedure ReplaceRefSeq_%s$',
				16, 1, @Err, @sTbl)
		return @err
	end

	return 0
go





































if object_id('ReplaceRefSeq$') is not null begin
	print 'removing proc ReplaceRefSeq$'
	drop proc [ReplaceRefSeq$]
end
go
print 'creating proc ReplaceRefSeq$'
go
create proc [ReplaceRefSeq$]
	@flid int,
	@SrcObjId int,
	@ListStmp int,
	@hXMLdoc int,
	@StartObj int = null,
	@StartObjOccurrence int = 1,
	@EndObj int = null,
	@EndObjOccurrence int = 1,
	@fRemoveXMLDoc tinyint = 1
as
	declare @Err int
	declare	@sDynSql varchar(500)

	select	@sDynSql = 'exec ReplaceRefSeq_' + c.[Name] + '_' + f.[Name] + ' ' +
			coalesce(convert(varchar(11), @SrcObjId), 'null') + ',' +
			coalesce(convert(varchar(11), @ListStmp), 'null') + ',' +
			coalesce(convert(varchar(11), @hXMLdoc), 'null') + ',' +
			coalesce(convert(varchar(11), @StartObj), 'null') + ',' +
			coalesce(convert(varchar(11), @StartObjOccurrence), 'null') + ',' +
			coalesce(convert(varchar(11), @EndObj), 'null') + ',' +
			coalesce(convert(varchar(11), @EndObjOccurrence), 'null') + ',' +
			coalesce(convert(varchar(3), @fRemoveXMLDoc), 'null')
	from	Field$ f join Class$ c on f.[Class] = c.[Id]
	where	f.[Id] = @flid and f.[Type] = 28

	if @@rowcount <> 1 begin
		raiserror('ReplaceRefSeq$: Invalid flid: %d', 16, 1, @flid)
		return 50000
	end

	exec (@sDynSql)
	set @Err = @@error
	if @Err <> 0 begin
		raiserror('ReplaceRefSeq$: SQL Error %d: Unable to perform replace: %d', 16, 1, @Err, @sDynSql)
		return @Err
	end

	return 0
go


if not object_id('MoveToOwnedAtom$') is null begin print 'removing ' + 'proc' + ' ' + 'MoveToOwnedAtom$' drop proc MoveToOwnedAtom$ end
go
print 'creating proc MoveToOwnedAtom$'
go


































create proc MoveToOwnedAtom$
	@SrcObjId int,
	@SrcFlid int,
	@ObjId int = null,
	@DstObjId int,
	@DstFlid int
as
	declare @sTranName varchar(50)
	declare	@fIsNocountOn int, @Err int, @nTrnCnt int
	
	set @Err = 0
	
	-- transactions
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on
	set @sTranName = 'MoveToOwnedAtom$_' + convert(varchar(11), @@trancount)
	set @nTrnCnt = @@trancount
	if @nTrnCnt = 0 begin tran @sTranName
	else save tran @sTranName
	set @Err = @@error
	if @Err <> 0 begin
		raiserror('MoveToOwnedAtom$: SQL Error %d; Unable to create a transaction', 16, 1, @Err)
		goto LFail
	end
	
	update	CmObject with (repeatableread)
	set [Owner$] = @DstObjId,
		[OwnFlid$] = @DstFlid,
		[OwnOrd$] = null
	where [Id] = @ObjId
		
	set @Err = @@error
	if @Err <> 0 begin
		raiserror('MoveToOwnedAtom$: SQL Error %d; Unable to update owners in CmObject: DstObjId(Owner$) = %d, DstFlid(OwnFlid$) = %d', 
				16, 1, @Err, @DstObjId, @DstFlid)
		goto LFail
	end

	-- stamp the owning objects as updated
	update CmObject with (repeatableread)
		set [UpdDttm] = getdate()
		where [Id] in (@SrcObjId, @DstObjId)
		--( seems to execute as fast as a where clause written:
		--(    where [Id] = @SrcObjId or [Id] =@DstObjId
	
	if @nTrnCnt = 0 commit tran @sTranName
	
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return 0
	
LFail:
	rollback tran @sTranName
	
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @Err
GO


if not object_id('MoveToOwnedColl$') is null begin print 'removing ' + 'proc' + ' ' + 'MoveToOwnedColl$' drop proc MoveToOwnedColl$ end
go
print 'creating proc MoveToOwnedColl$'
go









































create proc MoveToOwnedColl$
	@SrcObjId int,		-- The ID of the object that owns the source object(s)
	@SrcFlid int,		-- The FLID (field ID) of the object attribute that owns the object(s)
	@StartObj int = null,	-- The ID of the first object to be moved.
	@EndObj int = null,	-- The ID of the last object to be moved
	@DstObjId int,		-- The ID of the object which will own the object(s) moved
	@DstFlid int		-- The FLID (field ID) of the object attribute that will own the object(s)
	
as
	declare @sTranName varchar(50)
	declare @StartOrd int, @EndOrd int
	declare	@fIsNocountOn int, @Err int, @nTrnCnt int, @nSrcType int

	-- Remark these constants for production code. For coding and testing with Query Analyzer,
	-- unremark these constants and put an @ in front of the variables wherever they appear.
	







	
	set @Err = 0
	
	-- transactions
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on
	set @sTranName = 'MoveToOwnedColl$_' + convert(varchar(11), @@trancount)
	set @nTrnCnt = @@trancount
	if @nTrnCnt = 0 begin tran @sTranName
	else save tran @sTranName
	set @Err = @@error
	if @Err <> 0 begin
		raiserror('MoveToOwnedColl$: SQL Error %d; Unable to create a transaction', 16, 1, @Err)
		goto LFail
	end
	
	select @nSrcType = [Type]
	from Field$
	where [id] = @SrcFlid
	
	if @nSrcType = 27 begin  --( If source object is an owning sequence

		select	@StartOrd = [OwnOrd$]
		from	CmObject (repeatableread)
		where	[Owner$] = @SrcObjId
			and [OwnFlid$] = @SrcFlid
			and [Id] = @StartObj
		
		if @EndObj is null begin
			select	@EndOrd = max([OwnOrd$])
			from	CmObject (serializable)
			where	[Owner$] = @SrcObjId
				and [OwnFlid$] = @SrcFlid
		end
		else begin
			select	@EndOrd = [OwnOrd$]
			from	CmObject (repeatableread)
			where	[Owner$] = @SrcObjId
				and [OwnFlid$] = @SrcFlid
				and [Id] = @EndObj
		end
		
		if @EndOrd is not null and @EndOrd < @StartOrd begin
			raiserror('MoveToOwnedColl$: The starting ordinal value %d is greater than the ending ordinal value %d in CmObject: SrcObjId(Owner$) = %d SrcFlid(OwnFlid$) = %d StartObj(Id) = %d EndObj(Id) = %d', 
					16, 1, @StartOrd, @EndOrd, @SrcObjId, @SrcFlid, @StartObj, @EndObj)
			set @Err = 51001
			goto LFail
		end
		
		update	CmObject with (repeatableread)
		set [Owner$] = @DstObjId,
			[OwnFlid$] = @DstFlid,
			[OwnOrd$] = null
		where	[Owner$] = @SrcObjId
			and [OwnFlid$] = @SrcFlid
			and [OwnOrd$] >= @StartOrd and [OwnOrd$] <= @EndOrd
	end
	else begin
		-- ENHANCE SteveMiller: Cannot yet move more than one object from a collection to a sequence.
		if @nSrcType = 25 and not @StartObj = @EndObj begin
			raiserror('MoveToOwnedSeq$: Cannot yet move more than one object from a collection to a sequence', 16, 1)
			set @Err = 51002
			goto LFail
		end
		
		update	CmObject with (repeatableread)
		set [Owner$] = @DstObjId,
			[OwnFlid$] = @DstFlid,
			[OwnOrd$] = null
		where [Id] = @StartObj
	end
		
	set @Err = @@error
	if @Err <> 0 begin
		raiserror('MoveToOwnedColl$: SQL Error %d; Unable to update owners in CmObject: DstObjId(Owner$) = %d, DstFlid(OwnFlid$) = %d, start = %d, end = %d', 
				16, 1, @Err, @DstObjId, @DstFlid, @StartOrd, @EndOrd)
		goto LFail
	end
	
	-- stamp the owning objects as updated
	update CmObject with (repeatableread)
		set [UpdDttm] = getdate()
		where [Id] in (@SrcObjId, @DstObjId)
		--( seems to execute as fast as a where clause written:
		--(    where [Id] = @SrcObjId or [Id] =@DstObjId

	if @nTrnCnt = 0 commit tran @sTranName
	
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return 0
	
LFail:
	rollback tran @sTranName
	
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @Err
go


if not object_id('MoveToOwnedSeq$') is null begin print 'removing ' + 'proc' + ' ' + 'MoveToOwnedSeq$' drop proc MoveToOwnedSeq$ end
go
print 'creating proc MoveToOwnedSeq$'
go














































CREATE proc MoveToOwnedSeq$
	@SrcObjId int,
	@SrcFlid int,
	@StartObj int,
	@EndObj int = null,
	@DstObjId int,
	@DstFlid int,
	@DstStartObj int = null
as
	declare @sTranName varchar(50)
	declare @nDstType int
	declare @nMinOrd int, @StartOrd int, @EndOrd int, @DstStartOrd int, @DstEndOrd int, @DstEndDelOrd int
	declare @nSpaceAvail int, @nSpaceNeed int, @nNewOrdOffset int, @fMadeSpace tinyint
	declare @uid uniqueidentifier
	declare	@fIsNocountOn int, @Err int, @nTrnCnt int, @UpdStmp int, @RetVal int, @nSrcType int

	-- Remark these constants for production code. For coding and testing with Query Analyzer,
	-- unremark these constants and put an @ in front of the variables wherever they appear.
	







	
	set @Err = 0
	set @fMadeSpace = 0
	
	--==Transactions ==--
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on
	
	-- determine if the procedure was called within a transaction; if yes then create a savepoint, 
	--	otherwise create a transaction
	set @sTranName = 'MoveToOwnedSeq$_' + convert(varchar(11), @@trancount)
	set @nTrnCnt = @@trancount
	if @nTrnCnt = 0 begin tran @sTranName
	else save tran @sTranName
	set @Err = @@error
	if @Err <> 0 begin
		raiserror('MoveToOwnedSeq$: SQL Error %d; Unable to create a transaction', 16, 1, @Err)
		goto LFail
	end
	
	--== Get Start and End Orders ==-
	
	--( See notes at the top of the file about the query where clause
	
	if @DstStartObj is null begin 
		select	@DstStartOrd = coalesce(max([OwnOrd$]), -1) + 1
		from	CmObject (serializable)
		where	[Owner$] = @DstObjId
			and [OwnFlid$] = @DstFlid
	end
	else begin
		select	@DstStartOrd = [OwnOrd$]
		from	CmObject (repeatableread)
		where	[Owner$] = @DstObjId
			and [OwnFlid$] = @DstFlid
			and [Id] = @DstStartObj
	end
	
	--( Get type (atomic, collection, or sequence) of source
	select @nSrcType = [Type]
	from Field$
	where [id] = @SrcFlid
	
	if @nSrcType = 27 begin  --( If source object is an owning sequence
		-- get the starting and ending ordinal values
		select	@StartOrd = [OwnOrd$]
		from	CmObject (repeatableread)
		where	[Owner$] = @SrcObjId
			and [OwnFlid$] = @SrcFlid
			and [Id] = @StartObj
		if @EndObj is null begin
			select	@EndOrd = max([OwnOrd$])
			from	CmObject (serializable)
			where	[Owner$] = @SrcObjId
				and [OwnFlid$] = @SrcFlid
		end
		else begin
			select	@EndOrd = [OwnOrd$]
			from	CmObject (repeatableread)
			where	[Owner$] = @SrcObjId
				and [OwnFlid$] = @SrcFlid
				and [Id] = @EndObj
		end
	end
	
	-- If source object is an owning collection
	else if @nSrcType = 25 begin
		 
		-- ENHANCE SteveMiller: Cannot yet move more than one object from a collection to a sequence.
		if not @StartObj = @EndObj begin
			raiserror('MoveToOwnedSeq$: Cannot yet move more than one object from a collection to a sequence', 16, 1)
			set @Err = 51000
			goto LFail
		end
			
		set @StartOrd = @DstStartOrd
		set @EndOrd = @StartOrd
	end
	
	-- If source object is an owning atom
	else if @nSrcType = 23 begin
		 
		if not @StartObj = @EndObj begin
			raiserror('MoveToOwnedSeq$: Cannot move two atoms at the same time', 16, 1)
			set @Err = 51001
			goto LFail
		end
		
		set @StartOrd = @DstStartOrd
		set @EndOrd = @StartOrd
	end
	
	set @DstEndOrd = @DstStartOrd + @EndOrd - @StartOrd
	
	--== Validate the arguments  ==--
	if @StartOrd is null begin
		raiserror('MoveToOwnedSeq$: Unable to locate ordinal value in CmObject: SrcObjId(Owner$) = %d SrcFlid(OwnFlid$) = %d StartObj(Id) = %d', 
				16, 1, @SrcObjId, @SrcFlid, @StartObj)
		set @Err = 51002
		goto LFail
	end
	if @EndOrd is null begin
		raiserror('MoveToOwnedSeq$: Unable to locate ordinal value in CmObject: SrcObjId(Owner$) = %d SrcFlid(OwnFlid$) = %d EndObj(Id) = %d', 
				16, 1, @SrcObjId, @SrcFlid, @EndObj)
		set @Err = 51003
		goto LFail
	end
	if @DstStartOrd is null begin
		raiserror('MoveToOwnedSeq$: Unable to locate ordinal value in CmObject: DstObjId(Owner$) = %d DstFlid(OwnFlid$) = %d DstStartObj(Id) = %d', 
				16, 1, @DstObjId, @DstFlid, @DstStartObj)
		set @Err = 51004
		goto LFail
	end
	if @EndOrd is not null and @EndOrd < @StartOrd begin
		raiserror('MoveToOwnedSeq$: The starting ordinal value %d is greater than the ending ordinal value %d in CmObject: SrcObjId(Owner$) = %d SrcFlid(OwnFlid$) = %d StartObj(Id) = %d EndObj(Id) = %d', 
				16, 1, @StartOrd, @EndOrd, @SrcObjId, @SrcFlid, @StartObj, @EndObj)
		set @Err = 51005
		goto LFail
	end
	
	-- if the objects are not appended to the end of the destination list then determine if there is enough room
	if @DstStartObj is not null begin
		
		-- find the object with the largest ordinal value less than the destination start object's ordinal
		select @nMinOrd = coalesce(max([OwnOrd$]), -1)
		from	CmObject with (serializable)
		where	[Owner$] = @DstObjId
			and [OwnFlid$] = @DstFlid
			and [OwnOrd$] < @DstStartOrd
		set @Err = @@error
		if @Err <> 0 begin
			raiserror('MoveToOwnedSeq$: SQL Error %d; Unable to analyze the sequence in CmObject: DstObjId(Owner$) = %d, DstFlid(OwnFlid$) = %d', 
					16, 1, @Err, @DstObjId, @DstFlid)
			goto LFail
		end
		
		set @nSpaceAvail = @DstStartOrd - @nMinOrd - 1
		set @nSpaceNeed = @EndOrd - @StartOrd + 1
		
		-- see if there is currently enough room for the objects under the destination object's sequence list; 
		--	if there is not then make room
		if @nSpaceAvail < @nSpaceNeed begin
			
			set @fMadeSpace = 1
			
			update	CmObject with (repeatableread)
			set	[OwnOrd$] = [OwnOrd$] + @nSpaceNeed - @nSpaceAvail
			where	[Owner$] = @DstObjId
				and [OwnFlid$] = @DstFlid
				and [OwnOrd$] >= @DstStartOrd
			set @Err = @@error
			if @Err <> 0 begin
				raiserror('MoveToOwnedSeq$: SQL Error %d; Unable to increment the ordinal values in the CmObject: DstObjId(Owner$) = %d, DstFlid(OwnFlid$) = %d', 
					16, 1, @Err, @DstObjId, @DstFlid)
				goto LFail
			end
		end
		
		set @nNewOrdOffset = @nMinOrd + 1 - @StartOrd
	end
	else begin
		set @nNewOrdOffset = @DstStartOrd - @StartOrd
	end
	
	-- determine if the source and destination owning sequence is the same
	if @SrcObjId = @DstObjId and @SrcFlid = @DstFlid begin
		
		-- if room was made below the objects that are to be moved then the objects to be moved also
		--	had their ordinal values modified, so calculate the new source ordinal numbers so that they
		--	will remain in the range of objects that are to be moved
		if @fMadeSpace = 1 and @StartOrd > @DstStartOrd begin
			set @StartOrd =  @StartOrd + @nSpaceNeed - @nSpaceAvail
			set @EndOrd = @EndOrd + @nSpaceNeed - @nSpaceAvail
			set @nNewOrdOffset = @DstStartOrd - @StartOrd
		end

		-- update the ordinals of the specified range of objects in the specified sequence
		update	CmObject with (repeatableread)
		set	[OwnOrd$] = [OwnOrd$] + @nNewOrdOffset
		where	[Owner$] = @SrcObjId
			and [OwnFlid$] = @SrcFlid
			and [OwnOrd$] >= @StartOrd
			and [OwnOrd$] <= @EndOrd
		set @Err = @@error
		if @Err <> 0 begin
			raiserror('MoveToOwnedSeq$: SQL Error %d; Unable to update ordinals in CmObject: DstObjId(Owner$) = %d, DstFlid(OwnFlid$) = %d, start = %d, end = %d', 
				16, 1, @Err, @DstObjId, @DstFlid, @StartOrd, @EndOrd)
			goto LFail
		end
	end
	
	-- destination and source are not the same	
	else begin
		if @nSrcType = 27 begin
			-- update the owner of the specified range of objects in the specified sequence
			update	CmObject with (repeatableread)
			set	[Owner$] = @DstObjId,
				[OwnFlid$] = @DstFlid,
				[OwnOrd$] = [OwnOrd$] + @nNewOrdOffset
			where	[Owner$] = @SrcObjId
				and [OwnFlid$] = @SrcFlid
				and [OwnOrd$] >= @StartOrd
				and [OwnOrd$] <= @EndOrd
		end
		else if @nSrcType = 25 or @nSrcType = 23 begin
			update	CmObject with (repeatableread)
			set	[Owner$] = @DstObjId,
				[OwnFlid$] = @DstFlid,
				[OwnOrd$] = @DstStartOrd + @nNewOrdOffset
			where	[Id] = @StartObj
		end
		
		set @Err = @@error
		if @Err <> 0 begin
			raiserror('MoveToOwnedSeq$: SQL Error %d; Unable to update owners in CmObject: DstObjId(Owner$) = %d, DstFlid(OwnFlid$) = %d, start = %d, end = %d', 
				16, 1, @Err, @DstObjId, @DstFlid, @StartOrd, @EndOrd)
			goto LFail
		end
	end
	
	-- stamp the owning objects as updated
	update CmObject with (repeatableread)
		set [UpdDttm] = getdate()
		where [Id] in (@SrcObjId, @DstObjId)
		--( seems to execute as fast as a where clause written:
		--(    where [Id] = @SrcObjId or [Id] =@DstObjId
	
	if @nTrnCnt = 0 commit tran @sTranName
	
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return 0
	
LFail:
	rollback tran @sTranName
	
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @Err
go


if not object_id('MoveOwnedObject$') is null begin print 'removing ' + 'proc' + ' ' + 'MoveOwnedObject$' drop proc MoveOwnedObject$ end
go
print 'creating proc MoveOwnedObject$'
go





















































create proc MoveOwnedObject$
	@SrcObjId int,
	@SrcFlid int,
	@ListStmp int,
	@StartObj int = null,
	@EndObj int = null,
	@DstObjId int,
	@DstFlid int,
	@DstStartObj int = null
as
	declare @Err int, @nDstType int
	
	









	
	set @Err = 0
	
	-- Get if atomic, collection, or sequence for destination
	select @nDstType = [Type]
	from Field$
	where [id] = @DstFlid
	
	-- Destination type is owning sequence	
	if @nDstType = 27 begin
		execute MoveToOwnedSeq$ @SrcObjId, @SrcFlid, @StartObj, @EndObj, @DstObjId, @DstFlid, @DstStartObj
	end
	
	-- Destinaton type is owning collection
	else if @nDstType = 25 begin
		execute MoveToOwnedColl$ @SrcObjId, @SrcFlid, @StartObj, @EndObj, @DstObjId, @DstFlid
	end
	
	-- Destination type is owning atomic
	else if @nDstType = 23 begin
		if not @StartObj = @EndObj begin
			set @Err = 51000 
			raiserror('MoveOwnedObject$: The starting and ending object IDs and  must be the same when moving an object to an owned atomic', 16, 1, @Err)
			goto LFail
		end
		execute MoveToOwnedAtom$ @SrcObjId, @SrcFlid, @StartObj, @DstObjId, @DstFlid
	end
	
	-- Other types not allowed
	else begin
		set @Err = 51001 
		raiserror('MoveOwnedObject$: Only owned sequences and collections allowed', 16, 1, @Err)
		goto LFail
	end
	
	return 0
	
LFail:
	return @Err
go


























if object_id('DeleteOwnSeq$') is not null begin
	print 'removing proc DeleteOwnSeq$'
	drop proc [DeleteOwnSeq$]
end
go
print 'creating proc DeleteOwnSeq$'
go
create proc [DeleteOwnSeq$]
	@SrcObjId int,
	@SrcFlid int,
	@ListStmp int,
	@StartObj int,
	@EndObj int = null
as
	declare @sTranName varchar(50)
	declare @StartOrd int, @EndOrd int
	declare @guid uniqueidentifier
	declare	@fIsNocountOn int, @Err int, @nTrnCnt int, @UpdStmp int

	set @Err = 0

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on











	-- determine if the procedure was called within a transaction; if yes then create a savepoint, 
	--	otherwise create a transaction
	set @sTranName = 'DeleteOwnSeq$_' + convert(varchar(11), @@trancount)
	set @nTrnCnt = @@trancount
	if @nTrnCnt = 0 begin tran @sTranName
	else save tran @sTranName
	set @Err = @@error
	if @Err <> 0 begin
		raiserror('DeleteOwnSeq$: SQL Error %d; Unable to create a transaction', 16, 1, @Err)
		goto LFail
	end	

	-- get the starting and ending ordinal values
	select	@StartOrd = [OwnOrd$]
	from	CmObject (repeatableread)
	where	[Owner$] = @SrcObjId
		and [OwnFlid$] = @SrcFlid
		and [Id] = @StartObj
	if @EndObj is null begin
		select	@EndOrd = max([OwnOrd$])
		from	CmObject (serializable)
		where	[Owner$] = @SrcObjId
			and [OwnFlid$] = @SrcFlid
	end
	else begin
		select	@EndOrd = [OwnOrd$]
		from	CmObject (repeatableread)
		where	[Owner$] = @SrcObjId
			and [OwnFlid$] = @SrcFlid
			and [Id] = @EndObj
	end
	
	-- validate the parameters
	if @StartOrd is null begin
		raiserror('DeleteOwnSeq$: Unable to locate ordinal value in CmObject: SrcObjId(Owner$) = %d SrcFlid(OwnFlid$) = %d StartObj(Id) = %d', 
				16, 1, @SrcObjId, @SrcFlid, @StartObj)
		set @Err = 51001
		goto LFail
	end
	if @EndOrd is null begin
		raiserror('DeleteOwnSeq$: Unable to locate ordinal value in CmObject: SrcObjId(Owner$) = %d SrcFlid(OwnFlid$) = %d EndObj(Id) = %d', 
				16, 1, @SrcObjId, @SrcFlid, @EndObj)
		set @Err = 51002
		goto LFail
	end
	if @EndOrd < @StartOrd begin
		raiserror('DeleteOwnSeq$: The starting ordinal value %d is greater than the ending ordinal value %d in CmObject: SrcObjId(Owner$) = %d SrcFlid(OwnFlid$) = %d StartObj(Id) = %d EndObj(Id) = %d', 
				16, 1, @StartOrd, @EndOrd, @SrcObjId, @SrcFlid, @StartObj, @EndObj)
		set @Err = 51004
		goto LFail
	end

	-- get the list of objects that are to be deleted and insert them into the ObjInfoTbl$ table
	set @guid = newid()
	insert into ObjInfoTbl$ with (rowlock) (uid, ObjId)
	select	@guid, [Id]
	from	CmObject with (serializable)
	where	[Owner$] = @SrcObjId
		and [OwnFlid$] = @SrcFlid
		and [OwnOrd$] >= @StartOrd
		and [OwnOrd$] <= @EndOrd
	set @Err = @@error
	if @Err <> 0 begin
		raiserror('DeleteOwnSeq$: SQL Error %d; Unable to insert objects into the ObjInfoTbl$; SrcObjId(Owner$) = %d SrcFlid(OwnFlid$) = %d StartObj(Id) = %d EndObj(Id) = %d', 
				16, 1, @Err, @SrcObjId, @SrcFlid, @StartObj, @EndObj)
		goto LFail
	end	
	
	-- delete the objects that were inserted into the ObjInfoTbl$
	exec @Err = DeleteObject$ @guid, null, 1
	if @Err <> 0 goto LFail

	if @nTrnCnt = 0 commit tran @sTranName

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return 0

LFail:
	rollback tran @sTranName

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @Err
go


























if object_id('UpdateClassView$') is not null begin
	print 'removing proc UpdateClassView$'
	drop proc [UpdateClassView$]
end
go
print 'creating proc UpdateClassView$'
go
create proc [UpdateClassView$]
	@clid int,
	@fRebuildSubClassViews tinyint=0
as
	declare @sTable sysname, @sBaseTable sysname, @sSubClass sysname
	declare @sField sysname, @flid int, @nType int
	declare @sDynSql nvarchar(4000), @sViewtext nvarchar(4000)
	declare @Err int, @fIsNocountOn int, @nTrnCnt int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on
	
	-- validate the parameter
	select	@sTable = c.[Name], @sBaseTable = base.[Name]
	from	[Class$] c join [Class$] base on c.[Base] = base.[Id]
	where	c.[Id] = @clid
	if @sTable is null begin
		raiserror('Invalid class id %d', 16, 1, @clid)
		return 50001
	end
	if @sBaseTable is null begin
		raiserror('The Class$ table has been corrupted', 16, 1)
		return 50002
	end

	-- If this procedure was called within a transaction, then create a savepoint; otherwise
	--	create a transaction.
	set @nTrnCnt = @@trancount
	if @nTrnCnt = 0 begin transaction UpdateClassView$_Tran
	else save transaction UpdateClassView$_Tran
	set @Err = @@error
	if @Err <> 0 goto LFail
	
	-- drop the existing view		
	set @sDynSql = N'if object_id(''' + @sTable + N'_'') is not null drop view [' + @sTable + N'_]'
	exec (@sDynSql)
	set @Err = @@error
	if @Err <> 0 goto LFail
	
	set @sDynsql = N'create view [' + @sTable + '_]' + char(13) +
		N'as' + char(13) + N'select [' + @sBaseTable + N'_].*'
	
	declare fld_cur cursor local static forward_only read_only for
	select	[Id], [Name], [Type] 
	from	[Field$]
	where	[Class] = @clid 
		and ([Type] <= 9 or [Type] in (13,15,17,19,24) ) 
	order by [Id]
	
	open fld_cur
	fetch fld_cur into @flid, @sField, @nType
	while @@fetch_status = 0 begin
		set @sDynSql = @sDynSql + N',[' + @sTable + N'].[' + @sField + N']'

		-- check for strings, which have an additional format column
		if @nType = 13 or @nType = 17 set @sDynSql = @sDynSql + N',[' + @sTable + N'].[' + @sField + N'_Fmt]'

		fetch fld_cur into @flid, @sField, @nType
	end
	close fld_cur
	deallocate fld_cur

	set @sDynSql = @sDynSql + char(13) + N'from [' + @sBaseTable + N'_] join [' + @sTable + N'] on [' +
		@sBaseTable + N'_].[Id] = [' + @sTable + N'].[Id]'
	exec (@sDynSql)
	set @Err = @@error
	if @Err <> 0 goto LFail

	if @fRebuildSubClassViews = 1 begin

		-- Refresh all the views that depend on this class. This is necessary because views 
		--	based on the * operator are not automatically updated when tables are altered
		declare SubClass_cur cursor local static forward_only read_only for
		select	c.[Name]
		from	[ClassPar$] cp join [Class$] c on cp.[Src] = c.[Id]
		where	[Dst] = @clid
			and [Depth] > 0
		order by [Depth] desc

		open SubClass_cur
		fetch SubClass_cur into @sSubClass
		while @@fetch_status = 0 begin

			-- store the view contents
			select	@sViewText = [text]
			from	syscomments
			where	id = object_id(@sSubClass+'_')
			if @@rowcount <> 1 begin
				if @@rowcount = 0 begin
					raiserror('Could not find contents of view %s_', 16, 1, @sSubClass)
					set @Err = 50003
					goto LFail
				end
				-- if this happens a new approach will be necessary!!
				raiserror('View is too large to fit into an 8K page and could not be recreated', 16, 1)
				set @Err = 50004
				goto LFail
			end

			-- remove the current view
			set @sDynSql = N'drop view [' + @sSubClass + '_]'
			exec ( @sDynSql )
			set @Err = @@error
			if @Err <> 0 goto LFail

			-- rebuild the view
			exec ( @sViewtext )
			set @Err = @@error
			if @Err <> 0 goto LFail

			fetch SubClass_cur into @sSubClass
		end
		close SubClass_cur
		deallocate SubClass_cur
	end

	if @nTrnCnt = 0 commit tran UpdateClassView$_Tran

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	return 0

LFail:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	rollback tran UpdateClassView$_Tran
	return @Err
go



























if object_id('AddCustomField$') is not null begin
	print 'removing proc AddCustomField$'
	drop proc [AddCustomField$]
end
go
print 'creating proc AddCustomField$'
go
create proc [AddCustomField$]
	@flid int output,
	@name varchar(100),
	@type int,
	@clid int,
	@clidDst int = null,
	@Min bigint = null,
	@Max bigint = null,
	@Big bit = null,
	@nvcUserLabel	NVARCHAR(100) = NULL,
	@nvcHelpString	NVARCHAR(100) = NULL,
	@nListRootId	INT  = NULL,
	@nWsSelector	INT = NULL,
	@ntXmlUI		NTEXT = NULL
AS
	declare @flidNew int, @flidMax int
	declare @sql varchar(1000)
	declare @Err int

	-- If this procedure was called within a transaction, then create a savepoint; otherwise
	-- create a transaction.
	declare @nTrnCnt int
	set @nTrnCnt = @@trancount
	if @nTrnCnt = 0 begin tran AddCustomField$_Tran
	else save tran AddCustomField$_Tran

	-- calculate the new flid
	select	@flidMax = max([Id]) 
	from	[Field$] (serializable) 
	where	[Class] = @clid
	if @flidMax is null or @flidMax - @clid * 1000 < 500 set @flidNew = 1000 * @clid + 500
	else set @flidNew = @flidMax + 1
	set @flid = @flidNew

	-- perform the insert into Field$
	insert into [Field$] ([Id], [Type], [Class], [DstCls], [Name], [Custom], [Min], [Max], [Big],
		UserLabel, HelpString, ListRootId, WsSelector, XmlUI)
	values (@flidNew, @type, @clid, @clidDst, @name, 1, @Min, @Max, @Big,
		@nvcUserLabel, @nvcHelpString, @nListRootId, @nWsSelector, @ntXmlUI)

	set @Err = @@error
	if @Err <> 0 goto HandleError

	if @nTrnCnt = 0 commit tran AddCustomField$_Tran
	return 0

HandleError:
	rollback tran AddCustomField$_Tran
	return @Err
go























if object_id('TR_Field$_UpdateModel_Ins') is not null begin
	print 'removing trigger TR_Field$_UpdateModel_Ins'
	drop trigger [TR_Field$_UpdateModel_Ins]
end
go
print 'creating trigger TR_Field$_UpdateModel_Ins'
go
create trigger [TR_Field$_UpdateModel_Ins] on [Field$] for insert 
as
	declare @sFlid VARCHAR(20)
	declare @Type INT
	declare @Clid INT
	declare @DstCls INT
	declare @sName sysname
	declare @sClass sysname
	declare @sTargetClass sysname
	declare @Min BIGINT
	declare @Max BIGINT
	declare @Big BIT
	declare @fIsCustom bit

	declare @sql NVARCHAR(1000)
	declare @Err INT
	declare @fIsNocountOn INT

	declare @sMin VARCHAR(25)
	declare @sMax VARCHAR(25)
	declare @sTable VARCHAR(20)
	declare @sFmtArg VARCHAR(40)

	declare @sTableName sysname

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- get the first class to process
	Select @sFlid= min([id]) from inserted
	
	-- loop through all of the classes in the inserted logical table
	while @sFlid is not null begin

		-- get inserted data
		select 	@Type = [Type], @Clid = [Class], @sName = [Name], @DstCls = [DstCls], @Min = [Min], @Max = [Max], @Big = [Big], @fIsCustom = [Custom]
		from	inserted i 
		where	[Id] = @sFlid

		-- get class name
		select 	@sClass = [Name]  from class$  where [Id] = @Clid

		-- get target class for Reference Objects
		if @Type in (24,26,28) begin
			select 	@sTargetClass = [Name]  from class$  where [Id] = @DstCls
		end

		if @type = 2 begin

			set @sMin = coalesce(convert(varchar(25), @Min), 0)
			set @sMax = coalesce(convert(varchar(25), @Max), 0)

			-- Add Integer to table sized based on Min/Max values supplied
			set @sql = 'ALTER TABLE [' + @sClass + '] ADD [' + @sName + '] '

			if @Min >= 0 and @Max <= 255
				set @sql = @sql + 'TINYINT NOT NULL DEFAULT ' + @sMin
			else if @Min >= -32768 and @Max <= 32767
				set @sql = @sql + 'SMALLINT NOT NULL DEFAULT ' + @sMin
			else if @Min < -2147483648 or @Max > 2147483647
				set @sql = @sql + 'BIGINT NOT NULL DEFAULT ' + @sMin
			else
				set @sql = @sql + 'INT NOT NULL DEFAULT ' + @sMin
			exec (@sql)
			if @@error <> 0 goto LFail

			-- Add Check constraint
			if @Min is not null and @Max is not null begin
				-- format as text

				set @sql = 'ALTER TABLE [' + @sClass + '] ADD CONSTRAINT [' +
					'_CK_' + @sClass + '_' + @sName + '] ' + CHAR(13) + CHAR(9) +
					' check ( [' + @sName + '] is null or ([' + @sName + '] >= ' + @sMin + ' and  [' + @sName + '] <= ' + @sMax + '))'
				exec (@sql)
				set @Err = @@error
				if @Err <> 0 goto LFail
			end
			
			-- fix the view associated with this class.
			if @fIsCustom = 1 begin
				exec @Err = UpdateClassView$ @clid, 1
				if @Err <> 0 goto LFail
			end
			
		end
		else if @type IN (14,16,18,20) begin
			-- Define the view or table for this multilingual custom field

			set @sTable = case @type
				when 14 then 'MultiStr$'
				when 18 then 'MultiBigStr$'
				when 20 then 'MultiBigTxt$'
				end
			set @sFmtArg = case @type
				when 14 then '[Fmt]'
				when 18 then '[Fmt]'
				when 20 then 'cast(null as varbinary) as [Fmt]'
				end
			
			IF @type = 16 BEGIN
				-- TODO (SteveMiller): The Txt field really ought to be cut down
				-- to 83 or less for a number of reasons. First, indexes don't do
				-- a whole lot of good when they get beyond 83 characters. Second,
				-- a lot of these fields probably don't need more than 80, and if
				-- they do, ought to be put in a different field. Third, Firebird
				-- indexes don't go beyond 83.
				--
				-- The fields currently larger than 83 (or 40, for that matter),
				-- is flids 7001 and 20002. 6001004 does in TestLangProj, but that's
				-- "bogus data". These two might become MultiBigTxt fields. Ideally,
				-- word forms ought to be cut down to 83, but Ken indicates that
				-- idioms might be stored there.
				
				--( See notes under string tables about Latin1_General_BIN
				
				SET @sql = N'CREATE TABLE ' + @sClass + N'_' + @sName + N' ( ' + CHAR(13) + CHAR(10) +
					CHAR(9) + N'[Obj] INT NOT NULL, ' + CHAR(13) + CHAR(10) +
					CHAR(9) + N'[Ws] INT NOT NULL, ' + CHAR(13) + CHAR(10) +
					CHAR(9) + N'[Txt] NVARCHAR(4000) COLLATE Latin1_General_BIN NOT NULL)'
				EXEC sp_executesql @sql
				
				-- REVIEW (SteveMiller): If Txt were added in this index, we could
				-- have a sort on the primary analysis language in most cases.
				-- However, the current length prohibits from doing so. If the
				-- length of most fields gets cut down to 83 or less, then this
				-- sort of index becomes possible.
				
				SET @sql = N'CREATE INDEX pk_' + @sClass + N'_' + @sName +
					N' ON ' + @sClass + N'_' + @sName + N'(Obj, WS)'
				EXEC sp_executesql @sql
			END
			ELSE BEGIN
	  			set @sql = 'CREATE VIEW [' + @sClass + '_' + @sName + '] AS' + CHAR(13) + CHAR(10) +
	  				CHAR(9) + 'select [Obj], [Flid], [Ws], [Txt], ' + @sFmtArg + CHAR(13) + CHAR(10) +
	  				CHAR(9) + 'FROM [' + @sTable + ']' + CHAR(13) + CHAR(10) +
	  				CHAR(9) + 'WHERE [Flid] = ' + @sFlid
	  			exec (@sql)
			END
			if @@error <> 0 goto LFail
			
		end
		else if @type IN (23,25,27) begin
			-- define the view for this OwningAtom/Collection/Sequence custom field.
			set @sql = 'CREATE VIEW [' + @sClass + '_' + @sName + '] AS' + CHAR(13) + CHAR(10) +
				CHAR(9) + 'select [Owner$] as [Src], [Id] as [Dst]' 
			
			if @type = 27 set @sql = @sql + ', [OwnOrd$] as [Ord]'

			set @sql = @sql + CHAR(13) +
				CHAR(9) + 'FROM [CmObject]' + CHAR(13) + CHAR(10) +
				CHAR(9) + 'WHERE [OwnFlid$] = ' + @sFlid
			exec (@sql)
			if @@error <> 0 goto LFail

			--( Adding an owning atomic StText field requires all existing instances
			--( of the owning class to possess an empty StText and StTxtPara.
				
			IF @type = 23 AND @DstCls = 14 BEGIN				
				SET @sql = '
				DECLARE @recId INT,
					@newId int,
					@dummyId int,
					@dummyGuid uniqueidentifier
				
				DECLARE curOwners CURSOR FOR SELECT [id] FROM ' + @sClass + '
				OPEN curOwners
				FETCH NEXT FROM curOwners INTO @recId
				WHILE @@FETCH_STATUS = 0
				BEGIN
					EXEC CreateObject_StText
						0, @recId, ' + @sFlid + ', null, @newId OUTPUT, @dummyGuid OUTPUT
					EXEC CreateObject_StTxtPara
						null, null, null, null, null, null, @newId, 14001, null, @dummyId, @dummyGuid OUTPUT
					FETCH NEXT FROM curOwners INTO @recId
				END
				CLOSE curOwners
				DEALLOCATE curOwners'
				
				EXEC (@sql)
			END
			
		end
		else if @type IN (26,28) begin
			-- define the table for this custom reference collection/sequence field.
			set @sql = 'CREATE TABLE [' + @sClass + '_' + @sName + '] (' + CHAR(13) +
				'[Src] INT NOT NULL,' + CHAR(13) +
				'[Dst] INT NOT NULL,' + CHAR(13) 

			if @type = 28 set @sql = @sql + '[Ord] INT NOT NULL,' + CHAR(13)

			set @sql = @sql +
				'CONSTRAINT [_FK_' + @sClass + '_' + @sName + '_Src] ' +
				'FOREIGN KEY ([Src]) REFERENCES [' + @sClass + '] ([Id]),' + CHAR(13) +
				'CONSTRAINT [_FK_' + @sClass + '_' + @sName + '_Dst] ' +
				'FOREIGN KEY ([Dst]) REFERENCES [' + @sTargetClass + '] ([Id]),' + CHAR(13) +
				case @type
					when 26 then ')'
					when 28 then
						CHAR(9) + CHAR(9) + 'CONSTRAINT [_PK_' + @sClass + '_' + @sName + '] ' + 
						'PRIMARY KEY CLUSTERED ([Src], [Ord])' + CHAR(13) + ')'
					end
			exec (@sql)
			if @@error <> 0 goto LFail

			if @type = 26 begin
				set @sql = 'create clustered index ' + 
						@sClass + '_' + @sName + '_ind on ' + 
						@sClass + '_' + @sName + ' ([Src], [Dst])'
				exec (@sql)
				if @@error <> 0 goto LFail

				set @sTableName = @sClass + '_' + @sName
				exec @Err = DefineReplaceRefCollProc$ @sTableName
				if @Err <> 0 begin
					raiserror('TR_Field$_UpdateModel_Ins: Unable to create the procedure that handles reference collections for table %s',
							16, 1, @sName)
					goto LFail
				end

			end

			if @type = 28 begin
				set @sTableName = @sClass + '_' + @sName
				exec @Err = DefineReplaceRefSeqProc$ @sTableName, @sFlid
				if @Err <> 0 begin
					raiserror('TR_Field$_UpdateModel_Ins: Unable to create the procedure that handles reference sequences for table %s',
							16, 1, @sName)
					goto LFail
				end
			end
			
		--( Insert trigger
			SET @sql = 'CREATE TRIGGER [TR_' + @sClass + '_' + @sName + '_DtTmIns]' + CHAR(13) +
				CHAR(9) + 'ON [' + @sClass + '_' + @sName + '] FOR INSERT ' + CHAR(13) +
				'AS ' + CHAR(13) +
				CHAR(9) + 'UPDATE CmObject SET UpdDttm = GetDate() ' + CHAR(13) + 
				CHAR(9) + CHAR(9) + 'FROM CmObject co JOIN inserted ins ON co.[id] = ins.[src] ' + CHAR(13) +
				CHAR(9) + CHAR(13)  + 
				CHAR(9) + 'IF @@error <> 0 BEGIN' + CHAR(13) +
				CHAR(9) + CHAR(9) + 'Raiserror(''TR_' + @sClass + '_' + @sName + '_DtTmIns]: ' + 
					'Unable to update CmObject'', 16, 1)' + CHAR(13) +
				CHAR(9) + CHAR(9) + 'GOTO LFail' + CHAR(13) + 
				CHAR(9) + 'END' + CHAR(13) +
				CHAR(9) + 'RETURN' + CHAR(13) +
				CHAR(9) + CHAR(13) +
				CHAR(9) + 'LFail:' + CHAR(13) +
				CHAR(9) + CHAR(9) + 'ROLLBACK TRAN' + CHAR(13) + 
				CHAR(9) + CHAR(9) + 'RETURN' + CHAR(13)		
			EXEC (@sql)
			IF @@error <> 0 GOTO LFail

			--( Delete trigger
			SET @sql = 'CREATE TRIGGER [TR_' + @sClass + '_' + @sName + '_DtTmDel]' + CHAR(13) +
				CHAR(9) + 'ON [' + @sClass + '_' + @sName + '] FOR DELETE ' + CHAR(13) +
				'AS ' + CHAR(13) +
				CHAR(9) + 'UPDATE CmObject SET UpdDttm = GetDate() ' + CHAR(13) + 
				CHAR(9) + CHAR(9) + 'FROM CmObject co JOIN deleted del ON co.[id] = del.[src] ' + CHAR(13) +
				CHAR(9) + CHAR(13)  + 
				CHAR(9) + 'IF @@error <> 0 BEGIN' + CHAR(13) +
				CHAR(9) + CHAR(9) + 'Raiserror(''TR_' + @sClass + '_' + @sName + '_DtTmDel]: ' + 
					'Unable to update CmObject'', 16, 1)' + CHAR(13) +
				CHAR(9) + CHAR(9) + 'GOTO LFail' + CHAR(13) + 
				CHAR(9) + 'END' + CHAR(13) +
				CHAR(9) + 'RETURN' + CHAR(13) +
				CHAR(9) + CHAR(13) +
				CHAR(9) + 'LFail:' + CHAR(13) +
				CHAR(9) + CHAR(9) + 'ROLLBACK TRAN' + CHAR(13) + 
				CHAR(9) + CHAR(9) + 'RETURN' + CHAR(13)		
			EXEC (@sql)
			IF @@error <> 0 GOTO LFail
			
		end
		else begin
			-- add the custom field to the appropriate table
			set @sql = 'ALTER TABLE [' + @sClass + '] ADD [' + @sName + '] ' + case
				when @type = 1 then 'BIT NOT NULL DEFAULT 0'			-- Boolean
				when @type = 3 then 'DECIMAL(28,4) NOT NULL DEFAULT 0'		-- Numeric
				when @type = 4 then 'FLOAT NOT NULL DEFAULT 0.0'		-- Float
				-- Time: default to current time except for fields in LgWritingSystem.
				when @type = 5 AND @sClass != 'LgWritingSystem' then 'DATETIME NULL DEFAULT GETDATE()'
				when @type = 5 AND @sClass = 'LgWritingSystem' then 'DATETIME NULL'
				when @type = 6 then 'UNIQUEIDENTIFIER NULL'			-- Guid
				when @type = 7 then 'IMAGE NULL'				-- Image
				when @type = 8 then 'INT NOT NULL DEFAULT 0'			-- GenDate
				when @type = 9 and @big = 0 then 'VARBINARY(8000) NULL'		-- Binary
				when @type = 9 and @big = 1 then 'IMAGE NULL'			-- Binary
				when @type = 13 then 'NVARCHAR(4000) NULL'			-- String
				when @type = 15 then 'NVARCHAR(4000) NULL'			-- Unicode
				when @type = 17 then 'NTEXT NULL'				-- BigString
				when @type = 19 then 'NTEXT NULL'				-- BigUnicode
				when @type = 24 then 'INT NULL'					-- ReferenceAtom
				end
			exec (@sql)
			if @@error <> 0 goto LFail
			if @type in (13,17)  begin
				set @sql = 'ALTER TABLE [' + @sClass + '] ADD ' + case @type
					when 13 then '[' + @sName + '_Fmt] VARBINARY(8000) NULL' -- String
					when 17 then '[' + @sName + '_Fmt] IMAGE NULL'			-- BigString
					end
				exec (@sql)
				set @Err = @@error
				if @Err <> 0 goto LFail
			end

			-- Set the 'Text In Row' option for the table if type is 7, 17 or 19.
			if @type in (7, 17, 19) exec sp_tableoption @sClass, 'text in row', '1000'

			-- don't create foreign key constraints on CmObject
			if @type = 24 and @sTargetClass != 'CmObject' begin
				set @sql = 'ALTER TABLE [' + @sClass + '] ADD CONSTRAINT [' +		-- ReferenceAtom
					'_FK_' + @sClass + '_' + @sName + '] ' + CHAR(13) + CHAR(9) +
					' FOREIGN KEY ([' + @sName + ']) REFERENCES [' + @sTargetClass + '] ([Id])'
				exec (@sql)
				set @Err = @@error
				if @Err <> 0 goto LFail
			end

			-- fix the view associated with this class.
			if @fIsCustom = 1 begin
				exec @Err = UpdateClassView$ @clid, 1
				if @Err <> 0 goto LFail
			end
		end
		
		-- get the next class to process
		Select @sFlid= min([id]) from inserted  where [Id] > @sFlid

	end  -- While loop

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return

LFail:
	rollback tran
	return
go














if object_id('TR_Field$_UpdateModel_Del') is not null begin
	print 'removing trigger TR_Field$_UpdateModel_Del'
	drop trigger TR_Field$_UpdateModel_Del
end
go
print 'creating trigger TR_Field$_UpdateModel_Del'
go
create trigger TR_Field$_UpdateModel_Del on Field$ for delete 
as
	declare @Clid INT
	declare @DstCls INT
	declare @sName VARCHAR(100)
	declare @sClass VARCHAR(100)
	declare @sFlid VARCHAR(20)
	declare @Type INT

	declare @Err INT
	declare @fIsNocountOn INT
	declare @sql VARCHAR(1000)

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- get the first custom field to process
	Select @sFlid= min([id]) from deleted

	-- loop through all of the custom fields to be deleted
	while @sFlid is not null begin

		-- get deleted fields
		select 	@Type = [Type], @Clid = [Class], @sName = [Name], @DstCls = [DstCls]
		from	deleted 
		where	[Id] = @sFlid

		-- get class name
		select 	@sClass = [Name]  from class$  where [Id] = @Clid

		if @type IN (14,16,18,20) begin
			-- Remove any data stored for this multilingual custom field.
			declare @sTable VARCHAR(20)
			set @sTable = case @type
				when 14 then 'MultiStr$'
				when 16 then 'MultiTxt$'
				when 18 then 'MultiBigStr$'
				when 20 then 'MultiBigTxt$'
				end
			IF @type != 16  -- MultiTxt$ data will be deleted when the table is dropped
				set @sql = 'DELETE FROM [' + @sTable + '] WHERE [Flid] = ' + @sFlid
			exec (@sql)
			set @Err = @@error
			if @Err <> 0 goto LFail
			
			-- Remove the view created for this multilingual custom field.
			IF @type != 16
				set @sql = 'DROP VIEW [' + @sClass + '_' + @sName + ']'
			ELSE
				SET @sql = 'DROP TABLE [' + @sClass + '_' + @sName + ']'
			exec (@sql)
			set @Err = @@error
			if @Err <> 0 goto LFail
		end
		else if @type IN (23,25,27) begin
			-- Remove the view created for this custom OwningAtom/Collection/Sequence field.
			set @sql = 'DROP VIEW [' + @sClass + '_' + @sName + ']'
			exec (@sql)
			set @Err = @@error
			if @Err <> 0 goto LFail
			-- Check for any objects stored for this custom OwningAtom/Collection/Sequence field.
			declare @DelId INT
			select @DelId = [Id] FROM CmObject  WHERE [OwnFlid$] = @sFlid
			set @Err = @@error
			if @Err <> 0 goto LFail
			if @DelId is not null begin
				raiserror('TR_Field$_UpdateModel_Del: Unable to remove %s field until corresponding objects are deleted',
						16, 1, @sName)
				goto LFail
			end
		end
		else if @type IN (26,28) begin
			-- Remove the table created for this custom ReferenceCollection/Sequence field.
			set @sql = 'DROP TABLE [' + @sClass + '_' + @sName + ']'
			exec (@sql)
			set @Err = @@error
			if @Err <> 0 goto LFail

			-- Remove the procedure that handles reference collections or sequences for 
			-- the dropped table
			set @sql = N'
				IF OBJECT_ID(''ReplaceRefColl_' + @sClass +  '_' + @sName + ''') IS NOT NULL
					DROP PROCEDURE [ReplaceRefColl_' + @sClass + '_' + @sName + ']
				IF OBJECT_ID(''ReplaceRefSeq_' + @sClass +  '_' + @sName + ''') IS NOT NULL
					DROP PROCEDURE [ReplaceRefSeq_' + @sClass + '_' + @sName + ']'
			exec (@sql)
			set @Err = @@error
			if @Err <> 0 goto LFail
		end
		else begin
			-- Remove the format column created if this was a custom String field.
			if @type in (13,17) begin
				set @sql = 'ALTER TABLE [' + @sClass + '] DROP COLUMN [' + @sName + '_Fmt]'
				exec (@sql)
				set @Err = @@error
				if @Err <> 0 goto LFail
			end
			-- Remove the constraint created if this was a custom ReferenceAtom field.
			-- Not necessary for CmObject : Foreign Key constraints are not created agains CmObject
			if @type = 24 begin
				declare @sTarget VARCHAR(100)
				select @sTarget = [Name] FROM [Class$] WHERE [Id] = @DstCls
				set @Err = @@error
				if @Err <> 0 goto LFail
				if @sTarget != 'CmObject' begin
					set @sql = 'ALTER TABLE [' + @sClass + '] DROP CONSTRAINT [' +
						'_FK_' + @sClass + '_' + @sName + ']'
					exec (@sql)
					set @Err = @@error
					if @Err <> 0 goto LFail
				end
			end
			-- Remove Default Constraint from Numeric fields before dropping the column
			If @type in (1,2,3,4,8) begin
				select @sql = 'ALTER TABLE [' + @sClass + '] DROP CONSTRAINT [' + so.name + ']'
				from sysconstraints sc
					join sysobjects so on so.id = sc.constid and so.name like 'DF[_]%'
					join sysobjects so2 on so2.id = sc.id
					join syscolumns sco on sco.id = sc.id and sco.colid = sc.colid
				where so2.name = @sClass   -- Tablename
				and   sco.name = @sName    -- Fieldname
				and   so2.type = 'U'	   -- Userdefined table
				exec (@sql)
				set @Err = @@error
				if @Err <> 0 goto LFail
			end
			-- Remove the column created for this custom field.
			set @sql = 'ALTER TABLE [' + @sClass + '] DROP COLUMN [' + @sName + ']'
			exec (@sql)
			set @Err = @@error
			if @Err <> 0 goto LFail
			-- fix the view associated with this class.
			exec @Err = UpdateClassView$ @Clid, 1
			if @Err <> 0 goto LFail
		end

		-- get the next custom field to process
		Select @sFlid= min([id]) from deleted  where [Id] > @sFlid

	end -- While loop

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return

LFail:
	rollback tran
	return
go

















if object_id('TR_Field$_No_Upd') is not null begin
	print 'removing trigger TR_Field$_No_Upd'
	drop trigger [TR_Field$_No_Upd]
end
go
print 'creating trigger TR_Field$_No_Upd'
go
create trigger [TR_Field$_No_Upd] on [Field$] for update 
as
	
	DECLARE @nId INT
	
	--( This doesn't deal with IDs. Hopefully no on will ever be so rash
	--( as to do that.
	
	--( Many of the fields have constraints of their own, which makes it 
	--( hard to meet or test the conditions below.
	
	SELECT @nId = i.[Id]
	FROM inserted i
	JOIN deleted d ON d.[Id] = i.[Id]
	WHERE COALESCE(i.Type, 0) != COALESCE(d.Type, 0)
		OR COALESCE(i.Class, 0) != COALESCE(d.Class, 0)
		OR COALESCE(i.DstCls, 0) != COALESCE(d.DstCls, 0)
		OR i.[Name] != d.[Name]
		OR i.Custom != d.Custom
		--( Guids are 36 in length, but just in case...
		OR COALESCE(CONVERT(VARCHAR(100), i.CustomId), '0') != COALESCE(CONVERT(VARCHAR(100), d.CustomId), '0')
		OR COALESCE(i.[Min], 0) != COALESCE(d.[Min], 0)
		OR COALESCE(i.[Max], 0) != COALESCE(d.[Max], 0)
		OR COALESCE(i.Big, 0) != COALESCE(d.Big, 0)
	
	--( This forms a kind of assert. No one should be touching the metadata fields
	--( of Field$
	IF @@ROWCOUNT != 0 BEGIN
		raiserror('Update is not allowed on the Field$ table metadata fields.  Delete the field record and reinsert it with the new values.', 16, 1)
		rollback tran
	END
	
	return
go

















IF OBJECT_ID('CreateFlidCollations') IS NOT NULL BEGIN
	PRINT 'removing procedure CreateFlidCollations'
	DROP PROCEDURE [CreateFlidCollations]
END
GO
PRINT 'creating procedure CreateFlidCollations'
GO
CREATE PROCEDURE [CreateFlidCollations]
	@nEncID INT,
	@nCollationID INT,
	@nFlid INT
AS

	-- TODO (SteveMi): Only certain strings should have FlidCollation
	-- and MultiTxtSortKey$

	IF @nEncId IS NOT NULL
		PRINT 'todo'
		-- TODO (SteveMi): this chunk
	
	ELSE IF @nCollationID IS NOT NULL
		PRINT 'todo'
		-- TODO (SteveMi): this chunk
	
	ELSE IF @nFlid IS NOT NULL
		
		--( We want to create flidcollations only for current writing systems.
		--( We also don't want to duplicate any Writing System/Collation/Flid
		--( combination.
		
		INSERT INTO FlidCollation$ ([Ws], [CollationId], [Flid])
		SELECT curwritingsys.[Ws], wsc.[Dst] AS [CollationID], @nFlid AS [Flid]
		FROM (
			SELECT [Dst] AS [Ws] FROM LanguageProject_CurrentAnalysisWritingSystems
			UNION
			SELECT [Dst] AS [Ws] FROM LanguageProject_CurrentVernacularWritingSystems) curwritingsys
		JOIN LgWritingSystem_Collations wsc ON wsc.[Src] = curwritingsys.[Ws]
		LEFT OUTER JOIN FlidCollation$ fc ON 
			fc.[Ws] = curwritingsys.[Ws] AND
			fc.[CollationID] = wsc.[Dst] AND 
			fc.[Flid] = @nFlid
		WHERE (
			fc.[Ws] IS NULL OR
			fc.[CollationID] IS NULL OR
			fc.[Flid] IS NULL)
	
	--( The insert into FlidCollation$ should trigger an insert trigger
	--( sort key creation in MultiTxtSortKey$

	-- TODO (SteveMi): above comment.
		
GO













IF OBJECT_ID('DeleteFlidCollations') IS NOT NULL BEGIN
	PRINT 'removing procedure DeleteFlidCollations'
	DROP PROCEDURE [DeleteFlidCollations]
END
GO
PRINT 'creating procedure DeleteFlidCollations'
GO
CREATE PROCEDURE [DeleteFlidCollations]
	@nEncID INT,
	@nCollationID INT,
	@nFlid INT
AS

	-- TODO (SteveMi): Only certain strings should have FlidCollation
	-- and MultiTxtSortKey$

	IF @nEncId IS NOT NULL
		PRINT 'todo'
		-- TODO (SteveMi): this chunk
	
	ELSE IF @nCollationID IS NOT NULL
		PRINT 'todo'
		-- TODO (SteveMi): this chunk
	
	ELSE IF @nFlid IS NOT NULL
		

		INSERT INTO FlidCollation$ ([Ws], [CollationId], [Flid])
		SELECT e.[Ws], wsc.[Dst] AS [CollationID], @nFlid AS [Flid]
		FROM (
			SELECT [Dst] AS [Ws] FROM LanguageProject_CurrentAnalysisWritingSystems
			UNION
			SELECT [Dst] AS [Ws] FROM LanguageProject_CurrentVernacularWritingSystems) e
		JOIN LgWritingSystem_Collations wsc ON wsc.[Src] = e.[Ws]
		LEFT OUTER JOIN FlidCollation$ fc ON 
			fc.[Ws] = e.[Ws] AND
			fc.[CollationID] = wsc.[Dst] AND 
			fc.[Flid] = @nFlid
		WHERE (
			fc.[Ws] IS NULL OR
			fc.[CollationID] IS NULL OR
			fc.[Flid] IS NULL)
	
	--( The delete into FlidCollation$ should trigger an delete trigger
	--( sort key creation in MultiTxtSortKey$

	-- TODO (SteveMi): above comment.
		
GO






















IF OBJECT_ID('LogInfo$') IS NOT NULL BEGIN
	PRINT 'removing procedure LogInfo$'
	DROP PROCEDURE [LogInfo$]
END
GO
PRINT 'creating procedure LogInfo$'
GO

CREATE PROCEDURE LogInfo$
	@ncLogFileName NCHAR(128) OUTPUT,
	@nLogFileSize INT OUTPUT,
	@nLogFileSpaceUsed INT OUTPUT,
	@nLogFileMaxSize INT OUTPUT,
	@nSpaceAvailForLogFile INT OUTPUT
AS
BEGIN
	DECLARE
		@rLogUsedPercent REAL
	
	--( We'll get the log file size from sysfiles after doing the temp tables, 
	--( because the size can change. status of 0x40 indicates the log file
	
	SELECT @ncLogFileName = [filename] FROM sysfiles WHERE ([status] & 0x40) <> 0 
	
	--( This block can change the numbers on the log file, so it is executed before
	--( other code. We'll add more to mbfree momentarily.
	
	CREATE TABLE #fixeddrives (drive CHAR(1) PRIMARY KEY, mbfree INTEGER NOT NULL)
	--( xp_fixeddrives is not documented by MS, but it is quite a bit on the web. See, for example,
	--( http:
	INSERT INTO #fixeddrives EXEC master..xp_fixeddrives
	SELECT @nSpaceAvailForLogFile = mbfree FROM #fixeddrives WHERE drive = LEFT(@ncLogFileName, 1)
	DROP TABLE #fixeddrives
	--( xp_fixeddrives expresses space in Mb. We want it in Kb
	SET @nSpaceAvailForLogFile = @nSpaceAvailForLogFile * 1024
	
	--( We have a create temp table after this, but there's no helping it.
	
	SELECT
		@nLogFileSize = [size],
		@nLogFileMaxSize = [maxsize]
	FROM sysfiles
	WHERE ([status] & 0x40) <> 0 -- status of 0x40 indicates the log file
	
	--( SQL Server returns the size of the file in 8-KB pages. We want it in KB. The conversion 
	--( factor is 8.
	
	SET @nLogFileSize = @nLogFileSize * 8
	
	--( SQL Server returns the max size of the file in 8-KB pages. We want it in KB. The conversion 
	--( factor 8. The value of maxsize could also be 0 (no growth) or -1 (grow until disk full).
	
	IF @nLogFileMaxSize > 0
		SET @nLogFileMaxSize = @nLogFileMaxSize * 8
	
	--( This block can change the numbers on the log file, so it is executed after the
	--( previous code. We would use a table variable here, but SQL Server will give an
	--( error "EXECUTE cannot be used as a source when inserting into a table variable."
	
	--( DBCC SQLPERF (LOGSPACE) returns space used as a percentage.
	
	CREATE TABLE #LogInfo (DbName NVARCHAR(128), LogSize REAL, LogUsed REAL, Status TINYINT)
	INSERT INTO #LogInfo EXEC ('DBCC SQLPERF (LOGSPACE)')
	SELECT @rLogUsedPercent = LogUsed FROM #LogInfo WHERE [DbName] = DB_NAME()
	DROP TABLE #LogInfo
	
	SET @nLogFileSpaceUsed = ROUND(@nLogFileSize * (@rLogUsedPercent / 100), 0)
	
	--( Now calc how much space is available for the log file. 
	
	IF @nLogFileMaxSize = -1
		--(	@nSpaceAvailForLogFile already has free disk space.
		SET @nSpaceAvailForLogFile = @nSpaceAvailForLogFile + (@nLogFileSize - @nLogFileSpaceUsed)
	ELSE IF @nLogFileMaxSize = 0
		SET @nSpaceAvailForLogFile = @nLogFileSize - @nLogFileSpaceUsed
	ELSE
		SET @nSpaceAvailForLogFile = @nLogFileMaxSize  - @nLogFileSpaceUsed
	
END
GO










IF OBJECT_ID('fnIsMatch$') IS NOT NULL BEGIN
	PRINT 'removing function fnIsMatch$'
	DROP FUNCTION [fnIsMatch$]
END
GO
PRINT 'creating function fnIsMatch$'
GO

CREATE FUNCTION [fnIsMatch$] (
	@nvcPattern NVARCHAR(4000),
	@nvcString NVARCHAR(4000))
	--TODO (SteveMiller): more parameters are needed.
RETURNS INT
AS
BEGIN

	DECLARE
		@nError INT,
		@fMatch BIT
	
	EXEC @nError = master..xp_IsMatch @nvcPattern, @nvcString, @fMatch OUTPUT
	
	IF @nError != 0
		SET @fMatch = -1

	RETURN @fMatch
	
END
GO















IF OBJECT_ID('fnGetLastCommaDelimID$') IS NOT NULL BEGIN
	PRINT 'removing function fnGetLastCommaDelimID$'
	DROP FUNCTION [fnGetLastCommaDelimID$]
END
GO
PRINT 'creating function fnGetLastCommaDelimID$'
GO

CREATE FUNCTION [fnGetLastCommaDelimID$] (
	@nvcSourceString NVARCHAR(4000))
RETURNS INT
AS
BEGIN
	DECLARE 
		@nScratch SMALLINT,
		@nCommaPosition SMALLINT
	
	IF @nvcSourceString IS NULL
		SET @nCommaPosition = NULL
	ELSE BEGIN
		
		--( In case there are no commas
		SET @nScratch = CHARINDEX(',', @nvcSourceString)
		SET @nCommaPosition = @nScratch
		
		--( Find the last comma
		WHILE @nScratch > 0 BEGIN		
			SET @nCommaPosition = @nScratch
			SET @nScratch = CHARINDEX(',', @nvcSourceString, @nCommaPosition + 1)
		END
	END
	
	--( Return the ID after the last comma.
	RETURN CONVERT(INT, SUBSTRING(
		@nvcSourceString,
		@nCommaPosition + 1,
		LEN(@nvcSourceString) - @nCommaPosition))
END

GO
















IF OBJECT_ID('fnSplitCommaDelimIdStr') IS NOT NULL BEGIN
	PRINT 'removing function fnSplitCommaDelimIdStr'
	DROP FUNCTION [fnSplitCommaDelimIdStr]
END
GO
PRINT 'creating function fnSplitCommaDelimIdStr'
GO

CREATE FUNCTION fnSplitCommaDelimIdStr (@ntIds NTEXT)
	RETURNS @tblIds TABLE([Id] INT)
AS
BEGIN
	DECLARE
		@nEnd INT,
		@nStart INT
	
	SET @nStart = 1
	SET @nEnd = CHARINDEX(',', @ntIds, @nStart)
	
	WHILE @nEnd > 1 BEGIN
		INSERT INTO @tblIds VALUES (SUBSTRING(@ntIds, @nStart, @nEnd - @nStart))
		
 		SET @nStart = @nEnd + 1
		SET @nEnd = CHARINDEX(',', @ntIds, @nStart)	
	END
	
	--( last one. the ID won't be 1,000,000
	INSERT INTO @tblIds VALUES (SUBSTRING(@ntIds, @nStart, @nStart + 10 - @nStart))
	
	RETURN
END
GO















IF OBJECT_ID('ManageConstraints$') IS NOT NULL BEGIN
	PRINT 'removing procedure ManageConstraints$'
	DROP PROCEDURE [ManageConstraints$]
END
GO
PRINT 'creating procedure ManageConstraints$'
GO

CREATE PROCEDURE [ManageConstraints$]
		@nvcTableName NVARCHAR(50),
		@cConstraintType CHAR(2),
		@cAction CHAR(10)
AS
	DECLARE
		@sysConstraintName SYSNAME,
		@nvcSQL NVARCHAR(200)
	
	--( Run for all tables
	IF @nvcTableName IS NULL BEGIN
		DECLARE curConstraints CURSOR FOR
			SELECT consobjs.[Name] AS FKName, tableobjs.[Name] AS TableName
			FROM sysconstraints sc
			JOIN sysobjects consobjs ON consobjs.[id] = sc.[constid] --( to get constraint names
			JOIN sysobjects tableobjs ON tableobjs.[id] = sc.[id] --( to get table names
			WHERE consobjs.[xtype] = @cConstraintType
	
		OPEN curConstraints
		FETCH NEXT FROM curConstraints INTO @sysConstraintName, @nvcTableName
		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @nvcSQL = 'ALTER TABLE ' + @nvcTableName + ' ' + @cAction + 
				' CONSTRAINT ' + @sysConstraintName
			EXEC (@nvcSQL)
			
			FETCH NEXT FROM curConstraints INTO @sysConstraintName, @nvcTableName
		END
		CLOSE curConstraints
		DEALLOCATE curConstraints
	END
	
	ELSE BEGIN --( @nvcTableName is not null, run for individual table
		DECLARE curConstraints CURSOR FOR
			SELECT consobjs.[Name]
			FROM sysconstraints sc
			JOIN sysobjects consobjs ON consobjs.[id] = sc.[constid] --( to get constraint names
			JOIN sysobjects tableobjs ON tableobjs.[id] = sc.[id] --( to get table names
			WHERE tableobjs.[Name] = @nvcTableName AND consobjs.[xtype] = @cConstraintType
	
		OPEN curConstraints
		FETCH NEXT FROM curConstraints INTO @sysConstraintName
		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @nvcSQL = 'ALTER TABLE ' + @nvcTableName + ' ' + @cAction + 
				' CONSTRAINT ' + @sysConstraintName
			EXEC (@nvcSQL)
			
			FETCH NEXT FROM curConstraints INTO @sysConstraintName
		END
		CLOSE curConstraints
		DEALLOCATE curConstraints
	END













































if object_id('StartTrace$') is not null begin
	print 'removing proc StartTrace$'
	drop procedure [StartTrace$]
end
go
print 'creating procedure StartTrace$'
go

CREATE PROCEDURE [StartTrace$] 
	--( Some variables/parameters not Hungarian because of code copied
	--( from Profiler
	@TraceId INT OUTPUT,
	@nReturnCode INT OUTPUT,
	@nTraceType INT = 0,
	@nTraceOptions INT = 2, --( 2 = TRACE_FILE_ROLLOVER. See BOL
	@nvcTracePath NVARCHAR(245) = N'C:\',
	@bnMaxMbFileSize BIGINT = 1,
	@dtStopTime DATETIME = NULL
AS

	DECLARE
		@nvcTraceFile NVARCHAR(245),
		@on BIT,
		@nvcErrMsg NVARCHAR(50),
		@nvcCommand NVARCHAR(512)
	
	 --( sp_trace_create attaches .trc to the end of a file name.
	IF @nTraceType = 0
		SET @nvcTraceFile = @nvcTracePath + N'FwPlain'
	ELSE IF @nTraceType = 1
		SET @nvcTraceFile = @nvcTracePath + N'FwExpanded'
	ELSE BEGIN
		SET @nvcErrMsg = N'StartTrace: bad Trace type'
		GOTO Fail
	END

	
	--== Delete Old Trace if exists ==--
	
	--( This won't work if the trace is still running. You need to
	--( stop the trace first. Chances are the Trace ID is 1.
	
	SET @nvcCommand = 'if exist ' + @nvcTraceFile + '.trc del ' + @nvcTraceFile + '.trc'
	EXEC @nReturnCode = master.dbo.xp_cmdshell @nvcCommand, NO_OUTPUT
	IF NOT @nReturnCode = 0 BEGIN --( If not 0, then it will be 1
		SET @nvcErrMsg = N'StartTrace: Delete ' + @nvcTraceFile + N'.trc failed '
		GOTO Fail
	END
	
	--== Create the New Trace ==--
	
	EXEC @nReturnCode = sp_trace_create
		@TraceID OUTPUT,
		@nTraceOptions,
		@nvcTraceFile,
		@bnMaxMbFileSize,
		@dtStopTime
	
	IF NOT @nReturnCode = 0 BEGIN
		SET @nvcErrMsg = N'StartTrace: See Books Online for error return code ' + 
			CONVERT(NVARCHAR(2), @nReturnCode)
		GOTO Fail
	END
	
	SET @on = 1
	
	--( FwPlain, a genric trace file
	IF @nTraceType = 0 BEGIN
		exec sp_trace_setevent @TraceID, 10, 1, @on
		exec sp_trace_setevent @TraceID, 10, 6, @on
		exec sp_trace_setevent @TraceID, 10, 9, @on
		exec sp_trace_setevent @TraceID, 10, 10, @on
		exec sp_trace_setevent @TraceID, 10, 11, @on
		exec sp_trace_setevent @TraceID, 10, 12, @on
		exec sp_trace_setevent @TraceID, 10, 13, @on
		exec sp_trace_setevent @TraceID, 10, 14, @on
		exec sp_trace_setevent @TraceID, 10, 16, @on
		exec sp_trace_setevent @TraceID, 10, 17, @on
		exec sp_trace_setevent @TraceID, 10, 18, @on
		exec sp_trace_setevent @TraceID, 12, 1, @on
		exec sp_trace_setevent @TraceID, 12, 6, @on
		exec sp_trace_setevent @TraceID, 12, 9, @on
		exec sp_trace_setevent @TraceID, 12, 10, @on
		exec sp_trace_setevent @TraceID, 12, 11, @on
		exec sp_trace_setevent @TraceID, 12, 12, @on
		exec sp_trace_setevent @TraceID, 12, 13, @on
		exec sp_trace_setevent @TraceID, 12, 14, @on
		exec sp_trace_setevent @TraceID, 12, 16, @on
		exec sp_trace_setevent @TraceID, 12, 17, @on
		exec sp_trace_setevent @TraceID, 12, 18, @on
		exec sp_trace_setevent @TraceID, 14, 1, @on
		exec sp_trace_setevent @TraceID, 14, 6, @on
		exec sp_trace_setevent @TraceID, 14, 9, @on
		exec sp_trace_setevent @TraceID, 14, 10, @on
		exec sp_trace_setevent @TraceID, 14, 11, @on
		exec sp_trace_setevent @TraceID, 14, 12, @on
		exec sp_trace_setevent @TraceID, 14, 13, @on
		exec sp_trace_setevent @TraceID, 14, 14, @on
		exec sp_trace_setevent @TraceID, 14, 16, @on
		exec sp_trace_setevent @TraceID, 14, 17, @on
		exec sp_trace_setevent @TraceID, 14, 18, @on
		exec sp_trace_setevent @TraceID, 15, 1, @on
		exec sp_trace_setevent @TraceID, 15, 6, @on
		exec sp_trace_setevent @TraceID, 15, 9, @on
		exec sp_trace_setevent @TraceID, 15, 10, @on
		exec sp_trace_setevent @TraceID, 15, 11, @on
		exec sp_trace_setevent @TraceID, 15, 12, @on
		exec sp_trace_setevent @TraceID, 15, 13, @on
		exec sp_trace_setevent @TraceID, 15, 14, @on
		exec sp_trace_setevent @TraceID, 15, 16, @on
		exec sp_trace_setevent @TraceID, 15, 17, @on
		exec sp_trace_setevent @TraceID, 15, 18, @on
		exec sp_trace_setevent @TraceID, 17, 1, @on
		exec sp_trace_setevent @TraceID, 17, 6, @on
		exec sp_trace_setevent @TraceID, 17, 9, @on
		exec sp_trace_setevent @TraceID, 17, 10, @on
		exec sp_trace_setevent @TraceID, 17, 11, @on
		exec sp_trace_setevent @TraceID, 17, 12, @on
		exec sp_trace_setevent @TraceID, 17, 13, @on
		exec sp_trace_setevent @TraceID, 17, 14, @on
		exec sp_trace_setevent @TraceID, 17, 16, @on
		exec sp_trace_setevent @TraceID, 17, 17, @on
		exec sp_trace_setevent @TraceID, 17, 18, @on
	END
	
	ELSE IF @nTraceType = 1 BEGIN
		exec sp_trace_setevent @TraceID, 10, 1, @on
		exec sp_trace_setevent @TraceID, 10, 9, @on
		exec sp_trace_setevent @TraceID, 10, 11, @on
		exec sp_trace_setevent @TraceID, 10, 12, @on
		exec sp_trace_setevent @TraceID, 10, 13, @on
		exec sp_trace_setevent @TraceID, 10, 14, @on
		exec sp_trace_setevent @TraceID, 10, 16, @on
		exec sp_trace_setevent @TraceID, 10, 17, @on
		exec sp_trace_setevent @TraceID, 10, 18, @on
		exec sp_trace_setevent @TraceID, 10, 21, @on
		exec sp_trace_setevent @TraceID, 10, 31, @on
		exec sp_trace_setevent @TraceID, 10, 34, @on
		exec sp_trace_setevent @TraceID, 14, 1, @on
		exec sp_trace_setevent @TraceID, 14, 9, @on
		exec sp_trace_setevent @TraceID, 14, 11, @on
		exec sp_trace_setevent @TraceID, 14, 12, @on
		exec sp_trace_setevent @TraceID, 14, 13, @on
		exec sp_trace_setevent @TraceID, 14, 14, @on
		exec sp_trace_setevent @TraceID, 14, 16, @on
		exec sp_trace_setevent @TraceID, 14, 17, @on
		exec sp_trace_setevent @TraceID, 14, 18, @on
		exec sp_trace_setevent @TraceID, 14, 21, @on
		exec sp_trace_setevent @TraceID, 14, 31, @on
		exec sp_trace_setevent @TraceID, 14, 34, @on
		exec sp_trace_setevent @TraceID, 15, 1, @on
		exec sp_trace_setevent @TraceID, 15, 9, @on
		exec sp_trace_setevent @TraceID, 15, 11, @on
		exec sp_trace_setevent @TraceID, 15, 12, @on
		exec sp_trace_setevent @TraceID, 15, 13, @on
		exec sp_trace_setevent @TraceID, 15, 14, @on
		exec sp_trace_setevent @TraceID, 15, 16, @on
		exec sp_trace_setevent @TraceID, 15, 17, @on
		exec sp_trace_setevent @TraceID, 15, 18, @on
		exec sp_trace_setevent @TraceID, 15, 21, @on
		exec sp_trace_setevent @TraceID, 15, 31, @on
		exec sp_trace_setevent @TraceID, 15, 34, @on
		exec sp_trace_setevent @TraceID, 16, 1, @on
		exec sp_trace_setevent @TraceID, 16, 9, @on
		exec sp_trace_setevent @TraceID, 16, 11, @on
		exec sp_trace_setevent @TraceID, 16, 12, @on
		exec sp_trace_setevent @TraceID, 16, 13, @on
		exec sp_trace_setevent @TraceID, 16, 14, @on
		exec sp_trace_setevent @TraceID, 16, 16, @on
		exec sp_trace_setevent @TraceID, 16, 17, @on
		exec sp_trace_setevent @TraceID, 16, 18, @on
		exec sp_trace_setevent @TraceID, 16, 21, @on
		exec sp_trace_setevent @TraceID, 16, 31, @on
		exec sp_trace_setevent @TraceID, 16, 34, @on
		exec sp_trace_setevent @TraceID, 17, 1, @on
		exec sp_trace_setevent @TraceID, 17, 9, @on
		exec sp_trace_setevent @TraceID, 17, 11, @on
		exec sp_trace_setevent @TraceID, 17, 12, @on
		exec sp_trace_setevent @TraceID, 17, 13, @on
		exec sp_trace_setevent @TraceID, 17, 14, @on
		exec sp_trace_setevent @TraceID, 17, 16, @on
		exec sp_trace_setevent @TraceID, 17, 17, @on
		exec sp_trace_setevent @TraceID, 17, 18, @on
		exec sp_trace_setevent @TraceID, 17, 21, @on
		exec sp_trace_setevent @TraceID, 17, 31, @on
		exec sp_trace_setevent @TraceID, 17, 34, @on
		exec sp_trace_setevent @TraceID, 21, 1, @on
		exec sp_trace_setevent @TraceID, 21, 9, @on
		exec sp_trace_setevent @TraceID, 21, 11, @on
		exec sp_trace_setevent @TraceID, 21, 12, @on
		exec sp_trace_setevent @TraceID, 21, 13, @on
		exec sp_trace_setevent @TraceID, 21, 14, @on
		exec sp_trace_setevent @TraceID, 21, 16, @on
		exec sp_trace_setevent @TraceID, 21, 17, @on
		exec sp_trace_setevent @TraceID, 21, 18, @on
		exec sp_trace_setevent @TraceID, 21, 21, @on
		exec sp_trace_setevent @TraceID, 21, 31, @on
		exec sp_trace_setevent @TraceID, 21, 34, @on
		exec sp_trace_setevent @TraceID, 22, 1, @on
		exec sp_trace_setevent @TraceID, 22, 9, @on
		exec sp_trace_setevent @TraceID, 22, 11, @on
		exec sp_trace_setevent @TraceID, 22, 12, @on
		exec sp_trace_setevent @TraceID, 22, 13, @on
		exec sp_trace_setevent @TraceID, 22, 14, @on
		exec sp_trace_setevent @TraceID, 22, 16, @on
		exec sp_trace_setevent @TraceID, 22, 17, @on
		exec sp_trace_setevent @TraceID, 22, 18, @on
		exec sp_trace_setevent @TraceID, 22, 21, @on
		exec sp_trace_setevent @TraceID, 22, 31, @on
		exec sp_trace_setevent @TraceID, 22, 34, @on
		exec sp_trace_setevent @TraceID, 33, 1, @on
		exec sp_trace_setevent @TraceID, 33, 9, @on
		exec sp_trace_setevent @TraceID, 33, 11, @on
		exec sp_trace_setevent @TraceID, 33, 12, @on
		exec sp_trace_setevent @TraceID, 33, 13, @on
		exec sp_trace_setevent @TraceID, 33, 14, @on
		exec sp_trace_setevent @TraceID, 33, 16, @on
		exec sp_trace_setevent @TraceID, 33, 17, @on
		exec sp_trace_setevent @TraceID, 33, 18, @on
		exec sp_trace_setevent @TraceID, 33, 21, @on
		exec sp_trace_setevent @TraceID, 33, 31, @on
		exec sp_trace_setevent @TraceID, 33, 34, @on
		exec sp_trace_setevent @TraceID, 34, 1, @on
		exec sp_trace_setevent @TraceID, 34, 9, @on
		exec sp_trace_setevent @TraceID, 34, 11, @on
		exec sp_trace_setevent @TraceID, 34, 12, @on
		exec sp_trace_setevent @TraceID, 34, 13, @on
		exec sp_trace_setevent @TraceID, 34, 14, @on
		exec sp_trace_setevent @TraceID, 34, 16, @on
		exec sp_trace_setevent @TraceID, 34, 17, @on
		exec sp_trace_setevent @TraceID, 34, 18, @on
		exec sp_trace_setevent @TraceID, 34, 21, @on
		exec sp_trace_setevent @TraceID, 34, 31, @on
		exec sp_trace_setevent @TraceID, 34, 34, @on
		exec sp_trace_setevent @TraceID, 35, 1, @on
		exec sp_trace_setevent @TraceID, 35, 9, @on
		exec sp_trace_setevent @TraceID, 35, 11, @on
		exec sp_trace_setevent @TraceID, 35, 12, @on
		exec sp_trace_setevent @TraceID, 35, 13, @on
		exec sp_trace_setevent @TraceID, 35, 14, @on
		exec sp_trace_setevent @TraceID, 35, 16, @on
		exec sp_trace_setevent @TraceID, 35, 17, @on
		exec sp_trace_setevent @TraceID, 35, 18, @on
		exec sp_trace_setevent @TraceID, 35, 21, @on
		exec sp_trace_setevent @TraceID, 35, 31, @on
		exec sp_trace_setevent @TraceID, 35, 34, @on
		exec sp_trace_setevent @TraceID, 36, 1, @on
		exec sp_trace_setevent @TraceID, 36, 9, @on
		exec sp_trace_setevent @TraceID, 36, 11, @on
		exec sp_trace_setevent @TraceID, 36, 12, @on
		exec sp_trace_setevent @TraceID, 36, 13, @on
		exec sp_trace_setevent @TraceID, 36, 14, @on
		exec sp_trace_setevent @TraceID, 36, 16, @on
		exec sp_trace_setevent @TraceID, 36, 17, @on
		exec sp_trace_setevent @TraceID, 36, 18, @on
		exec sp_trace_setevent @TraceID, 36, 21, @on
		exec sp_trace_setevent @TraceID, 36, 31, @on
		exec sp_trace_setevent @TraceID, 36, 34, @on
		exec sp_trace_setevent @TraceID, 37, 1, @on
		exec sp_trace_setevent @TraceID, 37, 9, @on
		exec sp_trace_setevent @TraceID, 37, 11, @on
		exec sp_trace_setevent @TraceID, 37, 12, @on
		exec sp_trace_setevent @TraceID, 37, 13, @on
		exec sp_trace_setevent @TraceID, 37, 14, @on
		exec sp_trace_setevent @TraceID, 37, 16, @on
		exec sp_trace_setevent @TraceID, 37, 17, @on
		exec sp_trace_setevent @TraceID, 37, 18, @on
		exec sp_trace_setevent @TraceID, 37, 21, @on
		exec sp_trace_setevent @TraceID, 37, 31, @on
		exec sp_trace_setevent @TraceID, 37, 34, @on
		exec sp_trace_setevent @TraceID, 41, 1, @on
		exec sp_trace_setevent @TraceID, 41, 9, @on
		exec sp_trace_setevent @TraceID, 41, 11, @on
		exec sp_trace_setevent @TraceID, 41, 12, @on
		exec sp_trace_setevent @TraceID, 41, 13, @on
		exec sp_trace_setevent @TraceID, 41, 14, @on
		exec sp_trace_setevent @TraceID, 41, 16, @on
		exec sp_trace_setevent @TraceID, 41, 17, @on
		exec sp_trace_setevent @TraceID, 41, 18, @on
		exec sp_trace_setevent @TraceID, 41, 21, @on
		exec sp_trace_setevent @TraceID, 41, 31, @on
		exec sp_trace_setevent @TraceID, 41, 34, @on
		exec sp_trace_setevent @TraceID, 50, 1, @on
		exec sp_trace_setevent @TraceID, 50, 9, @on
		exec sp_trace_setevent @TraceID, 50, 11, @on
		exec sp_trace_setevent @TraceID, 50, 12, @on
		exec sp_trace_setevent @TraceID, 50, 13, @on
		exec sp_trace_setevent @TraceID, 50, 14, @on
		exec sp_trace_setevent @TraceID, 50, 16, @on
		exec sp_trace_setevent @TraceID, 50, 17, @on
		exec sp_trace_setevent @TraceID, 50, 18, @on
		exec sp_trace_setevent @TraceID, 50, 21, @on
		exec sp_trace_setevent @TraceID, 50, 31, @on
		exec sp_trace_setevent @TraceID, 50, 34, @on
		exec sp_trace_setevent @TraceID, 53, 1, @on
		exec sp_trace_setevent @TraceID, 53, 9, @on
		exec sp_trace_setevent @TraceID, 53, 11, @on
		exec sp_trace_setevent @TraceID, 53, 12, @on
		exec sp_trace_setevent @TraceID, 53, 13, @on
		exec sp_trace_setevent @TraceID, 53, 14, @on
		exec sp_trace_setevent @TraceID, 53, 16, @on
		exec sp_trace_setevent @TraceID, 53, 17, @on
		exec sp_trace_setevent @TraceID, 53, 18, @on
		exec sp_trace_setevent @TraceID, 53, 21, @on
		exec sp_trace_setevent @TraceID, 53, 31, @on
		exec sp_trace_setevent @TraceID, 53, 34, @on
		exec sp_trace_setevent @TraceID, 55, 1, @on
		exec sp_trace_setevent @TraceID, 55, 9, @on
		exec sp_trace_setevent @TraceID, 55, 11, @on
		exec sp_trace_setevent @TraceID, 55, 12, @on
		exec sp_trace_setevent @TraceID, 55, 13, @on
		exec sp_trace_setevent @TraceID, 55, 14, @on
		exec sp_trace_setevent @TraceID, 55, 16, @on
		exec sp_trace_setevent @TraceID, 55, 17, @on
		exec sp_trace_setevent @TraceID, 55, 18, @on
		exec sp_trace_setevent @TraceID, 55, 21, @on
		exec sp_trace_setevent @TraceID, 55, 31, @on
		exec sp_trace_setevent @TraceID, 55, 34, @on
		exec sp_trace_setevent @TraceID, 61, 1, @on
		exec sp_trace_setevent @TraceID, 61, 9, @on
		exec sp_trace_setevent @TraceID, 61, 11, @on
		exec sp_trace_setevent @TraceID, 61, 12, @on
		exec sp_trace_setevent @TraceID, 61, 13, @on
		exec sp_trace_setevent @TraceID, 61, 14, @on
		exec sp_trace_setevent @TraceID, 61, 16, @on
		exec sp_trace_setevent @TraceID, 61, 17, @on
		exec sp_trace_setevent @TraceID, 61, 18, @on
		exec sp_trace_setevent @TraceID, 61, 21, @on
		exec sp_trace_setevent @TraceID, 61, 31, @on
		exec sp_trace_setevent @TraceID, 61, 34, @on
		exec sp_trace_setevent @TraceID, 67, 1, @on
		exec sp_trace_setevent @TraceID, 67, 9, @on
		exec sp_trace_setevent @TraceID, 67, 11, @on
		exec sp_trace_setevent @TraceID, 67, 12, @on
		exec sp_trace_setevent @TraceID, 67, 13, @on
		exec sp_trace_setevent @TraceID, 67, 14, @on
		exec sp_trace_setevent @TraceID, 67, 16, @on
		exec sp_trace_setevent @TraceID, 67, 17, @on
		exec sp_trace_setevent @TraceID, 67, 18, @on
		exec sp_trace_setevent @TraceID, 67, 21, @on
		exec sp_trace_setevent @TraceID, 67, 31, @on
		exec sp_trace_setevent @TraceID, 67, 34, @on
		exec sp_trace_setevent @TraceID, 68, 1, @on
		exec sp_trace_setevent @TraceID, 68, 9, @on
		exec sp_trace_setevent @TraceID, 68, 11, @on
		exec sp_trace_setevent @TraceID, 68, 12, @on
		exec sp_trace_setevent @TraceID, 68, 13, @on
		exec sp_trace_setevent @TraceID, 68, 14, @on
		exec sp_trace_setevent @TraceID, 68, 16, @on
		exec sp_trace_setevent @TraceID, 68, 17, @on
		exec sp_trace_setevent @TraceID, 68, 18, @on
		exec sp_trace_setevent @TraceID, 68, 21, @on
		exec sp_trace_setevent @TraceID, 68, 31, @on
		exec sp_trace_setevent @TraceID, 68, 34, @on
		exec sp_trace_setevent @TraceID, 69, 1, @on
		exec sp_trace_setevent @TraceID, 69, 9, @on
		exec sp_trace_setevent @TraceID, 69, 11, @on
		exec sp_trace_setevent @TraceID, 69, 12, @on
		exec sp_trace_setevent @TraceID, 69, 13, @on
		exec sp_trace_setevent @TraceID, 69, 14, @on
		exec sp_trace_setevent @TraceID, 69, 16, @on
		exec sp_trace_setevent @TraceID, 69, 17, @on
		exec sp_trace_setevent @TraceID, 69, 18, @on
		exec sp_trace_setevent @TraceID, 69, 21, @on
		exec sp_trace_setevent @TraceID, 69, 31, @on
		exec sp_trace_setevent @TraceID, 69, 34, @on
		exec sp_trace_setevent @TraceID, 70, 1, @on
		exec sp_trace_setevent @TraceID, 70, 9, @on
		exec sp_trace_setevent @TraceID, 70, 11, @on
		exec sp_trace_setevent @TraceID, 70, 12, @on
		exec sp_trace_setevent @TraceID, 70, 13, @on
		exec sp_trace_setevent @TraceID, 70, 14, @on
		exec sp_trace_setevent @TraceID, 70, 16, @on
		exec sp_trace_setevent @TraceID, 70, 17, @on
		exec sp_trace_setevent @TraceID, 70, 18, @on
		exec sp_trace_setevent @TraceID, 70, 21, @on
		exec sp_trace_setevent @TraceID, 70, 31, @on
		exec sp_trace_setevent @TraceID, 70, 34, @on
		exec sp_trace_setevent @TraceID, 71, 1, @on
		exec sp_trace_setevent @TraceID, 71, 9, @on
		exec sp_trace_setevent @TraceID, 71, 11, @on
		exec sp_trace_setevent @TraceID, 71, 12, @on
		exec sp_trace_setevent @TraceID, 71, 13, @on
		exec sp_trace_setevent @TraceID, 71, 14, @on
		exec sp_trace_setevent @TraceID, 71, 16, @on
		exec sp_trace_setevent @TraceID, 71, 17, @on
		exec sp_trace_setevent @TraceID, 71, 18, @on
		exec sp_trace_setevent @TraceID, 71, 21, @on
		exec sp_trace_setevent @TraceID, 71, 31, @on
		exec sp_trace_setevent @TraceID, 71, 34, @on
		exec sp_trace_setevent @TraceID, 72, 1, @on
		exec sp_trace_setevent @TraceID, 72, 9, @on
		exec sp_trace_setevent @TraceID, 72, 11, @on
		exec sp_trace_setevent @TraceID, 72, 12, @on
		exec sp_trace_setevent @TraceID, 72, 13, @on
		exec sp_trace_setevent @TraceID, 72, 14, @on
		exec sp_trace_setevent @TraceID, 72, 16, @on
		exec sp_trace_setevent @TraceID, 72, 17, @on
		exec sp_trace_setevent @TraceID, 72, 18, @on
		exec sp_trace_setevent @TraceID, 72, 21, @on
		exec sp_trace_setevent @TraceID, 72, 31, @on
		exec sp_trace_setevent @TraceID, 72, 34, @on
		exec sp_trace_setevent @TraceID, 74, 1, @on
		exec sp_trace_setevent @TraceID, 74, 9, @on
		exec sp_trace_setevent @TraceID, 74, 11, @on
		exec sp_trace_setevent @TraceID, 74, 12, @on
		exec sp_trace_setevent @TraceID, 74, 13, @on
		exec sp_trace_setevent @TraceID, 74, 14, @on
		exec sp_trace_setevent @TraceID, 74, 16, @on
		exec sp_trace_setevent @TraceID, 74, 17, @on
		exec sp_trace_setevent @TraceID, 74, 18, @on
		exec sp_trace_setevent @TraceID, 74, 21, @on
		exec sp_trace_setevent @TraceID, 74, 31, @on
		exec sp_trace_setevent @TraceID, 74, 34, @on
		exec sp_trace_setevent @TraceID, 75, 1, @on
		exec sp_trace_setevent @TraceID, 75, 9, @on
		exec sp_trace_setevent @TraceID, 75, 11, @on
		exec sp_trace_setevent @TraceID, 75, 12, @on
		exec sp_trace_setevent @TraceID, 75, 13, @on
		exec sp_trace_setevent @TraceID, 75, 14, @on
		exec sp_trace_setevent @TraceID, 75, 16, @on
		exec sp_trace_setevent @TraceID, 75, 17, @on
		exec sp_trace_setevent @TraceID, 75, 18, @on
		exec sp_trace_setevent @TraceID, 75, 21, @on
		exec sp_trace_setevent @TraceID, 75, 31, @on
		exec sp_trace_setevent @TraceID, 75, 34, @on
		exec sp_trace_setevent @TraceID, 76, 1, @on
		exec sp_trace_setevent @TraceID, 76, 9, @on
		exec sp_trace_setevent @TraceID, 76, 11, @on
		exec sp_trace_setevent @TraceID, 76, 12, @on
		exec sp_trace_setevent @TraceID, 76, 13, @on
		exec sp_trace_setevent @TraceID, 76, 14, @on
		exec sp_trace_setevent @TraceID, 76, 16, @on
		exec sp_trace_setevent @TraceID, 76, 17, @on
		exec sp_trace_setevent @TraceID, 76, 18, @on
		exec sp_trace_setevent @TraceID, 76, 21, @on
		exec sp_trace_setevent @TraceID, 76, 31, @on
		exec sp_trace_setevent @TraceID, 76, 34, @on
		exec sp_trace_setevent @TraceID, 77, 1, @on
		exec sp_trace_setevent @TraceID, 77, 9, @on
		exec sp_trace_setevent @TraceID, 77, 11, @on
		exec sp_trace_setevent @TraceID, 77, 12, @on
		exec sp_trace_setevent @TraceID, 77, 13, @on
		exec sp_trace_setevent @TraceID, 77, 14, @on
		exec sp_trace_setevent @TraceID, 77, 16, @on
		exec sp_trace_setevent @TraceID, 77, 17, @on
		exec sp_trace_setevent @TraceID, 77, 18, @on
		exec sp_trace_setevent @TraceID, 77, 21, @on
		exec sp_trace_setevent @TraceID, 77, 31, @on
		exec sp_trace_setevent @TraceID, 77, 34, @on
		exec sp_trace_setevent @TraceID, 78, 1, @on
		exec sp_trace_setevent @TraceID, 78, 9, @on
		exec sp_trace_setevent @TraceID, 78, 11, @on
		exec sp_trace_setevent @TraceID, 78, 12, @on
		exec sp_trace_setevent @TraceID, 78, 13, @on
		exec sp_trace_setevent @TraceID, 78, 14, @on
		exec sp_trace_setevent @TraceID, 78, 16, @on
		exec sp_trace_setevent @TraceID, 78, 17, @on
		exec sp_trace_setevent @TraceID, 78, 18, @on
		exec sp_trace_setevent @TraceID, 78, 21, @on
		exec sp_trace_setevent @TraceID, 78, 31, @on
		exec sp_trace_setevent @TraceID, 78, 34, @on
		exec sp_trace_setevent @TraceID, 79, 1, @on
		exec sp_trace_setevent @TraceID, 79, 9, @on
		exec sp_trace_setevent @TraceID, 79, 11, @on
		exec sp_trace_setevent @TraceID, 79, 12, @on
		exec sp_trace_setevent @TraceID, 79, 13, @on
		exec sp_trace_setevent @TraceID, 79, 14, @on
		exec sp_trace_setevent @TraceID, 79, 16, @on
		exec sp_trace_setevent @TraceID, 79, 17, @on
		exec sp_trace_setevent @TraceID, 79, 18, @on
		exec sp_trace_setevent @TraceID, 79, 21, @on
		exec sp_trace_setevent @TraceID, 79, 31, @on
		exec sp_trace_setevent @TraceID, 79, 34, @on
		exec sp_trace_setevent @TraceID, 80, 1, @on
		exec sp_trace_setevent @TraceID, 80, 9, @on
		exec sp_trace_setevent @TraceID, 80, 11, @on
		exec sp_trace_setevent @TraceID, 80, 12, @on
		exec sp_trace_setevent @TraceID, 80, 13, @on
		exec sp_trace_setevent @TraceID, 80, 14, @on
		exec sp_trace_setevent @TraceID, 80, 16, @on
		exec sp_trace_setevent @TraceID, 80, 17, @on
		exec sp_trace_setevent @TraceID, 80, 18, @on
		exec sp_trace_setevent @TraceID, 80, 21, @on
		exec sp_trace_setevent @TraceID, 80, 31, @on
		exec sp_trace_setevent @TraceID, 80, 34, @on
		exec sp_trace_setevent @TraceID, 100, 1, @on
		exec sp_trace_setevent @TraceID, 100, 9, @on
		exec sp_trace_setevent @TraceID, 100, 11, @on
		exec sp_trace_setevent @TraceID, 100, 12, @on
		exec sp_trace_setevent @TraceID, 100, 13, @on
		exec sp_trace_setevent @TraceID, 100, 14, @on
		exec sp_trace_setevent @TraceID, 100, 16, @on
		exec sp_trace_setevent @TraceID, 100, 17, @on
		exec sp_trace_setevent @TraceID, 100, 18, @on
		exec sp_trace_setevent @TraceID, 100, 21, @on
		exec sp_trace_setevent @TraceID, 100, 31, @on
		exec sp_trace_setevent @TraceID, 100, 34, @on
	END
	
	--( Set a filter
	IF @nTraceType = 0
		exec sp_trace_setfilter @TraceID, 10, 0, 7, N'SQL Profiler'
	
	--== Start the Trace ==--
	
	EXEC @nReturnCode = sp_trace_setstatus @TraceID, 1

	IF NOT @nReturnCode = 0 BEGIN
		SET @nvcErrMsg = N'StartTrace: Couldn''t start the trace with sp_trace_setstatus'
		GOTO Fail
	END

	GOTO Finish

Fail:
	RAISERROR (@nvcErrMsg, 16, 1)
	SELECT ErrorCode = @nReturnCode
	
	--( Stop the trace
	EXEC sp_trace_setstatus @TraceID, 0	
	--( Close the trace
	EXEC sp_trace_setstatus @TraceID, 2

Finish:
	GO


















if object_id('StopTrace$') is not null begin
	print 'removing proc StopTrace$'
	drop procedure [StopTrace$]
end
go
print 'creating procedure StopTrace$'
go

CREATE PROCEDURE [StopTrace$]
	--( Chances are the trace ID is 1.
	@iTraceId INT = 1
AS
	--( Stop the trace
	EXEC sp_trace_setstatus @ITraceID, 0	
	--( Close the trace
	EXEC sp_trace_setstatus @ITraceID, 2

GO











if object_id('StopTraces$') is not null begin
	print 'removing proc StopTraces$'
	drop procedure [StopTraces$]
end
go
print 'creating procedure StopTraces$'
go

CREATE PROCEDURE [StopTraces$]
AS

--(The assumption here is that all traces need to be stopped

DECLARE @traceID INT
DECLARE traces CURSOR LOCAL FAST_FORWARD FOR
	SELECT DISTINCT traceid
	FROM ::fn_trace_getinfo(DEFAULT)

OPEN traces
FETCH NEXT FROM traces INTO @traceid
WHILE @@FETCH_STATUS = 0
BEGIN
	EXEC sp_trace_setstatus @traceID, 0
	EXEC sp_trace_setstatus @traceID, 2 
	FETCH NEXT FROM traces INTO @traceid
END
CLOSE traces
DEALLOCATE traces

GO





-- deny insert, update, delete on CmObject to FwDeveloper
-- deny insert, update, delete on MultiStr$ to FwDeveloper
-- deny insert, update, delete on MultiTxt$ to FwDeveloper
-- deny insert, update, delete on MultiBigStr$ to FwDeveloper
-- deny insert, update, delete on MultiBitTxt$ to FwDeveloper
-- go

if exists (select *
             from sysobjects
            where name = 'GetFwUsers')
	drop proc GetFwUsers
go
print 'creating proc GetFwUsers'
go











create proc GetFwUsers
as
	select REPLACE(name, '_', ' ') "name"
	from master.dbo.syslogins
	where isntgroup != 1
	and isntuser !=1
	and name != 'FWDeveloper'
	and name != 'sa'
GO

if exists (select *
             from sysobjects
            where name = 'IsValidObject$')
	drop proc IsValidObject$
go
print 'creating proc IsValidObject$'
go















create proc IsValidObject$
	@idOfObjectToCheck int,
	@class int,
	@fValid int out
as
	DECLARE @actualClass int

	select @actualClass = class$ from CmObject  where id = @idOfObjectToCheck
	if @class = @actualclass
		set @fValid = 1
	else
		exec ClassIsDerivedFrom$ @actualClass, @class, @fValid out
GO


if exists (select *
             from sysobjects
            where name = 'ClassIsDerivedFrom$')
	drop proc ClassIsDerivedFrom$
go
print 'creating proc ClassIsDerivedFrom$'
go

















create proc ClassIsDerivedFrom$
	@class int,
	@baseClass int,
	@fValid int out
as
	DECLARE @actualBase int
	select @actualBase = Base from class$ where id = @class
	if @actualBase = @baseClass
		set @fValid = 1
	else begin
		if @actualBase > 0
			exec ClassIsderivedFrom$ @actualBase, @baseClass, @fValid out
		else
			set @fValid = 0
	end
GO



insert into Module$ ([Id], [Name], [Ver], [VerBack])
	values(0, 'Cellar', 1, 1)

insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(0, 0, 0, 1, 'CmObject')


insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(23, 0, 0, 0, 'CmAgent')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(32, 0, 0, 0, 'CmAgentEvaluation')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(34, 0, 0, 0, 'CmAnnotation')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(11, 0, 0, 0, 'CmCell')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(67, 0, 0, 0, 'CmDomainQuestion')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(47, 0, 0, 0, 'CmFile')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(9, 0, 0, 0, 'CmFilter')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(2, 0, 0, 0, 'CmFolder')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5, 0, 0, 1, 'CmMajorObject')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(21, 0, 0, 0, 'CmOverlay')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(48, 0, 0, 0, 'CmPicture')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(7, 0, 0, 0, 'CmPossibility')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(1, 0, 0, 1, 'CmProject')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(10, 0, 0, 0, 'CmRow')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(31, 0, 0, 0, 'CmSortSpec')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(29, 0, 0, 0, 'CmTranslation')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(28, 0, 0, 0, 'CrossReference')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(60, 0, 0, 1, 'FsAbstractStructure')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(55, 0, 0, 1, 'FsFeatureDefn')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(56, 0, 0, 1, 'FsFeatureSpecification')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(59, 0, 0, 0, 'FsFeatureStructureType')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(49, 0, 0, 0, 'FsFeatureSystem')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(65, 0, 0, 0, 'FsSymbolicFeatureValue')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(30, 0, 0, 0, 'LgCollation')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(24, 0, 0, 0, 'LgWritingSystem')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(43, 0, 0, 0, 'PubDivision')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(46, 0, 0, 0, 'PubHeader')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(45, 0, 0, 0, 'PubHeaderFooterSet')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(42, 0, 0, 0, 'Publication')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(44, 0, 0, 0, 'PubPageLayout')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(15, 0, 0, 1, 'StPara')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(17, 0, 0, 0, 'StStyle')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(14, 0, 0, 0, 'StText')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(41, 0, 0, 0, 'UserAppFeatureActivated')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(40, 0, 0, 0, 'UserConfigAccount')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(18, 0, 0, 0, 'UserView')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(20, 0, 0, 0, 'UserViewField')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(19, 0, 0, 0, 'UserViewRec')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(35, 0, 7, 0, 'CmAnnotationDefn')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(26, 0, 7, 0, 'CmAnthroItem')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(37, 0, 34, 0, 'CmBaseAnnotation')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(27, 0, 7, 0, 'CmCustomItem')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(36, 0, 34, 0, 'CmIndirectAnnotation')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(12, 0, 7, 0, 'CmLocation')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(38, 0, 34, 0, 'CmMediaAnnotation')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(13, 0, 7, 0, 'CmPerson')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(8, 0, 5, 0, 'CmPossibilityList')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(66, 0, 7, 0, 'CmSemanticDomain')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(50, 0, 55, 0, 'FsClosedFeature')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(51, 0, 56, 0, 'FsClosedValue')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(4, 0, 55, 0, 'FsComplexFeature')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(53, 0, 56, 0, 'FsComplexValue')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(54, 0, 56, 0, 'FsDisjunctiveValue')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(57, 0, 60, 0, 'FsFeatureStructure')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(58, 0, 60, 0, 'FsFeatureStructureDisjunction')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(61, 0, 56, 0, 'FsNegatedValue')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(62, 0, 55, 0, 'FsOpenFeature')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(63, 0, 56, 0, 'FsOpenValue')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(64, 0, 56, 0, 'FsSharedValue')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(39, 0, 14, 0, 'StFootnote')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(16, 0, 15, 0, 'StTxtPara')



insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(23001, 16, 23,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(23002, 15, 23,
		null, 'StateInformation',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(23003, 1, 23,
		null, 'Human',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(23004, 23, 23,
		14, 'Notes',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(23005, 15, 23,
		null, 'Version',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(23006, 25, 23,
		32, 'Evaluations',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(32001, 24, 32,
		0, 'Target',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(32002, 5, 32,
		null, 'DateCreated',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(32003, 1, 32,
		null, 'Accepted',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(32004, 15, 32,
		null, 'Details',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(34001, 19, 34,
		null, 'CompDetails',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(34002, 18, 34,
		null, 'Comment',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(34003, 24, 34,
		35, 'AnnotationType',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(34004, 24, 34,
		23, 'Source',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(34006, 24, 34,
		0, 'InstanceOf',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(34007, 23, 34,
		14, 'Text',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(34008, 23, 34,
		57, 'Features',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(11001, 13, 11,
		null, 'Contents',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(67001, 16, 67,
		null, 'Question',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(67002, 16, 67,
		null, 'ExampleWords',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(67003, 14, 67,
		null, 'ExampleSentences',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(47001, 16, 47,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(47002, 18, 47,
		null, 'Description',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(47003, 15, 47,
		null, 'OriginalPath',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(47004, 15, 47,
		null, 'InternalPath',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(9001, 15, 9,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(9002, 2, 9,
		null, 'ClassId',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(9003, 2, 9,
		null, 'FieldId',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(9004, 15, 9,
		null, 'FieldInfo',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(9005, 6, 9,
		null, 'App',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(9006, 2, 9,
		null, 'Type',0,Null, 0, 127, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(9007, 27, 9,
		10, 'Rows',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(9008, 15, 9,
		null, 'ColumnInfo',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(9009, 2, 9,
		null, 'ShowPrompt',0,Null, 0, 127, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(9010, 15, 9,
		null, 'PromptText',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(2001, 16, 2,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(2003, 25, 2,
		2, 'SubFolders',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(2005, 18, 2,
		null, 'Description',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(2006, 25, 2,
		47, 'Files',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5001, 16, 5,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5002, 5, 5,
		null, 'DateCreated',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5003, 5, 5,
		null, 'DateModified',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5004, 18, 5,
		null, 'Description',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5005, 25, 5,
		42, 'Publications',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5006, 25, 5,
		45, 'HeaderFooterSets',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(21001, 15, 21,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(21002, 24, 21,
		8, 'PossList',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(21004, 26, 21,
		7, 'PossItems',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(48001, 13, 48,
		null, 'Caption',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(48002, 24, 48,
		47, 'PictureFile',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(7001, 16, 7,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(7002, 16, 7,
		null, 'Abbreviation',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(7003, 18, 7,
		null, 'Description',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(7004, 27, 7,
		7, 'SubPossibilities',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(7006, 2, 7,
		null, 'SortSpec',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(7007, 26, 7,
		7, 'Restrictions',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(7008, 24, 7,
		7, 'Confidence',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(7009, 24, 7,
		7, 'Status',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(7010, 5, 7,
		null, 'DateCreated',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(7011, 5, 7,
		null, 'DateModified',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(7012, 23, 7,
		14, 'Discussion',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(7013, 26, 7,
		13, 'Researchers',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(7014, 15, 7,
		null, 'HelpId',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(7015, 2, 7,
		null, 'ForeColor',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(7016, 2, 7,
		null, 'BackColor',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(7017, 2, 7,
		null, 'UnderColor',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(7018, 2, 7,
		null, 'UnderStyle',0,Null, 0, 127, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(7019, 1, 7,
		null, 'Hidden',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(7020, 1, 7,
		null, 'IsProtected',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(1001, 16, 1,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(1002, 5, 1,
		null, 'DateCreated',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(1004, 5, 1,
		null, 'DateModified',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(1005, 18, 1,
		null, 'Description',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(10001, 27, 10,
		11, 'Cells',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(31001, 15, 31,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(31002, 6, 31,
		null, 'App',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(31003, 2, 31,
		null, 'ClassId',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(31004, 15, 31,
		null, 'PrimaryField',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(31007, 2, 31,
		null, 'PrimaryCollType',0,Null, 0, 127, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(31009, 1, 31,
		null, 'PrimaryReverse',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(31010, 15, 31,
		null, 'SecondaryField',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(31013, 2, 31,
		null, 'SecondaryCollType',0,Null, 0, 127, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(31015, 1, 31,
		null, 'SecondaryReverse',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(31016, 15, 31,
		null, 'TertiaryField',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(31019, 2, 31,
		null, 'TertiaryCollType',0,Null, 0, 127, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(31021, 1, 31,
		null, 'TertiaryReverse',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(31022, 1, 31,
		null, 'IncludeSubentries',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(31023, 24, 31,
		24, 'PrimaryWs',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(31024, 24, 31,
		24, 'SecondaryWs',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(31025, 24, 31,
		24, 'TertiaryWs',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(31026, 24, 31,
		30, 'PrimaryCollation',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(31027, 24, 31,
		30, 'SecondaryCollation',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(31028, 24, 31,
		30, 'TertiaryCollation',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(29001, 18, 29,
		null, 'Translation',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(29002, 24, 29,
		7, 'Type',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(29003, 16, 29,
		null, 'Status',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(28001, 18, 28,
		null, 'Comment',0,Null, null, null, null)
go

go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(55001, 16, 55,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(55002, 16, 55,
		null, 'Abbreviation',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(55003, 14, 55,
		null, 'Description',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(55004, 23, 55,
		56, 'Default',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(55005, 16, 55,
		null, 'GlossAbbreviation',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(55006, 16, 55,
		null, 'RightGlossSeparator',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(55007, 1, 55,
		null, 'ShowInGloss',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(55008, 1, 55,
		null, 'DisplayToRightOfValues',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(56001, 2, 56,
		null, 'RefNumber',0,Null, 0, 268435455, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(56002, 2, 56,
		null, 'ValueState',0,Null, 0, 15, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(56003, 24, 56,
		55, 'Feature',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(59001, 16, 59,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(59002, 16, 59,
		null, 'Abbreviation',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(59003, 14, 59,
		null, 'Description',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(59004, 27, 59,
		55, 'Features',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(49002, 25, 49,
		59, 'Types',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(65001, 16, 65,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(65002, 16, 65,
		null, 'Abbreviation',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(65003, 14, 65,
		null, 'Description',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(65004, 16, 65,
		null, 'GlossAbbreviation',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(65005, 16, 65,
		null, 'RightGlossSeparator',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(65006, 1, 65,
		null, 'ShowInGloss',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(30001, 16, 30,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(30002, 2, 30,
		null, 'WinLCID',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(30003, 15, 30,
		null, 'WinCollation',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(30004, 15, 30,
		null, 'IcuResourceName',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(30005, 19, 30,
		null, 'IcuResourceText',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(30007, 19, 30,
		null, 'ICURules',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(24001, 16, 24,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(24003, 2, 24,
		null, 'Locale',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(24006, 16, 24,
		null, 'Abbr',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(24009, 15, 24,
		null, 'DefaultMonospace',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(24010, 15, 24,
		null, 'DefaultSansSerif',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(24011, 15, 24,
		null, 'DefaultSerif',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(24012, 15, 24,
		null, 'FontVariation',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(24013, 15, 24,
		null, 'KeyboardType',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(24015, 1, 24,
		null, 'RightToLeft',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(24018, 27, 24,
		30, 'Collations',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(24020, 14, 24,
		null, 'Description',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(24021, 15, 24,
		null, 'ICULocale',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(24022, 15, 24,
		null, 'KeymanKeyboard',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(24023, 15, 24,
		null, 'LegacyMapping',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(24024, 15, 24,
		null, 'SansFontVariation',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(24025, 5, 24,
		null, 'LastModified',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(43001, 1, 43,
		null, 'DifferentFirstHF',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(43002, 1, 43,
		null, 'DifferentEvenHF',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(43003, 2, 43,
		null, 'StartAt',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(43004, 23, 43,
		44, 'PageLayout',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(43005, 23, 43,
		45, 'HeaderFooterSettings',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(46001, 13, 46,
		null, 'InsideAlignedText',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(46002, 13, 46,
		null, 'CenteredText',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(46003, 13, 46,
		null, 'OutsideAlignedText',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(45001, 15, 45,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(45002, 17, 45,
		null, 'Description',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(45003, 23, 45,
		46, 'DefaultHeader',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(45004, 23, 45,
		46, 'DefaultFooter',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(45005, 23, 45,
		46, 'FirstHeader',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(45006, 23, 45,
		46, 'FirstFooter',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(45007, 23, 45,
		46, 'EvenHeader',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(45008, 23, 45,
		46, 'EvenFooter',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(42001, 15, 42,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(42002, 17, 42,
		null, 'Description',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(42003, 2, 42,
		null, 'PageHeight',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(42004, 2, 42,
		null, 'PageWidth',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(42005, 1, 42,
		null, 'IsLandscape',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(42006, 2, 42,
		null, 'GutterMargin',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(42007, 2, 42,
		null, 'GutterLoc',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(42008, 27, 42,
		43, 'Divisions',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(44001, 15, 44,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(44002, 17, 44,
		null, 'Description',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(44003, 2, 44,
		null, 'MarginTop',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(44004, 2, 44,
		null, 'MarginBottom',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(44005, 2, 44,
		null, 'MarginInside',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(44006, 2, 44,
		null, 'MarginOutside',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(44007, 2, 44,
		null, 'PosHeader',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(44008, 2, 44,
		null, 'PosFooter',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(44009, 2, 44,
		null, 'MaxPosFootnote',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(44010, 1, 44,
		null, 'IsBuiltIn',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(44011, 1, 44,
		null, 'IsModified',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(15001, 15, 15,
		null, 'StyleName',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(15002, 9, 15,
		null, 'StyleRules',0,Null, null, null, 0)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(17001, 15, 17,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(17002, 24, 17,
		17, 'BasedOn',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(17003, 24, 17,
		17, 'Next',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(17004, 2, 17,
		null, 'Type',0,Null, 0, 255, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(17005, 9, 17,
		null, 'Rules',0,Null, null, null, 0)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(17006, 1, 17,
		null, 'IsPublishedTextStyle',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(17007, 1, 17,
		null, 'IsBuiltIn',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(17008, 1, 17,
		null, 'IsModified',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(17009, 2, 17,
		null, 'UserLevel',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(17010, 2, 17,
		null, 'Role',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(17011, 2, 17,
		null, 'Context',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(17012, 2, 17,
		null, 'Structure',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(17013, 2, 17,
		null, 'Function',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(17014, 16, 17,
		null, 'Usage',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(14001, 27, 14,
		15, 'Paragraphs',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(14002, 1, 14,
		null, 'RightToLeft',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(41001, 26, 41,
		40, 'UserConfigAccount',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(41002, 6, 41,
		null, 'ApplicationId',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(41003, 2, 41,
		null, 'FeatureId',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(41004, 2, 41,
		null, 'ActivatedLevel',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(40001, 9, 40,
		null, 'Sid',0,Null, null, null, 0)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(40002, 2, 40,
		null, 'UserLevel',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(40003, 1, 40,
		null, 'HasMaintenance',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(18001, 16, 18,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(18002, 2, 18,
		null, 'Type',0,Null, 0, 127, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(18003, 6, 18,
		null, 'App',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(18004, 25, 18,
		19, 'Records',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(18005, 9, 18,
		null, 'Details',0,Null, null, null, 0)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(18006, 1, 18,
		null, 'System',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(18007, 2, 18,
		null, 'SubType',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(20001, 16, 20,
		null, 'Label',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(20002, 16, 20,
		null, 'HelpString',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(20003, 2, 20,
		null, 'Type',0,Null, 0, 127, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(20004, 2, 20,
		null, 'Flid',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(20005, 2, 20,
		null, 'Visibility',0,Null, 0, 127, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(20006, 2, 20,
		null, 'Required',0,Null, 0, 127, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(20007, 15, 20,
		null, 'Style',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(20008, 24, 20,
		20, 'SubfieldOf',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(20009, 9, 20,
		null, 'Details',0,Null, null, null, 0)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(20011, 1, 20,
		null, 'IsCustomField',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(20012, 24, 20,
		8, 'PossList',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(20013, 24, 20,
		24, 'WritingSystem',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(20014, 2, 20,
		null, 'WsSelector',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(19001, 2, 19,
		null, 'Clsid',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(19002, 2, 19,
		null, 'Level',0,Null, 0, 127, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(19003, 27, 19,
		20, 'Fields',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(19004, 9, 19,
		null, 'Details',0,Null, null, null, 0)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(35003, 1, 35,
		null, 'AllowsComment',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(35004, 1, 35,
		null, 'AllowsFeatureStructure',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(35005, 1, 35,
		null, 'AllowsInstanceOf',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(35006, 2, 35,
		null, 'InstanceOfSignature',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(35007, 1, 35,
		null, 'UserCanCreate',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(35008, 1, 35,
		null, 'CanCreateOrphan',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(35009, 1, 35,
		null, 'PromptUser',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(35010, 1, 35,
		null, 'CopyCutPastable',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(35011, 1, 35,
		null, 'ZeroWidth',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(35012, 1, 35,
		null, 'Multi',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(35013, 2, 35,
		null, 'Severity',0,Null, null, null, null)
go

go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(37001, 2, 37,
		null, 'BeginOffset',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(37003, 2, 37,
		null, 'Flid',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(37004, 2, 37,
		null, 'EndOffset',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(37005, 24, 37,
		0, 'BeginObject',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(37006, 24, 37,
		0, 'EndObject',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(37007, 26, 37,
		0, 'OtherObjects',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(37008, 24, 37,
		24, 'WritingSystem',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(37009, 2, 37,
		null, 'WsSelector',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(37010, 2, 37,
		null, 'BeginRef',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(37011, 2, 37,
		null, 'EndRef',0,Null, null, null, null)
go

go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(36001, 26, 36,
		34, 'AppliesTo',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(12001, 16, 12,
		null, 'Alias',0,Null, null, null, null)
go

go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(13001, 16, 13,
		null, 'Alias',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(13003, 2, 13,
		null, 'Gender',0,Null, 0, 2, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(13004, 8, 13,
		null, 'DateOfBirth',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(13006, 24, 13,
		12, 'PlaceOfBirth',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(13008, 1, 13,
		null, 'IsResearcher',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(13009, 26, 13,
		12, 'PlacesOfResidence',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(13010, 24, 13,
		7, 'Education',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(13011, 8, 13,
		null, 'DateOfDeath',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(13013, 26, 13,
		7, 'Positions',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(8002, 2, 8,
		null, 'Depth',0,Null, 0, 127, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(8003, 2, 8,
		null, 'PreventChoiceAboveLevel',0,Null, 0, 8, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(8004, 1, 8,
		null, 'IsSorted',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(8005, 1, 8,
		null, 'IsClosed',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(8006, 1, 8,
		null, 'PreventDuplicates',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(8007, 1, 8,
		null, 'PreventNodeChoices',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(8008, 27, 8,
		7, 'Possibilities',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(8010, 16, 8,
		null, 'Abbreviation',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(8011, 15, 8,
		null, 'HelpFile',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(8012, 1, 8,
		null, 'UseExtendedFields',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(8013, 2, 8,
		null, 'DisplayOption',0,Null, 0, 2, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(8014, 2, 8,
		null, 'ItemClsid',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(8015, 1, 8,
		null, 'IsVernacular',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(8017, 24, 8,
		24, 'WritingSystem',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(8018, 2, 8,
		null, 'WsSelector',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(66001, 15, 66,
		null, 'LouwNidaCodes',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(66002, 15, 66,
		null, 'OcmCodes',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(66003, 26, 66,
		26, 'OcmRefs',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(66004, 26, 66,
		66, 'RelatedDomains',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(66005, 27, 66,
		67, 'Questions',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(50001, 25, 50,
		65, 'Values',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(51001, 24, 51,
		65, 'Value',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4001, 24, 4,
		59, 'Type',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(53001, 23, 53,
		60, 'Value',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(54001, 26, 54,
		65, 'Value',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(57001, 25, 57,
		58, 'FeatureDisjunctions',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(57002, 25, 57,
		56, 'FeatureSpecs',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(57003, 24, 57,
		59, 'Type',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(58001, 25, 58,
		57, 'Contents',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(61001, 24, 61,
		65, 'Value',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(62002, 24, 62,
		24, 'WritingSystem',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(62003, 2, 62,
		null, 'WsSelector',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(63001, 16, 63,
		null, 'Value',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(64001, 24, 64,
		56, 'Value',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(39001, 13, 39,
		null, 'FootnoteMarker',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(39002, 1, 39,
		null, 'DisplayFootnoteReference',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(39003, 1, 39,
		null, 'DisplayFootnoteMarker',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(16001, 13, 16,
		null, 'Label',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(16002, 17, 16,
		null, 'Contents',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(16004, 28, 16,
		0, 'TextObjects',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(16005, 27, 16,
		0, 'AnalyzedTextObjects',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(16006, 26, 16,
		0, 'ObjRefs',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(16008, 25, 16,
		29, 'Translations',0,Null, null, null, null)
go




insert into Module$ ([Id], [Name], [Ver], [VerBack])
	values(4, 'Notebk', 1, 1)





insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(4007, 4, 0, 0, 'Reminder')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(4004, 4, 0, 1, 'RnGenericRecord')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(4010, 4, 0, 0, 'RnRoledParticipants')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(4005, 4, 4004, 0, 'RnAnalysis')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(4006, 4, 4004, 0, 'RnEvent')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(4001, 4, 5, 0, 'RnResearchNotebook')



insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4007001, 17, 4007,
		null, 'Description',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4007002, 8, 4007,
		null, 'Date',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4004001, 13, 4004,
		null, 'Title',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4004002, 23, 4004,
		14, 'VersionHistory',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4004003, 26, 4004,
		4007, 'Reminders',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4004004, 26, 4004,
		13, 'Researchers',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4004005, 24, 4004,
		7, 'Confidence',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4004006, 26, 4004,
		7, 'Restrictions',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4004007, 26, 4004,
		26, 'AnthroCodes',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4004008, 26, 4004,
		7, 'PhraseTags',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4004009, 27, 4004,
		4004, 'SubRecords',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4004010, 5, 4004,
		null, 'DateCreated',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4004011, 5, 4004,
		null, 'DateModified',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4004012, 26, 4004,
		28, 'CrossReferences',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4004013, 23, 4004,
		14, 'ExternalMaterials',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4004014, 23, 4004,
		14, 'FurtherQuestions',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4004015, 26, 4004,
		4004, 'SeeAlso',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4010001, 26, 4010,
		13, 'Participants',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4010002, 24, 4010,
		7, 'Role',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4005001, 23, 4005,
		14, 'Hypothesis',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4005002, 23, 4005,
		14, 'ResearchPlan',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4005003, 23, 4005,
		14, 'Discussion',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4005004, 23, 4005,
		14, 'Conclusions',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4005005, 28, 4005,
		4004, 'SupportingEvidence',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4005006, 28, 4005,
		4004, 'CounterEvidence',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4005007, 26, 4005,
		4005, 'SupersededBy',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4005008, 24, 4005,
		7, 'Status',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4006001, 23, 4006,
		14, 'Description',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4006002, 25, 4006,
		4010, 'Participants',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4006003, 26, 4006,
		12, 'Locations',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4006004, 24, 4006,
		7, 'Type',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4006006, 26, 4006,
		7, 'Weather',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4006007, 26, 4006,
		13, 'Sources',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4006008, 8, 4006,
		null, 'DateOfEvent',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4006009, 26, 4006,
		7, 'TimeOfEvent',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4006010, 23, 4006,
		14, 'PersonalNotes',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4001001, 25, 4001,
		4004, 'Records',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4001002, 25, 4001,
		4007, 'Reminders',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4001003, 23, 4001,
		8, 'EventTypes',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(4001004, 25, 4001,
		28, 'CrossReferences',0,Null, null, null, null)
go



insert into Module$ ([Id], [Name], [Ver], [VerBack])
	values(5, 'Ling', 1, 1)





insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5046, 5, 0, 0, 'LexAppendix')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5002, 5, 0, 1, 'LexEntry')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5113, 5, 0, 0, 'LexEtymology')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5004, 5, 0, 0, 'LexExampleSentence')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5006, 5, 0, 0, 'LexicalRelationGroup')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5010, 5, 0, 0, 'LexPair')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5013, 5, 0, 0, 'LexPicture')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5014, 5, 0, 0, 'LexPronunciation')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5003, 5, 0, 0, 'LexRefEntryOrSense')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5016, 5, 0, 0, 'LexSense')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5017, 5, 0, 1, 'LexSet')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5018, 5, 0, 0, 'LexSetItem')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5023, 5, 0, 0, 'LexTreeItem')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5114, 5, 0, 0, 'LexVariant')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5026, 5, 0, 1, 'MoAdhocCoProhibition')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5030, 5, 0, 1, 'MoCompoundRule')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5100, 5, 0, 0, 'MoDerivation')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5072, 5, 0, 1, 'MoDerivationTrace')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5035, 5, 0, 1, 'MoForm')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5109, 5, 0, 0, 'MoGlossItem')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5108, 5, 0, 0, 'MoGlossSystem')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5036, 5, 0, 0, 'MoInflAffixSlot')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5037, 5, 0, 0, 'MoInflAffixTemplate')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5039, 5, 0, 0, 'MoInflectionClass')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5040, 5, 0, 0, 'MoMorphologicalData')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5041, 5, 0, 1, 'MoMorphoSyntaxAnalysis')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5044, 5, 0, 0, 'MoReferralRule')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5066, 5, 0, 1, 'MoRuleMapping')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5047, 5, 0, 0, 'MoStemName')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5048, 5, 0, 0, 'MoStratum')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5098, 5, 0, 0, 'PhCode')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5080, 5, 0, 1, 'PhContextOrVar')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5097, 5, 0, 0, 'PhEnvironment')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5096, 5, 0, 0, 'PhFeatureConstraint')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5093, 5, 0, 1, 'PhNaturalClass')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5089, 5, 0, 0, 'PhPhonemeSet')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5099, 5, 0, 0, 'PhPhonologicalData')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5090, 5, 0, 1, 'PhTerminalUnit')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5053, 5, 0, 0, 'ReversalIndexEntry')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5054, 5, 0, 0, 'Text')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5059, 5, 0, 0, 'WfiAnalysis')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5060, 5, 0, 0, 'WfiGloss')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5112, 5, 0, 0, 'WfiMorphBundle')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5062, 5, 0, 0, 'WfiWordform')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5105, 5, 0, 0, 'WfiWordSet')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5064, 5, 0, 0, 'WordformLookupItem')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5005, 5, 5, 0, 'LexicalDatabase')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5008, 5, 5002, 0, 'LexMajorEntry')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5009, 5, 5002, 0, 'LexMinorEntry')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5011, 5, 5017, 0, 'LexPairRelation')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5015, 5, 5017, 0, 'LexScale')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5019, 5, 5017, 0, 'LexSimpleSet')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5021, 5, 7, 0, 'LexSubentryType')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5024, 5, 5017, 0, 'LexTreeRelation')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5110, 5, 5026, 0, 'MoAdhocCoProhibitionGroup')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5028, 5, 5035, 1, 'MoAffixForm')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5101, 5, 5026, 0, 'MoAllomorphAdhocCoProhibition')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5106, 5, 5030, 0, 'MoBinaryCompoundRule')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5073, 5, 5072, 0, 'MoCompoundRuleApp')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5103, 5, 5066, 0, 'MoCopyFromInput')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5074, 5, 5072, 0, 'MoDerivationalAffixApp')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5031, 5, 5041, 0, 'MoDerivationalAffixMsa')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5032, 5, 5041, 0, 'MoDerivationalStepMsa')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5075, 5, 5072, 0, 'MoInflAffixSlotApp')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5038, 5, 5041, 0, 'MoInflectionalAffixMsa')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5076, 5, 5072, 0, 'MoInflTemplateApp')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5069, 5, 5066, 0, 'MoInsertNC')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5068, 5, 5066, 0, 'MoInsertPhones')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5070, 5, 5066, 0, 'MoModifyFromInput')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5102, 5, 5026, 0, 'MoMorphemeAdhocCoProhibition')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5042, 5, 7, 0, 'MoMorphType')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5077, 5, 5072, 0, 'MoPhonolRuleApp')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5045, 5, 5035, 0, 'MoStemAllomorph')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5001, 5, 5041, 0, 'MoStemMsa')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5078, 5, 5072, 0, 'MoStratumApp')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5049, 5, 7, 0, 'PartOfSpeech')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5091, 5, 5090, 0, 'PhBdryMarker')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5094, 5, 5093, 0, 'PhNCFeatures')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5095, 5, 5093, 0, 'PhNCSegments')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5092, 5, 5090, 0, 'PhPhoneme')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5081, 5, 5080, 1, 'PhPhonologicalContext')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5088, 5, 5080, 0, 'PhVariable')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5052, 5, 5, 0, 'ReversalIndex')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5063, 5, 5, 0, 'WordformInventory')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5065, 5, 5, 0, 'WordformLookupList')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5007, 5, 5008, 0, 'LexSubentry')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5027, 5, 5028, 0, 'MoAffixAllomorph')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5029, 5, 5028, 0, 'MoAffixProcess')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5107, 5, 5106, 0, 'MoCoordinateCompound')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5033, 5, 5106, 0, 'MoEndocentricCompound')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5034, 5, 5106, 0, 'MoExocentricCompound')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5082, 5, 5081, 0, 'PhIterationContext')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5083, 5, 5081, 0, 'PhSequenceContext')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5084, 5, 5081, 1, 'PhSimpleContext')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5085, 5, 5084, 0, 'PhSimpleContextBdry')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5086, 5, 5084, 0, 'PhSimpleContextNC')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(5087, 5, 5084, 0, 'PhSimpleContextSeg')



insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5046001, 23, 5046,
		14, 'Contents',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5002001, 2, 5002,
		null, 'HomographNumber',0,Null, 0, 255, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5002002, 1, 5002,
		null, 'IsIncludedAsHeadword',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5002003, 16, 5002,
		null, 'CitationForm',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5002005, 5, 5002,
		null, 'DateCreated',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5002006, 5, 5002,
		null, 'DateModified',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5002008, 27, 5002,
		5035, 'Allomorphs',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5002009, 25, 5002,
		5041, 'MorphoSyntaxAnalyses',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5002010, 23, 5002,
		5035, 'UnderlyingForm',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5002011, 27, 5002,
		5016, 'Senses',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5002012, 14, 5002,
		null, 'Bibliography',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5002013, 23, 5002,
		5113, 'Etymology',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5002014, 16, 5002,
		null, 'Restrictions',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5002015, 25, 5002,
		5114, 'Variants',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5002016, 23, 5002,
		5014, 'Pronunciation',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5113001, 18, 5113,
		null, 'Comment',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5113002, 16, 5113,
		null, 'Form',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5113003, 16, 5113,
		null, 'Gloss',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5113004, 15, 5113,
		null, 'Source',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5004001, 14, 5004,
		null, 'Example',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5004002, 13, 5004,
		null, 'Reference',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5004003, 25, 5004,
		29, 'Translations',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5006001, 14, 5006,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5006002, 14, 5006,
		null, 'Abbreviation',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5006003, 14, 5006,
		null, 'Comment',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5006004, 14, 5006,
		null, 'AVariableAbbr',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5006005, 14, 5006,
		null, 'AVariableName',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5006006, 14, 5006,
		null, 'AbFunctionFrame',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5006007, 14, 5006,
		null, 'BVariableAbbr',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5006008, 14, 5006,
		null, 'BVariableName',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5006009, 14, 5006,
		null, 'BaFunctionFrame',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5006010, 25, 5006,
		5017, 'Members',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5006011, 2, 5006,
		null, 'SetType',0,Null, 1, 4, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5010001, 14, 5010,
		null, 'Comment',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5010002, 23, 5010,
		5018, 'MemberA',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5010003, 23, 5010,
		5018, 'MemberB',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5013001, 14, 5013,
		null, 'Caption',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5013002, 7, 5013,
		null, 'Picture',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5014001, 16, 5014,
		null, 'Form',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5014002, 7, 5014,
		null, 'Sound',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5003001, 24, 5003,
		5002, 'Entry',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5003002, 24, 5003,
		5016, 'Sense',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5016001, 24, 5016,
		5041, 'MorphoSyntaxAnalysis',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5016002, 26, 5016,
		26, 'AnthroCodes',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5016003, 27, 5016,
		5016, 'Senses',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5016004, 26, 5016,
		5046, 'Appendixes',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5016005, 14, 5016,
		null, 'Definition',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5016006, 26, 5016,
		7, 'DomainTypes',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5016007, 27, 5016,
		5004, 'Examples',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5016008, 16, 5016,
		null, 'Gloss',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5016009, 26, 5016,
		5053, 'ReversalEntries',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5016010, 27, 5016,
		5013, 'Pictures',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5016011, 13, 5016,
		null, 'ScientificName',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5016012, 24, 5016,
		7, 'SenseType',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5016013, 26, 5016,
		7, 'ThesaurusItems',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5016014, 26, 5016,
		7, 'UsageTypes',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5016015, 18, 5016,
		null, 'AnthroNote',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5016016, 14, 5016,
		null, 'Bibliography',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5016017, 18, 5016,
		null, 'DiscourseNote',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5016018, 18, 5016,
		null, 'EncyclopedicInfo',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5016019, 18, 5016,
		null, 'GeneralNote',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5016020, 18, 5016,
		null, 'GrammarNote',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5016021, 18, 5016,
		null, 'PhonologyNote',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5016022, 16, 5016,
		null, 'Restrictions',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5016023, 18, 5016,
		null, 'SemanticsNote',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5016024, 18, 5016,
		null, 'SocioLinguisticsNote',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5016025, 13, 5016,
		null, 'Source',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5016026, 24, 5016,
		7, 'Status',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5016027, 26, 5016,
		66, 'SemanticDomains',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5017001, 14, 5017,
		null, 'Abbreviation',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5017002, 14, 5017,
		null, 'Comment',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5017003, 14, 5017,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5017004, 24, 5017,
		5049, 'PartOfSpeech',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5018001, 14, 5018,
		null, 'Comment',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5018002, 24, 5018,
		5016, 'Sense',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5018003, 24, 5018,
		5019, 'SimpleSet',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5023001, 27, 5023,
		5023, 'Items',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5023002, 23, 5023,
		5018, 'Member',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5114001, 14, 5114,
		null, 'Comment',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5114002, 16, 5114,
		null, 'Form',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5114003, 23, 5114,
		5014, 'Pronunciation',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5026002, 2, 5026,
		null, 'Adjacency',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5030001, 16, 5030,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5030002, 14, 5030,
		null, 'Description',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5030004, 23, 5030,
		57, 'ToExceptionFeatures',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5030007, 24, 5030,
		5048, 'Stratum',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5100001, 24, 5100,
		5045, 'StemForm',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5100002, 24, 5100,
		5001, 'StemMsa',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5100003, 23, 5100,
		57, 'InflectionalFeatures',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5100004, 27, 5100,
		5078, 'StratumApps',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5072001, 16, 5072,
		null, 'OutputForm',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5035001, 16, 5035,
		null, 'Form',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5035002, 24, 5035,
		5042, 'MorphType',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5109001, 16, 5109,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5109002, 16, 5109,
		null, 'Abbreviation',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5109003, 2, 5109,
		null, 'Type',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5109004, 15, 5109,
		null, 'AfterSeparator',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5109005, 15, 5109,
		null, 'ComplexNameSeparator',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5109006, 1, 5109,
		null, 'ComplexNameFirst',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5109007, 1, 5109,
		null, 'Status',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5109008, 23, 5109,
		57, 'FeatureStructureFragment',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5109009, 27, 5109,
		5109, 'GlossItems',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5109010, 24, 5109,
		5109, 'Target',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5109011, 15, 5109,
		null, 'EticID',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5108001, 25, 5108,
		5109, 'Glosses',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5036001, 16, 5036,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5036002, 14, 5036,
		null, 'Description',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5036004, 1, 5036,
		null, 'Optional',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5037001, 16, 5037,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5037002, 14, 5037,
		null, 'Description',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5037003, 28, 5037,
		5036, 'Slots',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5037004, 24, 5037,
		5048, 'Stratum',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5037005, 23, 5037,
		57, 'Region',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5037006, 28, 5037,
		5036, 'PrefixSlots',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5037007, 28, 5037,
		5036, 'SuffixSlots',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5037008, 1, 5037,
		null, 'Final',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5039001, 16, 5039,
		null, 'Abbreviation',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5039002, 14, 5039,
		null, 'Description',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5039003, 16, 5039,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5039004, 25, 5039,
		5039, 'Subclasses',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5039005, 27, 5039,
		5044, 'RulesOfReferral',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5039006, 25, 5039,
		5047, 'StemNames',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5039007, 25, 5039,
		57, 'ReferenceForms',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5040001, 27, 5040,
		5048, 'Strata',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5040002, 27, 5040,
		5030, 'CompoundRules',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5040003, 25, 5040,
		5026, 'AdhocCoProhibitions',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5040005, 26, 5040,
		23, 'AnalyzingAgents',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5040006, 25, 5040,
		5105, 'TestSets',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5040007, 23, 5040,
		5108, 'GlossSystem',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5040008, 15, 5040,
		null, 'ParserParameters',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5041001, 28, 5041,
		5041, 'Components',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5041002, 15, 5041,
		null, 'GlossString',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5041003, 28, 5041,
		5109, 'GlossBundle',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5044001, 16, 5044,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5044002, 14, 5044,
		null, 'Description',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5044003, 23, 5044,
		57, 'Input',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5044004, 23, 5044,
		57, 'Output',0,Null, null, null, null)
go

go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5047001, 16, 5047,
		null, 'Abbreviation',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5047002, 14, 5047,
		null, 'Description',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5047003, 16, 5047,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5047004, 25, 5047,
		57, 'Regions',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5047006, 24, 5047,
		5038, 'DefaultAffix',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5047007, 24, 5047,
		5047, 'DefaultStem',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5048001, 16, 5048,
		null, 'Abbreviation',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5048002, 14, 5048,
		null, 'Description',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5048003, 16, 5048,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5048004, 24, 5048,
		5089, 'Phonemes',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5098001, 16, 5098,
		null, 'Representation',0,Null, null, null, null)
go

go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5097001, 16, 5097,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5097002, 14, 5097,
		null, 'Description',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5097004, 24, 5097,
		5081, 'LeftContext',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5097005, 24, 5097,
		5081, 'RightContext',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5097006, 15, 5097,
		null, 'AMPLEStringSegment',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5097007, 15, 5097,
		null, 'StringRepresentation',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5096001, 24, 5096,
		55, 'Feature',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5093001, 16, 5093,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5093003, 14, 5093,
		null, 'Description',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5093004, 16, 5093,
		null, 'Abbreviation',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5089001, 16, 5089,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5089002, 25, 5089,
		5092, 'Phonemes',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5089003, 25, 5089,
		5091, 'BoundaryMarkers',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5089004, 14, 5089,
		null, 'Description',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5099001, 27, 5099,
		5089, 'PhonemeSets',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5099002, 27, 5099,
		5097, 'Environments',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5099003, 27, 5099,
		5093, 'NaturalClasses',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5099004, 27, 5099,
		5080, 'Contexts',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5090001, 16, 5090,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5090002, 14, 5090,
		null, 'Description',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5090003, 27, 5090,
		5098, 'Codes',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5053001, 13, 5053,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5053002, 25, 5053,
		5053, 'Subentries',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5053003, 24, 5053,
		5049, 'PartOfSpeech',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5054002, 14, 5054,
		null, 'Source',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5054003, 15, 5054,
		null, 'SoundFilePath',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5054008, 23, 5054,
		14, 'Contents',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5059003, 24, 5059,
		5049, 'Category',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5059004, 23, 5059,
		57, 'MsFeatures',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5059005, 26, 5059,
		5002, 'Stems',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5059006, 23, 5059,
		5100, 'Derivation',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5059010, 25, 5059,
		5060, 'Meanings',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5059011, 27, 5059,
		5112, 'MorphBundles',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5059012, 28, 5059,
		5030, 'CompoundRuleApps',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5059013, 28, 5059,
		5037, 'InflectionalTemplateApps',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5060001, 16, 5060,
		null, 'Form',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5112001, 14, 5112,
		null, 'Form',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5112002, 24, 5112,
		5035, 'Morph',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5112003, 24, 5112,
		5041, 'Msa',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5112004, 24, 5112,
		5016, 'Sense',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5062001, 16, 5062,
		null, 'Form',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5062002, 25, 5062,
		5059, 'Analyses',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5062003, 2, 5062,
		null, 'SpellingStatus',0,Null, 0, 2, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5105001, 16, 5105,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5105002, 14, 5105,
		null, 'Description',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5105004, 26, 5105,
		5062, 'Cases',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5064001, 13, 5064,
		null, 'Form',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5064002, 2, 5064,
		null, 'ThesaurusCentral',0,Null, 0, 32768, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5064003, 26, 5064,
		7, 'ThesaurusItems',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5064004, 2, 5064,
		null, 'AnthroCentral',0,Null, 0, 32768, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5064005, 26, 5064,
		26, 'AnthroCodes',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5005001, 25, 5005,
		5002, 'Entries',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5005002, 25, 5005,
		5046, 'Appendixes',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5005003, 25, 5005,
		5006, 'LexicalRelations',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5005004, 23, 5005,
		8, 'AllomorphConditions',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5005005, 23, 5005,
		8, 'SenseTypes',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5005006, 23, 5005,
		8, 'UsageTypes',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5005007, 23, 5005,
		8, 'DomainTypes',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5005008, 23, 5005,
		8, 'MorphTypes',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5005009, 23, 5005,
		8, 'SubentryTypes',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5005010, 26, 5005,
		5002, 'LexicalFormIndex',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5005011, 26, 5005,
		5035, 'AllomorphIndex',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5005012, 23, 5005,
		14, 'Introduction',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5005013, 1, 5005,
		null, 'IsHeadwordCitationForm',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5005014, 1, 5005,
		null, 'IsBodyInSeparateSubentry',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5005015, 23, 5005,
		8, 'Status',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5008003, 14, 5008,
		null, 'SummaryDefinition',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5009001, 23, 5009,
		5003, 'MainEntryOrSense',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5009002, 24, 5009,
		7, 'Condition',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5009003, 14, 5009,
		null, 'Comment',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5009004, 23, 5009,
		57, 'Features',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5011001, 14, 5011,
		null, 'AAbbr',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5011002, 14, 5011,
		null, 'AName',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5011003, 14, 5011,
		null, 'AbFrame',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5011004, 14, 5011,
		null, 'BAbbr',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5011005, 14, 5011,
		null, 'BName',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5011006, 14, 5011,
		null, 'BaFrame',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5011007, 25, 5011,
		5010, 'Members',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5011008, 24, 5011,
		5049, 'PartOfSpeechB',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5015001, 27, 5015,
		5018, 'Negative',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5015002, 23, 5015,
		5018, 'Neutral',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5015003, 27, 5015,
		5018, 'Positive',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5019001, 25, 5019,
		5018, 'Members',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5021001, 2, 5021,
		null, 'SecondaryOrder',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5024001, 14, 5024,
		null, 'DownFrame',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5024002, 27, 5024,
		5023, 'Items',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5024003, 14, 5024,
		null, 'LowerAbbr',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5024004, 14, 5024,
		null, 'LowerName',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5024005, 14, 5024,
		null, 'UpFrame',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5024006, 14, 5024,
		null, 'UpperAbbr',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5024007, 14, 5024,
		null, 'UpperName',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5110001, 16, 5110,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5110002, 14, 5110,
		null, 'Description',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5110003, 25, 5110,
		5026, 'Members',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5028001, 26, 5028,
		5039, 'InflectionClasses',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5101001, 28, 5101,
		5035, 'Allomorphs',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5101002, 24, 5101,
		5035, 'FirstAllomorph',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5101003, 28, 5101,
		5035, 'RestOfAllomorphs',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5106001, 23, 5106,
		5001, 'LeftMsa',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5106002, 23, 5106,
		5001, 'RightMsa',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5106003, 23, 5106,
		5028, 'Linker',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5073001, 24, 5073,
		5045, 'LeftForm',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5073002, 24, 5073,
		5045, 'RightForm',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5073003, 24, 5073,
		5027, 'Linker',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5103001, 24, 5103,
		5080, 'Content',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5074001, 24, 5074,
		5027, 'AffixForm',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5074002, 24, 5074,
		5031, 'AffixMsa',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5074003, 23, 5074,
		5032, 'OutputMsa',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5031001, 23, 5031,
		57, 'FromMsFeatures',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5031002, 23, 5031,
		57, 'ToMsFeatures',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5031003, 24, 5031,
		5049, 'FromPartOfSpeech',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5031004, 24, 5031,
		5049, 'ToPartOfSpeech',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5031005, 24, 5031,
		5039, 'FromInflectionClass',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5031006, 24, 5031,
		5039, 'ToInflectionClass',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5031007, 23, 5031,
		57, 'FromExceptionFeatures',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5031008, 24, 5031,
		7, 'AffixCategory',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5031009, 1, 5031,
		null, 'Defined',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5031010, 24, 5031,
		5047, 'FromStemName',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5031011, 23, 5031,
		57, 'ToExceptionFeatures',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5031012, 24, 5031,
		5048, 'Stratum',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5032001, 24, 5032,
		5049, 'PartOfSpeech',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5032002, 23, 5032,
		57, 'MsFeatures',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5032003, 23, 5032,
		57, 'InflectionFeatures',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5032004, 24, 5032,
		5039, 'InflectionClass',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5032005, 24, 5032,
		57, 'ExceptionFeatures',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5075001, 24, 5075,
		5036, 'Slot',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5075002, 24, 5075,
		5028, 'AffixForm',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5075003, 24, 5075,
		5038, 'AffixMsa',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5038001, 25, 5038,
		57, 'InflectionFeatures',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5038002, 24, 5038,
		7, 'AffixCategory',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5038003, 23, 5038,
		57, 'FromExceptionFeatures',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5038004, 24, 5038,
		0, 'PartOfSpeechOrSlot',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5076001, 24, 5076,
		5037, 'Template',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5076002, 27, 5076,
		5075, 'SlotApps',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5069001, 24, 5069,
		5093, 'Content',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5068001, 28, 5068,
		5090, 'Content',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5070001, 24, 5070,
		5080, 'Content',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5070002, 24, 5070,
		5094, 'Modification',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5102001, 28, 5102,
		5041, 'Morphemes',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5102002, 24, 5102,
		5041, 'FirstMorpheme',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5102003, 28, 5102,
		5041, 'RestOfMorphemes',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5042001, 15, 5042,
		null, 'Postfix',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5042002, 15, 5042,
		null, 'Prefix',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5042003, 2, 5042,
		null, 'SecondaryOrder',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5077001, 24, 5077,
		0, 'Rule',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5077002, 1, 5077,
		null, 'VacuousApp',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5045002, 26, 5045,
		5097, 'PhoneEnv',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5045003, 24, 5045,
		5047, 'StemName',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5001001, 23, 5001,
		57, 'MsFeatures',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5001002, 24, 5001,
		5049, 'PartOfSpeech',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5001003, 24, 5001,
		5039, 'InflectionClass',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5001004, 23, 5001,
		57, 'ExceptionFeatures',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5001005, 24, 5001,
		5048, 'Stratum',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5078001, 24, 5078,
		5048, 'Stratum',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5078002, 27, 5078,
		5073, 'CompoundRuleApps',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5078003, 27, 5078,
		5074, 'DerivationalAffixApps',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5078004, 23, 5078,
		5076, 'TemplateApp',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5078005, 27, 5078,
		5077, 'PRuleApps',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5049001, 23, 5049,
		57, 'InherentFeatureValues',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5049002, 25, 5049,
		57, 'EmptyParadigmCells',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5049003, 27, 5049,
		5044, 'RulesOfReferral',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5049004, 25, 5049,
		5039, 'InflectionClasses',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5049005, 27, 5049,
		5037, 'AffixTemplates',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5049006, 25, 5049,
		5036, 'AffixSlots',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5049007, 25, 5049,
		5047, 'StemNames',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5049008, 26, 5049,
		55, 'BearableFeatures',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5049009, 26, 5049,
		55, 'InflectableFeatures',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5049010, 25, 5049,
		57, 'ReferenceForms',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5049011, 23, 5049,
		57, 'DefaultFeatures',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5049012, 24, 5049,
		5039, 'DefaultInflectionClass',0,Null, null, null, null)
go

go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5094001, 23, 5094,
		57, 'Features',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5095001, 26, 5095,
		5092, 'Segments',0,Null, null, null, null)
go

go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5081001, 16, 5081,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5081002, 23, 5081,
		14, 'Description',0,Null, null, null, null)
go

go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5052001, 23, 5052,
		8, 'PartsOfSpeech',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5052003, 25, 5052,
		5053, 'Entries',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5052004, 24, 5052,
		24, 'WritingSystem',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5063001, 25, 5063,
		5062, 'Wordforms',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5065001, 25, 5065,
		5064, 'Wordforms',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5065003, 24, 5065,
		24, 'WritingSystem',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5007001, 27, 5007,
		5003, 'MainEntriesOrSenses',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5007002, 24, 5007,
		5021, 'SubentryType',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5007003, 14, 5007,
		null, 'LiteralMeaning',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5007004, 1, 5007,
		null, 'IsBodyWithHeadword',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5027001, 23, 5027,
		57, 'MsEnvFeatures',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5027002, 26, 5027,
		5097, 'PhoneEnv',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5027004, 24, 5027,
		5049, 'MsEnvPartOfSpeech',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5027005, 28, 5027,
		5097, 'Position',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5029002, 27, 5029,
		5080, 'Input',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5029003, 27, 5029,
		5066, 'Output',0,Null, null, null, null)
go

go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5033001, 1, 5033,
		null, 'HeadLast',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5034001, 23, 5034,
		5001, 'ToMsa',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5082001, 2, 5082,
		null, 'Minimum',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5082002, 2, 5082,
		null, 'Maximum',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5082003, 24, 5082,
		5081, 'Member',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5083001, 28, 5083,
		5081, 'Members',0,Null, null, null, null)
go

go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5085001, 24, 5085,
		5091, 'FeatureStructure',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5086001, 24, 5086,
		5093, 'FeatureStructure',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5086002, 28, 5086,
		5096, 'PlusConstraints',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5086003, 28, 5086,
		5096, 'MinusConstraints',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(5087001, 24, 5087,
		5092, 'FeatureStructure',0,Null, null, null, null)
go












print '****************************** Loading LingSP.sql ******************************'
go

if object_id('WasParsingDataModified') is not null begin
	print 'removing proc WasParsingDataModified'
	drop proc WasParsingDataModified
end
print 'creating proc WasParsingDataModified'
go












create proc [WasParsingDataModified]
            @stampCompare timestamp
AS
	SELECT TOP 1 Id
	FROM CmObject co 
	where co.UpdStmp > @stampCompare
		and (co.Class$ BETWEEN 5026 AND 5045
			OR co.Class$ IN
			(5005, --5005
			5007, --5007
			5008, --5008 
			5009 --5009
			))
go




if object_id('dbo.GetSensesForSense') is not null begin
	print 'removing proc GetSensesForSense'
	drop proc dbo.GetSensesForSense
end
print 'creating proc GetSensesForSense'
go













create proc dbo.GetSensesForSense
	@SenseId as integer
as
	declare @nCurDepth int, @rowCnt int, @str varchar(100)
	declare @fIsNocountOn int

	set @nCurDepth = 0

	declare @lexSenses table (
		ownrId	int,
		sensId	int,
		ord	int,
		depth	int,
		sensNum	nvarchar(1000)
	)

	-- deterimine if no count is currently set to on
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on	

	insert into @lexSenses
	select 	Src, Dst, ord, @nCurDepth, convert(nvarchar(10), ord+1)
	from	lexSense_Senses 
	where	Src = @SenseId

	set @rowCnt = @@rowcount
	while @rowCnt > 0
	begin
		set @nCurDepth = @nCurDepth + 1

		insert into @lexSenses
		select 	lst.Src, lst.Dst, lst.ord, @nCurDepth, sensNum+'.'+replicate(' ', 5-len(convert(nvarchar(10), lst.ord+1)))+convert(nvarchar(10), lst.ord+1)
		from	@lexSenses ls
		join lexSense_Senses lst  on ls.sensId = lst.Src
		where	depth = @nCurDepth - 1
		
		set @rowCnt = @@rowcount
	end

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	select 	* 
	from 	@lexSenses
	order by sensNum
go

if object_id('dbo.fnGetSensesInEntry$') is not null begin
	print 'removing function fnGetSensesInEntry$'
	drop function dbo.fnGetSensesInEntry$
end
print 'creating function fnGetSensesInEntry$'
go


















CREATE FUNCTION dbo.fnGetSensesInEntry$ (
	@nEntryId INT )
RETURNS @tblLexSenses TABLE (
	EntryId INT,
	OwnerId	INT,
	SenseId	INT,
	Ord	INT,
	depth INT,
	SenseNum NVARCHAR(1000),
	SenseNumDummy NVARCHAR(1000) )
AS
BEGIN
	DECLARE
		@nCurDepth INT,
		@nRowCount INT,
		@vcStr VARCHAR(100),
		@SenseId INT

	SET @nCurDepth = 0
	
	--== Get senses for all entries ==--
		
	IF @nEntryId IS NULL BEGIN
		-- insert lexical sense at the highest depth - sense related directly to the specified entry
		insert into @tblLexSenses
		select 	le.[Id], les.Src, les.Dst, les.ord, @nCurDepth,
			replicate('', 5-len(convert(nvarchar(10), les.ord)))+convert(nvarchar(10), les.ord),
			replicate('  ', 5-len(convert(nvarchar(10), les.ord)))+convert(nvarchar(10), les.ord)
		from LexEntry_Senses les 
		JOIN LexEntry le  ON le.[Id] = les.[Src]
		
		-- loop through the reference sequence hierarchy getting each of the senses at every depth
		set @nRowCount = @@rowcount
		while @nRowCount > 0
		begin
			set @nCurDepth = @nCurDepth + 1
			
			insert into @tblLexSenses
			select 	ls.EntryId, ls.SenseId, lst.Dst, lst.ord, @nCurDepth,
				SenseNum+'.'+replicate('', 5-len(convert(nvarchar(10), lst.ord)))+convert(nvarchar(10), lst.ord),
				SenseNumDummy+'.'+replicate('  ', 5-len(convert(nvarchar(10), lst.ord)))+convert(nvarchar(10), lst.ord)
			from	@tblLexSenses ls
			join lexSense_Senses lst  on ls.SenseId = lst.Src
			where	depth = @nCurDepth - 1
			--( The original procedure had an order by SenseNumDummy here.
			
			set @nRowCount = @@rowcount
		end
	END
	
	--== Get senses for specified entry ==--
	
	ELSE BEGIN
		-- insert lexical sense at the highest depth - sense related directly to the specified entry
		insert into @tblLexSenses
		select 	@nEntryId, les.Src, les.Dst, les.ord, @nCurDepth,
			replicate('', 5-len(convert(nvarchar(10), les.ord)))+convert(nvarchar(10), les.ord),
			replicate('  ', 5-len(convert(nvarchar(10), les.ord)))+convert(nvarchar(10), les.ord)
		from	LexEntry_Senses les 
		where	les.Src = @nEntryId
		
		-- loop through the reference sequence hierarchy getting each of the senses at every depth
		set @nRowCount = @@rowcount
		while @nRowCount > 0
		begin
			set @nCurDepth = @nCurDepth + 1
			
			insert into @tblLexSenses
			select 	@nEntryId, ls.SenseId, lst.Dst, lst.ord, @nCurDepth,
				SenseNum+'.'+replicate('', 5-len(convert(nvarchar(10), lst.ord)))+convert(nvarchar(10), lst.ord),
				SenseNumDummy+'.'+replicate('  ', 5-len(convert(nvarchar(10), lst.ord)))+convert(nvarchar(10), lst.ord)
			from	@tblLexSenses ls
			join lexSense_Senses lst  on ls.SenseId = lst.Src
			where	depth = @nCurDepth - 1
			--( The original procedure had an order by SenseNumDummy here.
			
			set @nRowCount = @@rowcount
		end
	END
	
	RETURN
END
go

if object_id('GetEntriesAndSenses$') is not null begin
	print 'removing proc GetEntriesAndSenses$'
	drop proc GetEntriesAndSenses$
end
print 'creating proc GetEntriesAndSenses$'
go
















create proc [GetEntriesAndSenses$]
	@LdbId as integer = null,
	@aenc as integer = null,
	@vws as integer = null
as
	declare @fIsNocountOn int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- Make sure we have the LDB id.
	if @LdbId is null begin
		select top 1 @LdbId=ldb.Id
		from LexicalDatabase ldb 
		order by ldb.Id
	end

	-- Make sure we have the analysis writing system
	if @aenc is null begin
		select top 1 @aenc=Lg.Id
		from languageProject_CurrentAnalysisWritingSystems cae 
		join LgWritingSystem lg  On Lg.Id=cae.Dst
		order by cae.ord
	end

	-- Make sure we have the vernacular writing system
	if @vws is null begin
		select top 1 @vws=Lg.Id
		from languageProject_CurrentVernacularWritingSystems cve 
		join LgWritingSystem lg  On Lg.Id=cve.Dst
		order by cve.ord
	end

	DECLARE @tblSenses TABLE (
		entryId int,
		ownrId int,
		sensId int,
		ord int,
		depth int,
		sensNum nvarchar(1000)	)

	declare @leId as int
	SET @leId = NULL --( NULL gets all entries in fnGetSensesInEntry$

	INSERT INTO @tblSenses
		SELECT
			EntryId,
			OwnerId,
			SenseId,
			Ord,
			Depth,
			SenseNum
		FROM dbo.fnGetSensesInEntry$(@leId)
	
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	
	-- REVIEW (SteveMiller): MultiTxt$.fmt was always NULL. Don't understand the reason
	-- for them being selected here.
	
	-- Select entry information
	select le.Id, le.Class$, le.HomographNumber,
		isnull(cf.Txt, 'N/F') As CitationForm, 
		cast(null as varbinary) As CitationFormFmt,
		isnull(mfuf.Txt, 'N/F') As UnderlyingForm,
		cast(null as varbinary) As UnderlyingFormFmt,
		isnull(mflf.Txt, 'no form') As LexicalForm,
		cast(null as varbinary) As LexicalFormFmt
	from LexEntry_ le 
	left outer join LexEntry_CitationForm cf  On cf.Obj=le.Id and cf.Ws=@vws
	left outer join LexEntry_UnderlyingForm uf  On uf.Src=le.Id
	left outer join MoForm_Form mfuf  On mfuf.Obj=uf.Dst and mfuf.Ws=@vws
	left outer join LexEntry_Allomorphs a  On a.Src=le.Id
	left outer join MoForm_Form mflf  On mflf.Obj=a.Dst and mflf.Ws=@vws
	where @ldbId=le.Owner$
	order by le.Id
	
	-- REVIEW (SteveMiller): MultiTxt$.fmt was always NULL. Don't understand the reason
	-- for them being selected here.
	
	-- Select sense information in another rowset
	select ls.entryId As EntryId,
		isnull(ls.sensId, 0) As SenseID,
		ls.sensNum As SenseNum,
		isnull(lsg.Txt, 'no gloss') As Gloss, 
		cast(null as varbinary) As GlossFmt,
		isnull(lsd.Txt, 'no def') As Definition,
		cast(null as varbinary) As DefinitionFmt
	from @tblSenses ls 
	left outer join LexSense_Gloss lsg  On lsg.Obj=ls.sensId and lsg.Ws=@aenc
	left outer join LexSense_Definition lsd  On lsd.Obj=ls.sensId and lsd.Ws=@aenc
	order by ls.entryId, ls.sensNum

	return 0
go

if object_id('GetEntryForSense') is not null begin
	drop proc GetEntryForSense
end
print 'creating proc GetEntryForSense'
go










create proc [GetEntryForSense]
	@SenseId as integer
as
	declare @OwnerId int, @OwnFlid int, @ObjId int
	declare @fIsNocountOn int

	set @OwnerId = 0
	if @SenseId < 1 return 1	-- Bad Id

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	set @OwnFlid = 0
	set @ObjId = @SenseId

	-- Loop until we find an owning flid of 5002011 (or null for some ownership error).
	while @OwnFlid != 5002011
	begin
		select 	@OwnerId=isnull(Owner$, 0), @OwnFlid=OwnFlid$
		from	CmObject 
		where	Id=@ObjId

		set @ObjId=@OwnerId
		if @OwnerId = 0
			return 1
	end

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	-- select the sense back to the caller
	select 	@OwnerId LeId
	return 0
go






if object_id('FindOrCreateCmAgent') is not null
	drop proc FindOrCreateCmAgent
go
print 'creating proc FindOrCreateCmAgent'
go
















create proc FindOrCreateCmAgent
	@agentName nvarchar(4000),
	@isHuman bit,
	@version  nvarchar(4000)
as
	DECLARE 
		@retVal INT,
		@fIsNocountOn INT,
		@agentID int

	set @agentID = null

	-- determine if NO COUNT is currently set to ON
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	select @agentID=aa.Id
	from CmAgent_ aa 
	join CmAgent_Name aan  on aan.Obj = aa.Id and aan.Txt=@agentName
	join LanguageProject lp On lp.Id = aa.Owner$
	where aa.Human=@isHuman and aa.Version=@version

	-- Found extant one, so return it.
	if @agentID is not null
	begin
		set @retVal = 0
		goto FinishFinal
	end
	
	--== Need to make a new one ==--
	DECLARE @uid uniqueidentifier,
		@nTrnCnt INT,
		@sTranName VARCHAR(50),
		@wsEN int,
		@lpID int

	-- We don't need to wory about transactions, since the call to CreateObject_CmAgent
	-- wiil create waht is needed, and rool it back, if the creation fails.

	SELECT @wsEN=Obj
	FROM LgWritingSystem_Name 
	WHERE Txt='English'

	SELECT TOP 1 @lpID=ID
	FROM LanguageProject 
	ORDER BY ID

	exec @retVal = CreateObject_CmAgent
		@wsEN, @agentName,
		null,
		@isHuman,
		@version,
		@lpID,
		6001038, -- owning flid for CmAgent in LanguageProject
		null,
		@agentID out,
		@uid out

	if @retVal <> 0
	begin
		-- There was an error in CreateObject_CmAgent
		set @retVal = 1
		GOTO FinishClearID
	end

	SET @retVal = 0
	GOTO FinishFinal
	
FinishClearID:
	set @agentID = 0
	GOTO FinishFinal

FinishFinal:
	if @fIsNocountOn = 0 set nocount off
	select @agentID
	return @retVal

go






if object_id('FindOrCreateWfiAnalysis') is not null
	drop proc FindOrCreateWfiAnalysis
go
print 'creating proc FindOrCreateWfiAnalysis'
go





















create proc FindOrCreateWfiAnalysis
	@WFId int,
	@ntXmlFormMsaPairIds ntext,
	@AnalObjId int output
as
	DECLARE 
		@retVal INT,
		@fIsNocountOn INT,
		@hDoc INT,
		@nPairRowcount INT

	DECLARE @Pair TABLE (MsaId INT, FormId INT, Ord INT)
	DECLARE @PairChk TABLE ([Dummy] BIT)
	
	set @AnalObjId = null

	-- determine if NO COUNT is currently set to ON
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- Process XML inputs.
	exec sp_xml_preparedocument @hDoc output, @ntXmlFormMsaPairIds
	if @@error <> 0 begin
		set @retval = 1
		goto FinishCloseDoc
	end
	
 	INSERT INTO @Pair
		select ol.MsaId, ol.FormId, ol.Ord
		from	openxml(@hDoc, '/root/Pair')
		with ([MsaId] int, [FormId] int, Ord int) as ol
	SET @nPairRowcount = @@ROWCOUNT
	
	-- Do sanity check first. Check for same owner for MoForm and MSA.
	
	-- REVIEW (SteveMiller): As written, the whole procedure fails with
	-- one mismatch. It could be modified to give a list of mismatches.
	
	--( Query logic:
	--(    1. If any rows are returned from the query, we have a problem
	--(       with the data.
	--(    2. A single row is sufficient to throw out data, so we return
	--(       only "TOP 1" from the query.
	--(    3. We don't care what the value of the single-row field is, 
	--(       only that we returned a row, given our criteria.
	--(    4. We want a missing owner to return a row, so we do an outer
	--(       join on CmObject for both the MSA owner and the form owner.
	--(    5. Nulls can't be compared, so null owners are converted to 
	--(       values.
	--(    6. We can't give a null MSA owner and a null Form owner the
	--(       same value, or the query would clear.
	
	INSERT INTO @PairChk
		SELECT TOP 1 0 --( A dummy value for the one & only record
		FROM @Pair p
		LEFT OUTER JOIN CmObject msaowner  ON msaowner.[Id] = p.MsaId
		LEFT OUTER JOIN CmObject formowner  ON formowner.[Id] = p.FormId
		WHERE ISNULL(msaowner.Owner$, -1) != ISNULL(formowner.Owner$, -2)
	
	if @@ROWCOUNT != 0
	begin
		-- They have to be owned by the same object
		set @retVal = 3
		goto FinishCloseDoc
	end
	
	-- See if it already exists.
	IF @nPairRowcount = 0 BEGIN
		-- No substance to analysis, so look for an empty one.
		select top 1 @AnalObjId = wa.Id
		from WfiAnalysis wa 
		left outer join WfiAnalysis_MorphBundles mb  ON mb.Src = wa.Id
		where mb.Dst is null
		order by wa.Id
	end
	else begin
		-- Look for a match with substance.
		select top 1 @AnalObjId = DupChkLst.[ObjId]
		from	(select	WfiAMBS_1.[Src] ObjId, count(*) Cnt
			from	WfiAnalysis_MorphBundles WfiAMBS_1 
				join CmObject CmO  ON WfiAMBS_1.[Src] = CmO.[ID]
					and CmO.[OwnFlid$] = 5062002 -- Analyses FLID in the WfiWordform class
					and CmO.[Owner$] = @WFId
			group by WfiAMBS_1.[Src]
			-- find all analyses that have the same number of Morphs as the new analysis
			having	count(*) = @nPairRowcount
			) DupChkLst
		where	DupChkLst.[Cnt] = (
				-- if the number of matching rows between the new analysis and an existing 
				--	analysis' morphs is the same as the number of rows in the new analysis 
				--	then there is a collision
				select	count(*)
				from	WfiAnalysis_MorphBundles WfiAMBS_2 
				JOIN WfiMorphBundle mb  ON mb.[Id] = WfiAMBS_2.[Dst]
				JOIN @Pair NewWfiAM ON mb.[Morph] = NewWfiAM.[FormId]
					and mb.[msa] = NewWfiAM.[MsaId]
					and WfiAMBS_2.[Ord] = NewWfiAM.[Ord]
					and WfiAMBS_2.[Src] = DupChkLst.[ObjId]
				join CmObject cmoForm 
					On cmoForm.Class$ IN (5027, 5028, 5029, 5045)
						and cmoForm.Id=NewWfiAM.[FormId]
				join CmObject cmoMSA 
					On cmoMSA.Class$ IN (5001, 5031, 5032, 5038)
						and cmoMSA.Id=NewWfiAM.[MsaId]
			)
	end

	-- There was an error in the above check for duplicate WfiAnalyses. Return its retval.
	if @retVal <> 0
	begin
		set @retval = @retval + 100
		goto FinishCloseDoc
	end
	
	-- Turn loose of the handles
	exec sp_xml_removedocument @hDoc
	if @@error <> 0 begin
		set @retval = 4
		goto FinishClearID
	end

	-- Found extant one, so return it. (This is a good thing.)
	if @AnalObjId is not null
	begin
		set @retVal = 0
		goto FinishFinal
	end
	
	--== Need to make a new one ==--
	
	DECLARE @uid uniqueidentifier,
		@nTrnCnt INT,
		@sTranName VARCHAR(50),
		@CurOrd INT,
		@CurFormId INT,
		@CurMsaId INT,
		@CurMBId INT
	
	-- Determine if a transaction already exists.
	-- If one does then create a savepoint, otherwise create a transaction.
	set @nTrnCnt = @@trancount 
	set @sTranName = 'NewWfiAnalysis_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName
	
	-- Create a new WfiAnalysis, and add it to the wordform
	set @uid = null
	exec @retVal = CreateOwnedObject$ 
		5059,
		@AnalObjId output,
		null,
		@WFId,
		5062002,
		25,
		null,
		0,
		1,
		@uid output

	if @retVal <> 0
	begin
		-- There was an error in CreateOwnedObject
		set @retVal = 5
		GOTO FinishRollback
	end
	
	-- Loop through all ids and check on ownership.
	DECLARE @idsCur2 CURSOR,
		@defaultSenseID INT
	set @idsCur2 = CURSOR FAST_FORWARD for
		SELECT MsaId, FormId FROM @Pair
	open @idsCur2
	
	fetch next from @idsCur2 into @CurMsaId, @CurFormId
	while @@fetch_status = 0
	begin
		-- Find default sense
		SELECT TOP 1 @defaultSenseID = senses.[DST]
		FROM LexEntry le 
		JOIN MoMorphoSyntaxAnalysis_ msa 
			ON msa.[Owner$] = le.[ID]
			AND msa.[ID] = @CurMsaId
		JOIN LexEntry_Senses senses 
			ON le.[ID] = senses.[Src]
		ORDER BY senses.[Ord]

		-- Create a new WfiMorphBundle, and add it to the analysis.
		set @uid = null
		set @CurMBId = null
		exec @retVal = CreateOwnedObject$ 
			5112,
			@CurMBId output,
			null,
			@AnalObjId,
			5059011,
			27,
			null,
			0,
			1,
			@uid output

		if @retVal <> 0
		begin
			-- There was an error in CreateOwnedObject
			set @retVal = 6
			close idsCur2
			deallocate idsCur2
			GOTO FinishRollback
		end
		-- Add MoForm, MSA, and default sense.
		UPDATE WfiMorphBundle
		SET Morph = @CurFormId, Msa = @CurMsaId, Sense = @defaultSenseID
		WHERE id = @CurMBId
		if @@error <> 0
		begin
			-- Couldn't update form and msa data.
			close idsCur2
			deallocate idsCur2
			set @retVal = 7
			goto FinishClearID
		end
		fetch next from @idsCur2 into @CurMsaId, @CurFormId
	end
	close @idsCur2
	deallocate @idsCur2
	
	if @nTrnCnt = 0 commit tran @sTranName
	SET @retVal = 0
	GOTO FinishFinal
	
FinishCloseDoc:
	exec sp_xml_removedocument @hDoc
	GOTO FinishClearID

FinishRollback:
	if @nTrnCnt = 0 rollback tran @sTranName
	GOTO FinishClearID
	
FinishClearID:
	set @AnalObjId = null
	GOTO FinishFinal

FinishFinal:
	if @fIsNocountOn = 0 set nocount off
	RETURN @retVal
go

if object_id('CreateParserProblemAnnotation') is not null begin
	print 'removing proc CreateParserProblemAnnotation'
	drop proc CreateParserProblemAnnotation
end
print 'creating proc CreateParserProblemAnnotation'
go
















create proc [CreateParserProblemAnnotation]
	@CompDetails ntext,
	@BeginObject_WordformID int,
	@Source_AgentID int,
	@AnnotationType_AnnDefID int
AS
	DECLARE 
		@retVal INT,
		@fIsNocountOn INT,
		@lpid INT,
		@nTrnCnt INT,
		@sTranName VARCHAR(50),
		@uid uniqueidentifier,
		@annID INT

	-- determine if NO COUNT is currently set to ON
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- @lpid will be the annotation's owner.
	SELECT TOP 1 @lpID=ID
	FROM LanguageProject 
	ORDER BY ID
	
	-- Determine if a transaction already exists.
	-- If one does then create a savepoint, otherwise create a transaction.
	set @nTrnCnt = @@trancount 
	set @sTranName = 'CreateParserProblemAnnotation_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName

	-- Create a new CmBaseAnnotation, and add it to the LanguageProject
	set @uid = null
	exec @retVal = CreateOwnedObject$ 
		37, -- 37
		@annID output,
		null,
		@lpid,
		6001044, -- kflidLanguageProject_Annotations
		25, --25
		null,
		0,
		1,
		@uid output

	if @retVal <> 0
	begin
		-- There was an error in CreateOwnedObject
		set @retVal = 1
		GOTO FinishRollback
	end

	-- Update values.
	UPDATE CmAnnotation
	SET CompDetails=@CompDetails,
		Source=@Source_AgentID,
		AnnotationType=@AnnotationType_AnnDefID
	WHERE ID = @annID
	if @@error <> 0
	begin
		-- Couldn't update CmAnnotation data.
		set @retVal = 2
		goto FinishRollback
	end
	UPDATE CmBaseAnnotation
	SET BeginObject=@BeginObject_WordformID
	WHERE ID = @annID
	if @@error <> 0
	begin
		-- Couldn't update CmBaseAnnotation data.
		set @retVal = 3
		goto FinishRollback
	end

	if @nTrnCnt = 0 commit tran @sTranName
	SET @retVal = 0
	GOTO FinishFinal

FinishRollback:
	if @nTrnCnt = 0 rollback tran @sTranName
	GOTO FinishFinal

FinishFinal:
	if @fIsNocountOn = 0 set nocount off
	return @retval
go


if object_id('SetAgentEval') is not null begin
	print 'removing proc SetAgentEval'
	drop proc SetAgentEval
end
go
print 'creating proc SetAgentEval'
go



























CREATE PROC SetAgentEval
	@nAgentID INT,
	@nTargetID INT, --( A WfiAnalysis.ID or a WfiWordform.ID
	@nAccepted INT,
	@nvcDetails NVARCHAR(4000),
	@dtEval DATETIME
AS
	DECLARE
		@nIsNoCountOn INT,
		@nTranCount INT,
		@sysTranName SYSNAME,
		@nEvals INT,
		@nEvalId INT,
		@nNewObjId INT,
 		@guidNewObj UNIQUEIDENTIFIER,
		@nNewObjTimeStamp INT,
		@nError INT,
		@nvcError NVARCHAR(100)
	
	SET @nError = 0
	
	SET @nIsNoCountOn = @@OPTIONS & 512
	IF @nIsNoCountOn = 0
		SET NOCOUNT ON
	
	--( Take care of transaction stuff	
	SET @nTranCount = @@TRANCOUNT
	SET @sysTranName = 'SetAgentEval_tr' + CONVERT(VARCHAR(2), @@NESTLEVEL)
	IF @nTranCount = 0 
		BEGIN TRAN @sysTranName
	ELSE 
		SAVE TRAN @sysTranName
	
	--( See if we have an Agent Evaluation already
	SELECT TOP 1 @nEvalId = co.[Id]
	FROM CmAgentEvaluation cae 
	JOIN CmObject co  ON co.[Id] = cae.[Id]
		AND co.Owner$ = @nAgentID
	WHERE cae.Target = @nTargetID
	ORDER BY co.[Id]
	
	SET @nEvals = @@ROWCOUNT
	
	--== Remove Eval ==--
	
	--( If we don't know if the analysis is accepted or not,
	--( we don't really have an eval for it. And if we don't
	--( have an eval for it, we need to get rid of it.
	
	IF @nAccepted = 2 OR @nAccepted IS NULL BEGIN
		WHILE @nEvals > 0 BEGIN
			EXEC DeleteObj$ @nEvalId
			
			SELECT TOP 1 @nEvalId = co.[Id]
			FROM CmAgentEvaluation cae 
			JOIN CmObject co  ON co.[Id] = cae.[Id]
				AND co.Owner$ = @nAgentID
			WHERE cae.Target = @nTargetID
				AND co.[Id] > @nEvalId
			ORDER BY co.[Id]
			
			SET @nEvals = @@ROWCOUNT
		END
	END
	
	--== Create or Update Eval ==--
	
	--( Make sure the evaluation is set the way it should be.	
	
	ELSE BEGIN
		
		--( Create a new Agent Evaluation
		IF @nEvals = 0 BEGIN
			
			EXEC @nError = CreateObject_CmAgentEvaluation
				@dtEval,
				@nAccepted,
				@nvcDetails,
				@nAgentId,					--(owner
	 			23006,	--(ownflid  23006
				NULL,						--(startobj
				@nNewObjId OUTPUT,
				@guidNewObj OUTPUT,
				0,			--(ReturnTimeStamp
				@nNewObjTimeStamp OUTPUT
			
			IF @nError != 0 BEGIN
				SET @nvcError = 'SetAgentEval: CreateObject_CmAgentEvaluation failed.'
				GOTO Fail
			END
			
			--( Yes, this seems like a circular reference, making the Target the
			--( same as the owner of the Agent which owns the Agent Evaluation,
			--( but that's the way the model is set up at present.
			
			UPDATE CmAgentEvaluation with (serializable)
			SET Target = @nTargetID
			FROM cmAgentEvaluation cae 
			WHERE cae.[Id] = @nNewObjId
		END
		
		--( Update the existing Agent Evaluation
		ELSE
			
			UPDATE CmAgentEvaluation with (serializable)
			SET
				DateCreated = @dtEval,
				Accepted = @nAccepted,
				Details = @nvcDetails
			FROM CmAgentEvaluation cae 
			JOIN CmObject co  ON co.[Id] = cae.[Id]
				AND co.Owner$ = @nAgentID
			WHERE cae.Target = @nTargetID
		--( END
	END
	GOTO Finish
	
Finish:

	SET @nIsNoCountOn = @@OPTIONS & 512
	IF @nIsNoCountOn = 0
		SET NOCOUNT ON
	
	-- determine if a transaction or savepoint was created
	IF @nTranCount = 0
		COMMIT TRAN @sysTranName
	
	RETURN @nError

Fail:
	RAISERROR (@nvcError, 16, 1, @nError)
	IF @nTranCount !=0
		ROLLBACK TRAN @sysTranName
	
	RETURN @nError

GO

if object_id('UpdWfiAnalysisAndEval$') is not null begin
	print 'removing proc UpdWfiAnalysisAndEval$'
	drop proc [UpdWfiAnalysisAndEval$]
end
go
print 'creating proc UpdWfiAnalysisAndEval$'
go





















-- TODO (SteveMiller/JohnH): -- Needs testing when data becomes available.

CREATE PROC [UpdWfiAnalysisAndEval$]
	@nAgentId INT,
	@nWfiWordFormID INT,
	@ntXmlFormMsaPairIds NTEXT,
	@fAccepted BIT,
	@nvcDetails NVARCHAR(4000),
	@dtEval DATETIME
AS

	DECLARE
		@nIsNoCountOn INT,
		@nTranCount INT,
		@sysTranName SYSNAME,
		@nError INT,
		@nvcError NVARCHAR(100),
		@nAgentEvalId INT,
		@nAnalysisId INT
	
	SET @nIsNoCountOn = @@OPTIONS & 512
	IF @nIsNoCountOn = 0
		SET NOCOUNT ON
	
	SET @nError = 0
	
	--== Find or create the analysis ==--
	
	EXEC @nError = FindOrCreateWfiAnalysis
		@nWfiWordFormID,
		@ntXmlFormMsaPairIds,
		@nAnalysisId OUTPUT
	
	IF @nError != 0 BEGIN
		SET @nvcError = 'UpdWfiAnalysisAndEval$: FindOrCreateWfiAnalysis failed'
		GOTO Fail
	END
	
	--== Update or create the evaluation ==--
	
	EXEC @nError = SetAgentEval
		@nAgentId,
		@nAnalysisID,
		@fAccepted,
		@nvcDetails,
		@dtEval
	
	IF @nError != 0 BEGIN
		SET @nvcError = 'UpdWfiAnalysisAndEval$: SetAgentEval failed'
		GOTO Fail
	END
	
	GOTO Finish
	
Finish:
	IF @nIsNocountOn = 0 SET NOCOUNT OFF
	RETURN @nError
	
Fail:	
	RAISERROR (@nvcError, 16, 1, @nError)
	RETURN @nError

GO

if object_id('RemoveUnusedAnalyses$') is not null begin
	print 'removing proc RemoveUnusedAnalyses$'
	drop proc [RemoveUnusedAnalyses$]
end
go
print 'creating proc RemoveUnusedAnalyses$'
go




















-- TODO (SteveMiller/RandyR): Determine if the orphaned records should really 
--							be deleted by a trigger. 

CREATE PROCEDURE RemoveUnusedAnalyses$
	@nAgentId INT,
	@nWfiWordFormID INT,
	@dtEval DATETIME
AS
	DECLARE
		@nGonnerID INT,
		@nError INT

	SET @nGonnerId = NULL
	SET @nError = 0
	
	--== Delete stale evaluations on analyses ==--
	
	SELECT TOP 1 @nGonnerId = ae.[Id]
	FROM CmAgentEvaluation ae 
	JOIN CmObject objae 
		ON objae.[Id] = ae.[Id] AND objae.Owner$ = @nAgentId
	JOIN CmObject objanalysis 
		ON objanalysis.[Id] = ae.Target
		AND objanalysis.Class$ = 5059 -- WfiAnalysis objects
		AND objanalysis.Owner$ = @nWfiWordFormID
	WHERE ae.DateCreated < @dtEval
	ORDER BY ae.[Id] 
	
	WHILE @@ROWCOUNT != 0 BEGIN
		EXEC @nError = DeleteObj$ @nGonnerId
		
		IF @nError != 0		
			GOTO Finish		
		
		SELECT TOP 1 @nGonnerId = ae.[Id]
		FROM CmAgentEvaluation ae 
		JOIN CmObject objae 
			ON objae.[Id] = ae.[Id] AND objae.Owner$ = @nAgentId
		JOIN CmObject objanalysis 
			ON objanalysis.[Id] = ae.Target
			AND objanalysis.Class$ = 5059 -- WfiAnalysis objects
			AND objanalysis.Owner$ = @nWfiWordFormID
		WHERE ae.[Id] > @nGonnerId AND ae.DateCreated < @dtEval 
		ORDER BY ae.[Id] 	
	END
		
	--== Delete orphan analyses, which have no evaluations ==--
	
	SELECT TOP 1 @nGonnerId = analysis.[Id]
	FROM CmObject analysis 
	LEFT OUTER JOIN cmAgentEvaluation cae 
		ON cae.Target = analysis.[Id]
	WHERE cae.Target IS NULL
		AND analysis.OwnFlid$ = 5062002
		AND analysis.Owner$ = @nWfiWordFormID
	ORDER BY analysis.[Id]
	
	WHILE @@ROWCOUNT != 0 BEGIN
		EXEC @nError = DeleteObj$ @nGonnerId
		
		IF @nError != 0		
			GOTO Finish		
		
		SELECT TOP 1 @nGonnerId = analysis.[Id]
		FROM CmObject analysis 
		LEFT OUTER JOIN cmAgentEvaluation cae 
			ON cae.Target = analysis.[Id]
		WHERE cae.Target IS NULL
			AND analysis.[Id] > @nGonnerId
			AND analysis.OwnFlid$ = 5062002
			AND analysis.Owner$ = @nWfiWordFormID
		ORDER BY analysis.[Id]
	END
	
	GOTO Finish

Finish:
	RETURN @nError

GO














































IF OBJECT_ID('fnGetWordformParses') IS NOT NULL BEGIN
	PRINT 'removing function fnGetWordformParses'
	DROP FUNCTION fnGetWordformParses
END
GO
PRINT 'creating function fnGetWordformParses'
GO

CREATE FUNCTION [fnGetWordformParses] (
	@nAgentId INT,
	@nWritingSystem INT,
	@cParseType CHAR(10))
RETURNS @tblWordFormParses TABLE (
	[Id] INT,
	--( See the notes under string tables in FwCore.sql about the 
	--( COLLATE clause.
	Txt NVARCHAR(4000) COLLATE Latin1_General_BIN)
AS
BEGIN
	
	IF @cParseType = 'All'
		
		--( Including the All query here will make sure this
		--( function is called upon startup, making an execution
		--( plan. It also keeps the SQL code in one spot.
		
		--( This will return all word forms in the list.
		
		INSERT INTO @tblWordFormParses
		SELECT DISTINCT Obj, Txt
		FROM WfiWordform_Form wff 
		ORDER BY Txt
	
	ELSE IF @cParseType = 'Some'
		
		--( wordforms have analyses that have evaluations by the agent
		
		INSERT INTO @tblWordFormParses
		SELECT wff.Obj, wff.Txt
		FROM wfiWordform_Form wff 
		JOIN  WfiWordform_Analyses wa  ON wa.Src = wff.Obj
		JOIN CmAgentEvaluation cae  ON cae.Target = wa.Dst
		JOIN CmObject o  ON o.[Id] = cae.[Id]
			AND o.Owner$ = @nAgentId
		ORDER BY Txt
		
	ELSE IF @cParseType = 'Never' OR @cParseType = 'NeedsEval'
		
		-- REVIEW (SteveMiller): Never is for the nonhuman parser, and 
		-- NeedsEval is for the human agent. Functionally they are the same.
		
		--(	Never:		wordforms have no evals by the agent (parser).
		--(				(error for human)
		--( NeedsEval:	Wordforms have analyses which do not have agent
		--( 			evals (error for nonhuman)
		
		--( John Hatton:
		--( "never parsed" isn't a very good name, is it? The full name 
		--( would be "the Parser has never even been asked to try to 
		--( parsed this word, so we don't know if it parses or not".
		--( Technically, I suppose this means that the parsing agent
		--( has no evaluations at all, whether good or bad, on this 
		--( wordform. It has never seen it.
		
		--( We need two queries in one: we need to return the text of the
		--( wordform(s). We also need to find evaluations only for a particular
		--( agent. Then we find where the wordform text *does not* find an
		--( evaluation from the agent.
		
		INSERT INTO @tblWordFormParses
		SELECT wff.Obj, wff.Txt
		FROM wfiWordform_Form wff 
		JOIN  WfiWordform_Analyses wa  ON wa.Src = wff.Obj
		LEFT OUTER JOIN (
 			--( Subselect: Get the target of all the agent evaluations which
			--( are owned by the agent passed in to this function.			
			SELECT ae.Target
			FROM CmAgentEvaluation ae 
			JOIN CmObject oae  ON oae.[Id] = ae.[Id]
			AND oae.Owner$ = @nAgentId
			) cae ON cae.Target = wa.Dst
		WHERE wff.ws = @nWritingSystem
			--( The wordforms that have nulls in agent evaluation targets
			--( don't have any analyses. These are the wordforms we want.
			AND cae.Target IS NULL
		ORDER BY Txt
		
	RETURN
END
GO

































IF OBJECT_ID('fnGetWordformParses2') IS NOT NULL BEGIN
	PRINT 'removing function fnGetWordformParses2'
	DROP FUNCTION fnGetWordformParses2
END
GO
PRINT 'creating function fnGetWordformParses2'
GO

CREATE FUNCTION [fnGetWordformParses2] (
	@nNonhumanId INT,
	@nHumanId INT,
	@nWritingSystem INT,
	@cParseType CHAR(10))
RETURNS @tblWordFormParses TABLE (
	[Id] INT,
	--( See the notes under string tables in FwCore.sql about the 
	--( COLLATE clause.
	Txt NVARCHAR(4000) COLLATE Latin1_General_BIN)
AS
BEGIN
	
	IF @cParseType = 'Problem' BEGIN
		
		--( This query carries the assumption that no human evaluations matching
		--( accepted nonhuman evaluations will be covered in the 'Missing' node.
		
		INSERT INTO @tblWordFormParses
		SELECT DISTINCT wf.Obj, wf.Txt
		FROM wfiWordform_Form wf 
		JOIN  WfiWordform_Analyses wa  ON wa.Src = wf.Obj
		JOIN CmAgentEvaluation ae_nonhuman  ON ae_nonhuman.Target = wa.Dst
			AND ae_nonhuman.Accepted = 1
		JOIN CmObject aeo_nonhuman  ON aeo_nonhuman.[Id] = ae_nonhuman.[Id]
			AND aeo_nonhuman.Owner$ = @nNonhumanId
		JOIN CmAgentEvaluation ae_human  ON ae_human.Target = wa.Dst
			AND ae_human.Accepted = 0
		JOIN CmObject aeo_human  ON aeo_human.[Id] = ae_human.[Id]
			AND aeo_human.Owner$ = @nHumanId
		WHERE ae_nonhuman.Target = ae_human.Target --( helps performance
		ORDER BY Txt
		
	END
	ELSE BEGIN
		
		--( The Perfect, Missing, and Extra nodes are treated here as
		--( mutually exclusive. That is, the Perfect has the same number
		--( evals between the human and nonhuman. The Missing node has
		--( less human evals than nonhuman, and the Extra node has more
		--( human evals than nonhuman.
				
		-- TODO (SteveMiller): This function was redone when ParseBench
		-- was being phased out and LexText was being phased in. Need to 
		-- see this work with all the pieces put together.
		
		-- REVIEW (SteveMiller): This has the potential of being sped up,
		-- possibly by combining two queries into derived tables.
		
		DECLARE @tblHumanCount TABLE (Obj INT, EvalCount INT)
		DECLARE @tblNonHumanCount TABLE (Obj INT, EvalCount INT)
		
		--( Get the count of evals on each wordform made be the human
			
		INSERT INTO @tblHumanCount
		SELECT wf.Obj, COUNT(ae_Human.[Id])
		FROM wfiWordform_Form wf 
		JOIN  WfiWordform_Analyses wa  ON wa.Src = wf.Obj
		JOIN CmAgentEvaluation ae_Human  ON ae_Human.Target = wa.Dst
		JOIN CmObject aeo_Human  ON aeo_Human.[Id] = ae_Human.[Id]
			AND aeo_Human.Owner$ = @nHumanId
		WHERE wf.ws = @nWritingSystem
		GROUP BY wf.Obj
		
		--( Get the count of evals on each wordform made be the nonhuman
		
		INSERT INTO @tblNonHumanCount
		SELECT wf.Obj, COUNT(ae_NonHuman.[Id])
		FROM wfiWordform_Form wf 
		JOIN  WfiWordform_Analyses wa  ON wa.Src = wf.Obj
		JOIN CmAgentEvaluation ae_NonHuman  ON ae_NonHuman.Target = wa.Dst
		JOIN CmObject aeo_NonHuman  ON aeo_NonHuman.[Id] = ae_NonHuman.[Id]
			AND aeo_NonHuman.Owner$ = @nNonHumanId
		WHERE wf.ws = @nWritingSystem
		GROUP BY wf.Obj
		
		--( See where the human and the nonhuman match/don't match
		
		IF @cParseType = 'Perfect'
			
			-- REVIEW (SteveMiller): Perfect here means that the has
			-- the same number evals by both the human and nonhuman. 
			-- It doesn't take into account whether one is accepted
			-- and the other isn't.
			
			INSERT INTO @tblWordFormParses
			SELECT h.Obj, wf.Txt
			FROM @tblHumanCount h
			JOIN wfiWordform_Form wf  ON wf.Obj = h.Obj
			JOIN @tblNonHumanCount n ON n.Obj = h.Obj
			WHERE  h.EvalCount = n.EvalCount
			ORDER BY wf.Txt
		
		ELSE IF @cParseType = 'Missing'
			
			INSERT INTO @tblWordFormParses
			SELECT n.Obj, wf.Txt
			FROM @tblNonHumanCount n
			JOIN wfiWordform_Form wf  ON wf.Obj = n.Obj
			LEFT OUTER JOIN @tblHumanCount h ON h.Obj = n.Obj
			WHERE n.EvalCount > COALESCE(h.EvalCount, 0)
			ORDER BY wf.Txt
					
		ELSE IF @cParseType = 'Extra'
					
			INSERT INTO @tblWordFormParses
			SELECT h.Obj, wf.Txt
			FROM @tblHumanCount h
			JOIN wfiWordform_Form wf  ON wf.Obj = h.Obj
			LEFT OUTER JOIN @tblNonHumanCount n ON n.Obj = h.Obj
			WHERE h.EvalCount > COALESCE(n.EvalCount, 0)
			ORDER BY wf.Txt
			
		--( END
	END
	RETURN
END
GO


























if object_id('fnGetParseCountRange') is not null begin
	print 'removing function fnGetParseCountRange'
	drop function [fnGetParseCountRange]
end
go
print 'creating function fnGetParseCountRange'
go

CREATE FUNCTION [fnGetParseCountRange] (
	@nAgentId INT,
	@nWritingSystem INT,
	@nAccepted BIT,
	@nRangeMin INT,
	@nRangeMax INT)
RETURNS @tblWfiWordFormsCount TABLE (
	[Id] INT,
	--( See the notes under string tables in FwCore.sql about the 
	--( COLLATE clause.
	Txt NVARCHAR(4000) COLLATE Latin1_General_BIN,
	EvalCount INT)
AS
BEGIN
	
	--( See Class Diagram CmAgent in the doc.
	--(-------------------------------------------
	--( CmAgentEvaluation.Target -->
	--(		CmObject --( subclassed as )-->
	--(		WfiWordForm or WfiAnalysis
	--(
	--(	WfiWordForm.Analyses -->
	--(		WfiAnalysis
	--(-------------------------------------------
	--( The Target of CmAgentEvaluation may either
	--( be a WfiWordForm, or a WfiAnalysis owned
	--( by a WfiWordForm. We want the latter.
	
	IF @nRangeMax != 0 BEGIN
		
		IF @nAccepted IS NULL 
		
		 	INSERT INTO @tblWfiWordFormsCount
			SELECT wordformform.[Obj], wordformform.Txt, COUNT(wordformform.[Obj]) AS EvalCount
			FROM CmAgentEvaluation agenteval 
			JOIN CmObject oagenteval  ON oagenteval.[Id] = agenteval.[Id]
				AND oagenteval.[Owner$] = @nAgentId
			--( Don't need to join WfiAnalysis or WfiAnalysis_ here
			JOIN CmObject oanalysis  ON oanalysis.[Id] = agenteval.[Target]
			JOIN WfiWordForm_Form wordformform  ON wordformform.Obj = oanalysis.[Owner$]
				AND wordformform.ws = @nWritingSystem --( WfiWordForm_Form is actually MultiTxt$ with flid
			GROUP BY wordformform.[Obj], wordformform.Txt
			HAVING COUNT(wordformform.[Obj]) BETWEEN @nRangeMin AND @nRangeMax
			ORDER BY wordformform.Txt
			
		ELSE
			
		 	INSERT INTO @tblWfiWordFormsCount
			SELECT wordformform.[Obj], wordformform.Txt, COUNT(wordformform.[Obj]) AS EvalCount
			FROM CmAgentEvaluation agenteval 
			JOIN CmObject oagenteval  ON oagenteval.[Id] = agenteval.[Id]
				AND oagenteval.[Owner$] = @nAgentId
			--( Don't need to join WfiAnalysis or WfiAnalysis_ here
			JOIN CmObject oanalysis  ON oanalysis.[Id] = agenteval.[Target]
			JOIN WfiWordForm_Form wordformform  ON wordformform.Obj = oanalysis.[Owner$]
				AND wordformform.ws = @nWritingSystem --( WfiWordForm_Form is actually MultiTxt$ with flid
			WHERE agenteval.accepted = @nAccepted
			GROUP BY wordformform.[Obj], wordformform.Txt
			HAVING COUNT(wordformform.[Obj]) BETWEEN @nRangeMin AND @nRangeMax
			ORDER BY wordformform.Txt
			
	END
	ELSE --( IF @nRangeMax = 0
		
		--( 0 Parses:	wordform has an evaluation, but analyses--if
		--(				any--don't have evaluations
		
		--( Randy Regnier:
		--( I think it will have an evaluation, but for cases where the 
		--( parser couldn't come up with any parses at all, I add a CmBaseAnnotation, 
		--( and set its InstanceOfRAHvo and BeginObjectRAHvo to the HVO of the wordform.
		--( The CompDetails of the annotation will say "Analysis Failure".
		--( <snip>
		--( John Thomson: Which 'it' will have an evaluation?
		--( <snip>
		--( RR: We add evaluations to both the wordform and any parses retruned by the 
		--( parser. In the case of no parses being returned, we jsut add an evaluation
		--( top the wordform, along with the annotation.
				
	 	INSERT INTO @tblWfiWordFormsCount
		SELECT wordformform.[Obj], wordformform.Txt, 0 AS EvalCount
		FROM WfiWordForm_Form wordformform  
		JOIN CmAgentEvaluation agenteval ON agenteval.Target = wordformform.Obj
		JOIN CmObject oagenteval  ON oagenteval.[Id] = agenteval.[Id]
			AND oagenteval.[Owner$] = @nAgentId
		LEFT OUTER JOIN CmObject oAnalysis ON oAnalysis.Owner$ = wordformform.Obj
		LEFT OUTER JOIN CmAgentEvaluation aneval ON aneval.Target = oanalysis.[Id]
		WHERE aneval.Target IS NULL
				
	RETURN
END
GO
































IF OBJECT_ID('IsAgentAgreement$') IS NOT NULL BEGIN
	PRINT 'removing procedure IsAgentAgreement$'
	DROP PROCEDURE IsAgentAgreement$
END
GO
PRINT 'creating procedure IsAgentAgreement$'
GO

CREATE PROCEDURE [IsAgentAgreement$] (
	@nWfiWordFormId INT,
	@nAgentId1 INT,
	@nAgentId2 INT,
	@fAgreement BIT OUTPUT)
AS
BEGIN
	
	DECLARE @tblAgentEvals1 TABLE ([Id] INT, Target INT, [Accepted] BIT)
	DECLARE @tblAgentEvals2 TABLE ([Id] INT, Target INT, [Accepted] BIT)
	
	DECLARE
		@nCount1 INT,
		@nCount2 INT
	
	SET @fAgreement = 1
	
	INSERT INTO @tblAgentEvals1
	SELECT ae.[Id], ae.Target, ae.[Accepted]
	FROM CmAgentEvaluation ae 
	JOIN CmObject oAgentEval  ON oAgentEval.[Id] = ae.[Id]
		AND oAgentEval.Owner$ = @nAgentId1
	JOIN CmObject oWordAnal  ON oWordAnal.[Id] = ae.Target
		AND oWordAnal.Owner$ = @nWfiWordFormId
	
	INSERT INTO @tblAgentEvals2
	SELECT ae.[Id], ae.Target, ae.[Accepted]
	FROM CmAgentEvaluation ae 
	JOIN CmObject oAgentEval  ON oAgentEval.[Id] = ae.[Id]
		AND oAgentEval.Owner$ = @nAgentId2
	JOIN CmObject oWordAnal  ON oWordAnal.[Id] = ae.Target
		AND oWordAnal.Owner$ = @nWfiWordFormId
	
	--( Make sure all are accepted
		
 	SELECT @nCount1 = COUNT(*) FROM @tblAgentEvals1 WHERE [Accepted] = 0
	SELECT @nCount2 = COUNT(*) FROM @tblAgentEvals2 WHERE [Accepted] = 0
	
	IF @nCount1 + @nCount2 > 0
		SET @fAgreement = 0
		
	--( All evaluations are marked accepted. Make sure the analyses
	--( from the two different agents line up
		
	ELSE BEGIN
		SET @nCount1 = 0
		
		SELECT @nCount1 = COUNT(*)
		FROM @tblAgentEvals1 a1
		RIGHT OUTER JOIN @tblAgentEvals2 a2 ON a2.Target = a1.Target
		WHERE a1.[Id] IS NULL
		
		IF @nCount1 > 0
			SET @fAgreement = 0

		ELSE BEGIN
			SET @nCount1 = 0
			
			SELECT @nCount1 = COUNT(*)
			FROM @tblAgentEvals2 a2
			RIGHT OUTER JOIN @tblAgentEvals1 a1 ON a1.Target = a2.Target
			WHERE a2.[Id] IS NULL

			IF @nCount1 > 0
				SET @fAgreement = 0
		END
	END
	
	RETURN @fAgreement
END
GO


















IF OBJECT_ID('fnGetDefaultAnalysisGloss') IS NOT NULL BEGIN
	PRINT 'removing procedure fnGetDefaultAnalysisGloss'
	DROP FUNCTION fnGetDefaultAnalysisGloss
END
GO
PRINT 'creating function fnGetDefaultAnalysisGloss'
GO

CREATE FUNCTION fnGetDefaultAnalysisGloss (
	@nWfiWordFormId INT)
RETURNS @tblScore TABLE (
	AnalysisId INT,
	GlossId INT,
	[Score] INT)
AS BEGIN
	
	INSERT INTO @tblScore
		--( wfiGloss is an InstanceOf
		SELECT
			oanalysis.[Id],
			ogloss.[Id],
			(COUNT(ann.InstanceOf) + 10000) --( needs higher # than wfiAnalsys
		FROM CmAnnotation ann 
		JOIN WfiGloss g   ON g.[Id] = ann.InstanceOf
		JOIN CmObject ogloss  ON ogloss.[Id] = g.[Id]
		JOIN CmObject oanalysis  ON oanalysis.[Id] = ogloss.Owner$
			AND oanalysis.Owner$ = @nWfiWordFormId
		JOIN WfiAnalysis a  ON a.[Id] = oanalysis.[Id]
		GROUP BY oanalysis.[Id], ogloss.[Id]
	UNION ALL
		--( wfiAnnotation is an InstanceOf
		SELECT
			oanalysis.[Id],
			NULL,
			COUNT(ann.InstanceOf)
		FROM CmAnnotation ann 
		JOIN CmObject oanalysis  ON oanalysis.[Id] = ann.InstanceOf
			AND oanalysis.Owner$ = @nWfiWordFormId
		JOIN WfiAnalysis a  ON a.[Id] = oanalysis.[Id]
		GROUP BY oanalysis.[Id]
		
	--( If the gloss and analysis ID are all null, there
	--( are no annotations, but an analysis still might exist.
	
	IF @@ROWCOUNT = 0
		
		INSERT INTO @tblScore
		SELECT TOP 1 
			oanalysis.[Id],
			NULL,
			0
		FROM CmObject oanalysis 
		WHERE oanalysis.Owner$ = @nWfiWordFormId
	
	RETURN
END
GO













































IF OBJECT_ID('fnGetDefaultAnalysesGlosses') IS NOT NULL BEGIN
	PRINT 'removing procedure fnGetDefaultAnalysesGlosses'
	DROP FUNCTION fnGetDefaultAnalysesGlosses
END
GO
PRINT 'creating function fnGetDefaultAnalysesGlosses'
GO

CREATE FUNCTION fnGetDefaultAnalysesGlosses (
	@nStTxtParaId INT)
RETURNS @tblDefaultAnalysesGlosses TABLE (
	WordformId INT,
	AnalysisId INT,
	GlossId INT,
	BaseAnnotationId INT,
	InstanceOf INT,
	BeginOffset INT,
	EndOffset INT)
AS BEGIN
	
	DECLARE
		@nWordformId INT,
		@nAnalysisId INT,
		@nGlossId INT
	
	--==( Get Most Data )==--
	
	--( This query is a union of three queries:
	--(
	--( 	1. WfiGloss owned by WfiAnalysis, owned by WfiWordform
	--(		2. WfiAnalysis owned by wfiWordform, and default gloss
	--(		3. WfiWordform default analysis and gloss.
	--(
	--( A couple of these pieces can't be picked up in one query, and 
	--( will be retrieved next.
	
	--( wfiGloss is an InstanceOf
	INSERT INTO @tblDefaultAnalysesGlosses
	SELECT 
		wf.[Id] AS WordformId,
		wa.[Id] AS AnalysisId,
		wg.[Id] AS GlossId,
		ba.[Id] AS BaseAnnotationId,
		a.InstanceOf,
		ba.BeginOffset,
		ba.EndOffset
	FROM CmBaseAnnotation ba 
	JOIN CmAnnotation a ON a.[Id] = ba.[Id]
	JOIN StTxtPara tp ON tp.[Id] = ba.BeginObject
	JOIN WfiGloss wg ON wg.[Id] = a.InstanceOf
	JOIN CmObject wgobj ON wgobj.[Id] = wg.[Id]
	JOIN WfiAnalysis wa ON wa.[Id] = wgobj.Owner$
	JOIN CmObject waobj ON waobj.[Id] = wa.[Id]
	JOIN WfiWordform wf ON wf.[Id] = waobj.Owner$
	WHERE ba.BeginObject = @nStTxtParaId
	UNION ALL
	--( wfiAnalysis is an InstanceOf
	SELECT 
		wf.[Id] AS WordformId,
		wa.[Id] AS AnalysisId,
		NULL AS GlossId,
		ba.[Id] AS BaseAnnotationId,
		a.InstanceOf,
		ba.BeginOffset,
		ba.EndOffset
	FROM CmBaseAnnotation ba 
	JOIN CmAnnotation a ON a.[Id] = ba.[Id]
	JOIN StTxtPara tp ON tp.[Id] = ba.BeginObject
	JOIN WfiAnalysis wa ON wa.[Id] = a.InstanceOf
	JOIN CmObject waobj ON waobj.[Id] = wa.[Id]
	JOIN WfiWordform wf ON wf.[Id] = waobj.Owner$
	WHERE ba.BeginObject = @nStTxtParaId
	UNION ALL
	--( wfiWordform is an InstanceOf
	SELECT 
		wf.[Id] AS WordformId,
		NULL AS AnalysisId,
		NULL AS GlossId,
		ba.[Id] AS BaseAnnotationId,
		a.InstanceOf,
		ba.BeginOffset,
		ba.EndOffset
	FROM CmBaseAnnotation ba 
	JOIN CmAnnotation a ON a.[Id] = ba.[Id]
	JOIN StTxtPara tp ON tp.[Id] = ba.BeginObject
	JOIN WfiWordform wf ON wf.[Id] = a.InstanceOf
	WHERE ba.BeginObject = @nStTxtParaId
	
	--( Default analyses and glosses:
	--(
	--( This function is supposed to get a default analysis
	--( and default gloss for the current wordform only if
	--( the current analysis is incomplete. In other words,
	--( If the user has specified the gloss already, use
	--( that.
	
	--==( Get Default analysis and gloss for wordforms )==--

	SET @nWordformId = NULL
	
	SELECT TOP 1 @nWordformId = WordformId
	FROM @tblDefaultAnalysesGlosses
	WHERE GlossId IS NULL AND AnalysisId IS NULL
	ORDER BY WordformId
	
	WHILE @nWordformId IS NOT NULL BEGIN
		-- this query could return no rows, in which case, it doesn't modify
		-- the variables. If we get no rows we don't want to set a value.
		set @nAnalysisId = NULL
		set @nGlossId = NULL
		SELECT TOP 1 @nAnalysisId = AnalysisId, @nGlossId = GlossId 
		FROM dbo.fnGetDefaultAnalysisGloss(@nWordformId)
		ORDER BY Score DESC
		
		UPDATE @tblDefaultAnalysesGlosses SET GlossId = @nGlossId, AnalysisId = @nAnalysisId
		WHERE WordformId = @nWordformId AND GlossId IS NULL AND AnalysisId IS NULL
		
		DECLARE @WfIdOld int
		SET @WfIdOld = @nWordformId
		SET @nWordformId = NULL
		
		SELECT TOP 1 @nWordformId = WordformId
		FROM @tblDefaultAnalysesGlosses
		WHERE GlossId IS NULL AND AnalysisId IS NULL
			AND WordformId > @WfIdOld
		ORDER BY WordformId	
	END
	
	--==( Get Default gloss for analysis)==--
	
	SET @nWordformId = NULL
	
	SELECT TOP 1 @nWordformId = WordformId
	FROM @tblDefaultAnalysesGlosses
	WHERE GlossId IS NULL AND AnalysisId IS NOT NULL
	ORDER BY WordformId
	
	WHILE @nWordformId IS NOT NULL BEGIN
		set @nGlossId = NULL
		SELECT TOP 1 @nGlossId = GlossId 
		FROM dbo.fnGetDefaultAnalysisGloss(@nWordformId)
		ORDER BY Score DESC
		
		UPDATE @tblDefaultAnalysesGlosses SET GlossId = @nGlossId
		WHERE WordformId = @nWordformId AND GlossId IS NULL
			AND AnalysisId IS NOT NULL
		
		SET @WfIdOld = @nWordformId
		SET @nWordformId = NULL
		
	
		SELECT TOP 1 @nWordformId = WordformId
		FROM @tblDefaultAnalysesGlosses
		WHERE GlossId IS NULL AND AnalysisId IS NOT NULL
			AND WordformId > @WfIdOld
		ORDER BY WordformId	
	END

	-- Now add the punctuation annotations, identified by (a) pointing at this
	-- paragraph, and (b) having a type which is an annotation defn with the right GUID.
	INSERT INTO @tblDefaultAnalysesGlosses
	SELECT 
		NULL AS WordformId,
		NULL AS AnalysisId,
		NULL AS GlossId,
		ba.[Id] AS BaseAnnotationId,
		NULL,
		ba.BeginOffset,
		ba.EndOffset
	FROM CmBaseAnnotation ba
	join CmAnnotation ca on ba.id = ca.id
	join CmObject andefn on ca.AnnotationType = andefn.id AND ba.BeginObject = @nStTxtParaId
		AND andefn.Guid$ = 'CFECB1FE-037A-452D-A35B-59E06D15F4DF'

	RETURN
END
GO







-- First, delete them all, if they exist.
if exists (select * from sysobjects where name = 'PATRString_FsFeatureStructure')
	drop proc PATRString_FsFeatureStructure
go
if exists (select * from sysobjects where name = 'PATRString_FsAbstractStructure')
	drop proc PATRString_FsAbstractStructure
go
if exists (select * from sysobjects where name = 'PATRString_FsFeatureSpecification')
	drop proc PATRString_FsFeatureSpecification
go
-- Create to 'empty' SPs.
print 'creating proc PATRString_FsFeatureSpecification'
go
create proc PATRString_FsFeatureSpecification
	@Def nvarchar(1),
	@Id int,
	@PATRString nvarchar(4000) output
as
	return 1
go
print 'creating proc PATRString_FsAbstractStructure'
go
create proc PATRString_FsAbstractStructure
	@Def nvarchar(1),
	@Id int,
	@PATRString nvarchar(4000) output
as
	return 1
go


-- Create real top-level SPs.
print 'altering proc PATRString_FsAbstractStructure'
go












alter proc PATRString_FsAbstractStructure
	@Def nvarchar(1),
	@Id int,
	@PATRString nvarchar(4000) output
as
	declare @fIsNocountOn int, @retval int,
		@fNeedSpace bit, @CurDstId int,
		@Txt NVARCHAR(4000),
		@Class int,
		@fNeedSlash bit

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- Get class info.
	select @Class = Class$
	from CmObject 
	where Id = @Id

	if @Class = 2009 begin	-- FsFeatureStructure
		set @PATRString = '['

		-- Handle disjunctions, if any
		select top 1 @CurDstId = Dst
		from FsFeatureStructure_FeatureDisjunctions 
		where Src = @Id
		order by Dst
		while @@rowcount > 0 begin
			exec @retval = PATRString_FsAbstractStructure @Def, @CurDstId, @Txt output
			if @retval != 0 begin
				set @PATRString = '[]'
				goto LFail
			end
			set @PATRString = @PATRString + @Txt
			-- Try getting another one
			select top 1 @CurDstId = Dst
			from FsFeatureStructure_FeatureDisjunctions 
			where Src = @Id and Dst > @CurDstId
			order by Dst
		end

		-- Handle FeatureSpecs, if any
		set @fNeedSpace = 0
		select top 1 @CurDstId = Dst
		from FsFeatureStructure_FeatureSpecs 
		where Src = @Id
		order by Dst
		while @@rowcount > 0 begin
			exec @retval = PATRString_FsFeatureSpecification @Def, @CurDstId, @Txt output
			if @retval != 0 begin
				set @PATRString = '[]'
				goto LFail
			end
			if @fNeedSpace = 1 set @PATRString = @PATRString + ' '
			else set @fNeedSpace = 1
			set @PATRString = @PATRString + @Txt
			-- Try getting another one
			select top 1 @CurDstId = Dst
			from FsFeatureStructure_FeatureSpecs 
			where Src = @Id and Dst > @CurDstId
			order by Dst
		end

		set @PATRString = @PATRString + ']'
	end
	else if @Class = 2010 begin	-- FsFeatureStructureDisjunction
		set @PATRString = '{'
		-- Handle contents, if any
		set @fNeedSlash = 0
		select top 1 @CurDstId = Dst
		from FsFeatureStructureDisjunction_Contents 
		where Src = @Id
		order by Dst
		while @@rowcount > 0 begin
			exec @retval = PATRString_FsAbstractStructure @Def, @CurDstId, @Txt output
			if @retval != 0 begin
				set @PATRString = ''
				goto LFail
			end
			if @fNeedSlash = 1 set @PATRString = @PATRString + ' '
			else set @fNeedSlash = 1
			set @PATRString = @PATRString + @Txt
			-- Try getting another one
			select top 1 @CurDstId = Dst
			from FsFeatureStructureDisjunction_Contents 
			where Src = @Id and Dst > @CurDstId
			order by Dst
		end
		set @PATRString = @PATRString + '}'
	end
	else begin	-- unknown class.
		set @retval = 1
		set @PATRString = '[]'
		goto LFail
	end
	set @retval = 0
LFail:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @retval
go


print 'altering proc PATRString_FsFeatureSpecification'
go













alter proc PATRString_FsFeatureSpecification
	@Def nvarchar(1),
	@Id int,
	@PATRString nvarchar(4000) output
as
	declare @fIsNocountOn int, @retval int,
		@tCount int, @cCur int, @CurId int,
		@CurDstId int, @Class int,
		@ValueId int, @ValueClass int, @FDID int,
		@Label nvarchar(4000), @Value nvarchar(4000)

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- Get name of FsFeatureDefn.
	-- If there is no name or FsFeatureDefn, then quit.
	-- We don't care which writing system is used.
	select top 1 @Label = fdn.Txt, @FDID = fd.Id
	from FsFeatureSpecification fs 
	join FsFeatureDefn fd  On fs.Feature = fd.Id
	join FsFeatureDefn_Name fdn  On fd.Id = fdn.Obj
	where fs.Id = @Id
	order by Ws
	-- Check for null value in @PATRString
	if @Label is null begin
		set @PATRString = ''
		set @retval = 1
		goto LFail
	end

	-- Handle various values in subclasses of FsFeatureSpecification
	select @Class = Class$
	from CmObject 
	where Id = @Id
	if @Class = 2003 begin	-- FsClosedValue
		select top 1 @Value = Txt
		from FsClosedValue cv 
		join FsSymbolicFeatureValue sfv  On cv.Value = sfv.Id
		join FsSymbolicFeatureValue_Name sfvn  On sfvn.Obj = sfv.Id
		where cv.Id = @Id
		if @Value is null begin
			-- Try default value.
			select @FDID=Dst
			from FsFeatureDefn_Default 
			where Src=@FDID
			exec @retval = PATRString_FsFeatureSpecification '!', @FDID, @Value output
			if @retval != 0 begin
				set @PATRString = ''
				set @retval = 1
				goto LFail
			end
			set @PATRString = @Value
		end
		else set @PATRString = @Label + ':' + @Def + @Value
	end
	else if @Class = 2006 begin	-- FsDisjunctiveValue
		set @PATRString = @Label + ':{'
		set @tCount = 0
		select top 1 @CurDstId = Dst
		from FsDisjunctiveValue_Value 
		where Src = @Id
		order by Dst
		set @Value = ''
		while @@rowcount > 0 begin
			if @tCount > 0 set @PATRString = @PATRString + ' '
			if @Def = '!' set @PATRString = @PATRString + '!'
			set @tCount = 1
			select top 1 @Value = Txt
			from FsSymbolicFeatureValue sfv 
			join FsSymbolicFeatureValue_Name sfvn  On sfvn.Obj = sfv.Id
			where sfv.Id = @CurDstId
			if @Value is null begin
				-- Try default value.
				select @FDID=Dst
				from FsFeatureDefn_Default 
				where Src=@FDID
				exec @retval = PATRString_FsFeatureSpecification '!', @FDID, @Value output
				if @retval != 0 begin
					set @PATRString = ''
					set @retval = 1
					goto LFail
				end
				set @PATRString = @PATRString + @Value
			end
			else set @PATRString = @PATRString + @Value
			-- Try getting another one
			select top 1 @CurDstId = Dst
			from FsDisjunctiveValue_Value 
			where Src = @Id and Dst > @CurDstId
			order by Dst
		end
		set @PATRString = @PATRString + '}'
	end
	else if @Class = 2013 begin	-- FsNegatedValue
		select top 1 @Value = Txt
		from FsNegatedValue nv 
		join FsSymbolicFeatureValue sfv  On nv.Value = sfv.Id
		join FsSymbolicFeatureValue_Name sfvn  On sfvn.Obj = sfv.Id
		where nv.Id = @Id
		if @Value is null begin
print 'Trying default for FsNegatedValue'
			-- Try default value.
			select @FDID=Dst
			from FsFeatureDefn_Default 
			where Src=@FDID
			exec @retval = PATRString_FsFeatureSpecification '!', @FDID, @Value output
			if @retval != 0 begin
				set @PATRString = ''
				set @retval = 1
				goto LFail
			end
			set @PATRString = @Value
		end
		else set @PATRString = @Label + ':~' + @Def + @Value
	end
	else if @Class = 2005 begin	-- FsComplexValue
		-- Need to get class of Value, so we call the right SP.
		select @ValueClass = cmo.Class$, @ValueId = cmo.Id
		from FsComplexValue_Value cvv 
		join CmObject cmo  On cvv.Dst = cmo.Id
		where cvv.Src = @Id
		if @ValueClass is null or @ValueId is null begin
			declare @cmpxFS int, @cmpxValId int
			-- Try default value.
			select @cmpxFS=Dst
			from FsFeatureDefn_Default 
			where Src=@FDID
			if @cmpxFS is null begin
				set @PATRString = ''
				set @retval = 1
				goto LFail
			end
			select @cmpxValId=Dst
			from FsComplexValue_Value 
			where Src=@cmpxFS
			if @cmpxValId is null begin
				set @PATRString = ''
				set @retval = 1
				goto LFail
			end
			exec @retval = PATRString_FsAbstractStructure '!', @cmpxValId, @Value output
			if @retval != 0 begin
				set @PATRString = ''
				set @retval = 1
				goto LFail
			end
			set @PATRString = @Value
		end
		else if @ValueClass = 2009 or @ValueClass = 2010 begin
			-- FsFeatureStructure or FsFeatureDisjunction
			exec @retval = PATRString_FsAbstractStructure @Def, @ValueId, @Value output
			if @retval != 0 begin
				set @PATRString = ''
				set @retval = 1
				goto LFail
			end
			set @PATRString = @Label + ':' + @Def + @Value
		end
		else begin	-- Bad class.
			set @PATRString = ''
			set @retval = 1
			goto LFail
		end
		set @PATRString = @Label + ':' + @Value
	end
	else if @Class = 2015 begin	-- FsOpenValue
		-- We don't care which writing system is used.
		select top 1 @Value = Txt
		from FsOpenValue_Value 
		where Obj=@Id
		order by Ws
		if @Value is null begin
			set @PATRString = ''
			set @retval = 1
			goto LFail
		end
		set @PATRString = @Label + ':' + @Value
	end
	else if @Class = 2016 begin	-- FsSharedValue
		-- We don't do FsSharedValue at the moment.
		set @PATRString = ''
		set @retval = 1
		goto LFail
	end
	else begin
		-- Unknown class
		set @PATRString = ''
		set @retval = 1
		goto LFail
	end

	set @retval = 0
LFail:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @retval
go


print 'creating proc PATRString_FsFeatureStructure'
go















create proc PATRString_FsFeatureStructure
	@XMLOut bit = 0,
	@XMLIds ntext = null
as
	declare @retval int,
		@CurId int, @Txt nvarchar(4000),
		@fIsNocountOn int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	--Table variable.
	declare @FS table (
		Id int,
		PATRTxt nvarchar(4000) )

	if @XMLIds is null begin
		-- Do all feature structures.
		insert into @FS (Id, PATRTxt)
			select	Id, '[]'
			from	FsFeatureStructure_ 
			where OwnFlid$ != 2005001 -- Owned by FsComplexValue 
				and OwnFlid$ != 2010001 -- Owned by FsFeatureStructureDisjunction
	end
	else begin
		-- Do feature structures provided in xml string.
		declare @hdoc int
		exec sp_xml_preparedocument @hdoc output, @XMLIds
		if @@error <> 0 begin
			set @retval = 1
			goto LExit
		end
		insert into @FS (Id, PATRTxt)
			select	ol.[Id], '[]'
			from	openxml(@hdoc, '/FeatureStructures/FeatureStructure')
			with ([Id] int) as ol
			-- Remove all pretenders, since they won't 'join'.
			join CmObject cmo 
				On ol.Id=cmo.Id
				and cmo.Class$=2009 -- Check for class being FsFeatureStructure
				and cmo.OwnFlid$ != 2005001 -- Owned by FsComplexValue
				and cmo.OwnFlid$ != 2010001 -- Owned by FsFeatureStructureDisjunction
		-- Turn loose of the handle
		exec sp_xml_removedocument @hdoc
		if @@error <> 0 begin
			set @retval = 1
			goto LExit
		end
	end

	-- Loop through all ids.
	select top 1 @CurId = Id
	from @FS
	order by Id
	while @@rowcount > 0 begin
		-- Call PATRString_FsAbstractStructure for each ID. It will return the PATR string.
		exec @retval = PATRString_FsAbstractStructure '', @CurId, @Txt output
		-- Note: If @retval is not 0, then we already are set to use '[]'
		-- for the string, so nothing mnore need be done.
		if @retval = 0 begin
			update @FS
			Set PATRTxt = @Txt
			where Id = @CurId
		end
		-- Try for another one.
		select top 1 @CurId = Id
		from @FS
		where Id > @CurId
		order by Id
	end

	if @XMLOut = 0
		select * from @FS
	else
		select * from @FS for xml auto
	set @retval = 0
LExit:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @retval
go





if object_id('DisplayName_PhPhonologicalContextID') is not null begin
	drop proc DisplayName_PhPhonologicalContextID
end
go
print 'creating proc DisplayName_PhPhonologicalContextID'
go
create proc DisplayName_PhPhonologicalContextID
	@ContextId int,
	@ContextString nvarchar(4000) output
as
	return 0
go
print 'altering proc DisplayName_PhPhonologicalContextID'
go











alter proc DisplayName_PhPhonologicalContextID
	@ContextId int,
	@ContextString nvarchar(4000) output
as
	declare @retval int,
		@CurId int, @Txt nvarchar(4000),
		@class int,
		@CurSeqId int, @SeqTxt nvarchar(4000), @wantSpace bit, @CurOrd int,
		@fIsNocountOn int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	set @ContextString = ''

	-- Check for legal class.
	select @CurId = isnull(Id, 0)
	from CmObject cmo 
	where cmo.Id = @ContextId
		 -- Check for class being a subclass of PhPhonologicalContext
		and cmo.Class$ IN (5082, 5083, 5085, 5086, 5087)

	if @CurId > 0 begin
		select @class = Class$
		from CmObject 
		where Id = @CurId

		-- Deal with subclass specific contexts.
		if @class = 5082 begin	-- PhIterationContext
			select @CurSeqId = isnull(Member, 0)
			from PhIterationContext mem 
			where mem.Id = @ContextId
			if @CurSeqId = 0 begin
				set @ContextString = '(***)'
				set @retval = 1
				goto LExit
			end
			exec @retval = DisplayName_PhPhonologicalContextID @CurSeqId, @Txt output
			if @retval != 0 begin
				set @ContextString = '(***)'
				goto LExit
			end
			set @ContextString = '(' + @Txt + ')'
		end
		else if @class = 5083 begin	-- PhSequenceContext
			set @wantSpace = 0
			select top 1 @CurSeqId = Dst, @CurOrd = mem.ord
			from PhSequenceContext_Members mem 
			where mem.Src = @ContextId
			order by mem.Ord
			while @@rowcount > 0 begin
				set @SeqTxt = '***'
				exec @retval = DisplayName_PhPhonologicalContextID @CurSeqId, @SeqTxt output
				if @retval != 0 begin
					set @ContextString = '***'
					goto LExit
				end
				if @wantSpace = 1
					set @ContextString = @ContextString + ' '
				set @wantSpace = 1
				set @ContextString = @ContextString + @SeqTxt
				-- Try to get next one
				select top 1 @CurSeqId = Dst, @CurOrd = mem.ord
				from PhSequenceContext_Members mem 
				where mem.Src = @ContextId and mem.Ord > @CurOrd
				order by mem.Ord
			end
			--set @ContextString = 'PhSequenceContext'
		end
		else if @class = 5085 begin	-- PhSimpleContextBdry
			select top 1 @Txt = isnull(nm.Txt, '***')
			from PhSimpleContextBdry ctx 
			join PhTerminalUnit tu  On tu.Id = ctx.FeatureStructure
			join PhTerminalUnit_Codes cds  On cds.Src = tu.Id
			join PhCode_Representation nm  On nm.Obj = cds.Dst
			where ctx.Id = @CurId
			order by cds.Ord, nm.Ws
			set @ContextString = @Txt
		end
		else if @class = 5086 begin	-- PhSimpleContextNC
			select top 1 @Txt = isnull(nm.Txt, '***')
			from PhSimpleContextNC ctx 
			join PhNaturalClass_Name nm  On nm.Obj = ctx.FeatureStructure
			where ctx.Id = @CurId
			order by nm.Ws
			set @ContextString = '[' + @Txt + ']'
		end
		else if @class = 5087 begin	-- PhSimpleContextSeg
			select top 1 @Txt = isnull(nm.Txt, '***')
			from PhSimpleContextSeg ctx 
			join PhTerminalUnit tu  On tu.Id = ctx.FeatureStructure
			join PhTerminalUnit_Codes cds  On cds.Src = tu.Id
			join PhCode_Representation nm  On nm.Obj = cds.Dst
			where ctx.Id = @CurId
			order by cds.Ord, nm.Ws
			set @ContextString = @Txt
		end
		else begin
			set @ContextString = '***'
			set @retval = 1
			goto LExit
		end
	end
	else begin
		set @ContextString = '***'
		set @retval = 1
		goto LExit
	end
	set @retval = 0
LExit:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @retval
go


if object_id('DisplayName_PhEnvironment') is not null
	drop proc DisplayName_PhEnvironment
go
print 'creating proc DisplayName_PhEnvironment'
go










create proc DisplayName_PhEnvironment
	@XMLIds ntext = null
as
	declare @retval int, @fIsNocountOn int,
		@EnvId int, @EnvTxt nvarchar(4000),
		@CurContext int, @Txt nvarchar(4000),
		@myCursor CURSOR		

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	--Table variable.
	declare @DisplayNamePhEnvironment table (
		EnvId int primary key,
		--( See the notes under string tables in FwCore.sql about the 
		--( COLLATE clause.
		EnvTxt NVARCHAR(4000) COLLATE Latin1_General_BIN
		)
	
	if @XMLIds is null begin
		-- Do all environments.
		set @myCursor = CURSOR FAST_FORWARD for
			select Id
			from PhEnvironment 
			order by id
		open @myCursor
	end
	else begin
		-- Do environments provided in xml string.
		declare @hdoc int
		exec sp_xml_preparedocument @hdoc output, @XMLIds
		if @@error <> 0 begin
			set @retval = 1
			goto LExitNoCursor
		end
		set @myCursor = CURSOR FAST_FORWARD for
			select cmo.Id
			from	openxml(@hdoc, '/root/Obj')
			with ([Id] int) as ol
			-- Remove all pretenders, since they won't 'join'.
			join CmObject cmo 
				On ol.Id=cmo.Id
				and cmo.Class$ = 5097
			order by ol.[Id]
		open @myCursor
		-- Turn loose of the handle
		exec sp_xml_removedocument @hdoc
		if @@error <> 0 begin
			set @retval = 1
			goto LExitWithCursor
		end
	end

	-- Loop through all ids.
	fetch next from @myCursor into @EnvId
	while @@fetch_status = 0
	begin
		select @EnvTxt = isnull(StringRepresentation, '_')
		from PhEnvironment env 
		where Id = @EnvId

		-- Update the table variable
		insert @DisplayNamePhEnvironment (EnvId, EnvTxt)
		values (@EnvId, @EnvTxt)

		-- Try for another one.
		fetch next from @myCursor into @EnvId
	end

	select * from @DisplayNamePhEnvironment
	set @retval = 0

LExitWithCursor:
	close @myCursor
	deallocate @myCursor

LExitNoCursor:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @retval
go


if object_id('DisplayName_PhPhonologicalContext') is not null begin
	drop proc DisplayName_PhPhonologicalContext
end
go
print 'creating proc DisplayName_PhPhonologicalContext'
go












create proc DisplayName_PhPhonologicalContext
	@XMLIds ntext = null
as
	declare @retval int, @fIsNocountOn int,
		@CtxId int, @CtxForm nvarchar(4000),
		@myCursor CURSOR

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	--Table variable.
	declare @DisplayNamePhPhonologicalContext table (
		CtxId int primary key,
		CtxForm nvarchar(4000)
		)
	
	if @XMLIds is null begin
		-- Do all contexts.
		set @myCursor = CURSOR FAST_FORWARD for
			select Id
			from PhPhonologicalContext 
			order by id
		open @myCursor
	end
	else begin
		-- Do contexts provided in xml string.
		declare @hdoc int
		exec sp_xml_preparedocument @hdoc output, @XMLIds
		if @@error <> 0 begin
			set @retval = 1
			goto LExitNoCursor
		end
		set @myCursor = CURSOR FAST_FORWARD for
			select cmo.Id
			from	openxml(@hdoc, '/root/Obj')
			with ([Id] int) as ol
			-- Remove all pretenders, since they won't 'join'.
			join CmObject cmo 
				On ol.Id=cmo.Id
				and cmo.Class$ IN (5082, 5083, 5085, 5086, 5087)
			order by ol.[Id]
		open @myCursor
		-- Turn loose of the handle
		exec sp_xml_removedocument @hdoc
		if @@error <> 0 begin
			set @retval = 1
			goto LExitWithCursor
		end
	end

	-- Loop through all ids.
	fetch next from @myCursor into @CtxId
	while @@fetch_status = 0
	begin
		exec @retval = DisplayName_PhPhonologicalContextID @CtxId, @CtxForm output
		if @retval > 0 begin
			delete @DisplayNamePhPhonologicalContext
			goto LExitWithCursor
		end
		-- Update the temporary table
		insert @DisplayNamePhPhonologicalContext (CtxId, CtxForm)
		values (@CtxId, @CtxForm)

		-- Try for another one.
		fetch next from @myCursor into @CtxId
	end

	select * from @DisplayNamePhPhonologicalContext
	set @retval = 0

LExitWithCursor:
	close @myCursor
	deallocate @myCursor

LExitNoCursor:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	return @retval
go


if object_id('DisplayName_MoForm') is not null begin
	drop proc DisplayName_MoForm
end
go
print 'creating proc DisplayName_MoForm'
go










create proc [DisplayName_MoForm]
	@XMLIds ntext = null
as
	
declare @retval int, @fIsNocountOn int,
	@DisplayName nvarchar(4000), @pfxMarker nvarchar(2), @sfxMarker nvarchar(2),
	@AlloId int, @AlloClass int, @AlloOwner int, @AlloFlid int,
		@AlloTxt nvarchar(4000), @AlloFmt int, @AlloWs int,
	@SenseId int, @SenseTxt nvarchar(4000), @SenseFmt int, @SenseWs int,
	@CfTxt nvarchar(4000), @CfFmt int, @CfWs int,
	@myCursor CURSOR

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	set @AlloFlid=5002008

	-- table variable to hold return information.
	declare @DisplayNameMoForm table (
		DisplayName nvarchar(4000), --1
		AlloId int,	-- 2
		AlloClass int,	-- 3
		AlloOwner int,	-- 4
		AlloFlid int,	-- 5
		AlloTxt nvarchar(4000),	-- 6
		AlloFmt int,	-- 7
		AlloWs int,	-- 8
		SenseId int,	-- 
		SenseTxt nvarchar(4000),	-- 10
		SenseFmt int,	-- 11
		SenseWs int,	-- 12
		CfTxt nvarchar(4000),	-- 13
		CfFmt int,	-- 14
		CfWs int)	-- 15

	--Note: This can't be a table variable, because we do:
	-- insert #DNLE exec DisplayName_LexEntry null
	--And that can't be done using table variables.
	create table #DNLE (
		LeId int primary key,
		Class int,
		HNum int default 0,
		--( See the notes under string tables in FwCore.sql about the 
		--( COLLATE clause.
		FullTxt NVARCHAR(4000) COLLATE Latin1_General_BIN,
		FormId int default 0,
		Ord int default 0,
		Flid int default 0,
		FormTxt nvarchar(4000),
		FormFmt int,
		FormEnc int,
		SenseId int default 0,
		SenseGloss nvarchar(4000),
		SenseFmt int,
		SenseEnc int
		)






	
	if @XMLIds is null begin
		insert #DNLE exec DisplayName_LexEntry null
		-- Do all MoForms that are owned in the Allomorphs property of LexEntry.
		set @myCursor = CURSOR FAST_FORWARD for
			select Id, Class$ 
			from CmObject 
			where Class$ IN (5027, 5045) and OwnFlid$=@AlloFlid
			order by Id
		open @myCursor
	end
	else begin
		-- Do MoForms provided in xml string.
		declare @hdoc int
		exec sp_xml_preparedocument @hdoc output, @XMLIds
		if @@error <> 0 begin
			set @retval = 1
			goto LExitNoCursor
		end
		set @myCursor = CURSOR FAST_FORWARD for
			select cmo.Id, cmo.Class$ 
			from	openxml(@hdoc, '/root/Obj')
			with ([Id] int) as ol
			-- Remove all pretenders, since they won't 'join'.
			join CmObject cmo 
				On ol.Id=cmo.Id
				and cmo.Class$ IN (5027, 5045) and OwnFlid$=@AlloFlid
			order by ol.[Id]
		open @myCursor
		-- Turn loose of the handle
		exec sp_xml_removedocument @hdoc
		if @@error <> 0 begin
			set @retval = 1
			goto LExitWithCursor
		end
	end

	-- Loop through all ids.
	fetch next from @myCursor into @AlloId, @AlloClass
	while @@fetch_status = 0
	begin
		-- Get display name for LexEntry.
		declare @XMLLEId nvarchar(4000), @cnt int

		select @AlloOwner=Owner$
		from CmObject 
		where Id=@AlloId

		set @XMLLEId = '<root><Obj Id="' + cast(@AlloOwner as nvarchar(100)) + '"/></root>'

		if @XMLIds is not null
			insert #DNLE exec DisplayName_LexEntry @XMLLEId

		select @SenseId=SenseId, @SenseTxt=isnull(SenseGloss, '***'), @SenseFmt=SenseFmt, @SenseWs=SenseEnc, @AlloWs=FormEnc
		from #DNLE 
		where LeId=@AlloOwner

		-- REVIEW (SteveMiller): MultiTxt$.fmt was always NULL. Don't understand the 
		-- reason for @AlloFmt being set to Fmt. Changed to cast(null as varbinary).

		select @AlloTxt=isnull(Txt, '***'), @AlloFmt = cast(null as varbinary)
		from MoForm_Form 
		where Ws=@AlloWs and Obj=@AlloId

		select @pfxMarker=isnull(mmt.Prefix, ''), @sfxMarker=isnull(mmt.Postfix, '')
		from MoForm f 
		left outer join MoMorphType mmt  On f.MorphType=mmt.Id
		where f.Id=@AlloId

		-- REVIEW (SteveMiller): MultiTxt$.fmt was always NULL. Don't understand the 
		-- reason for @AlloFmt being set to Fmt. Changed to cast(null as varbinary).

		select @CfTxt=isnull(Txt, '***'), @CfFmt = cast(null as varbinary), @CfWs=Ws
		from LexEntry_CitationForm 
		where Obj=@AlloOwner and Ws=@AlloWs

		set @DisplayName = @pfxMarker + @AlloTxt + @sfxMarker + ' (' + @SenseTxt + '): ' + @CfTxt

		if @XMLIds is not null
			truncate table #DNLE

		--Put everything in temporary table
		insert @DisplayNameMoForm (
			DisplayName,
			AlloId, AlloClass, AlloOwner, AlloFlid, AlloTxt, AlloFmt, AlloWs,
			SenseId, SenseTxt, SenseFmt, SenseWs,
			CfTxt, CfFmt, CfWs)
		values (@DisplayName,
			@AlloId, @AlloClass, @AlloOwner, @AlloFlid, @AlloTxt, @AlloFmt, @AlloWs,
			@SenseId, @SenseTxt, @SenseFmt, @SenseWs,
			@CfTxt, @CfFmt, @CfWs)
		-- Try for another MoForm.
		fetch next from @myCursor into @AlloId, @AlloClass
	end

	set @retval = 0
	select * from @DisplayNameMoForm order by AlloTxt

LExitWithCursor:
	close @myCursor
	deallocate @myCursor

LExitNoCursor:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	drop table #DNLE

	return @retval
go


if object_id('DisplayName_LexEntry') is not null begin
	drop proc DisplayName_LexEntry
end
go
print 'creating proc DisplayName_LexEntry'
go
















create  proc [DisplayName_LexEntry]
	@XMLIds ntext = null
as
	
declare @retval int, @fIsNocountOn int,
	@LeId int, @Class int, @HNum int, @FullTxt nvarchar(4000),
	@FormId int, @Ord int, @Flid int, @FormTxt nvarchar(4000), @FormFmt int, @FormEnc int,
	@SenseId int, @SenseGloss nvarchar(4000), @SenseFmt int, @SenseEnc int,
	@myCursor CURSOR

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- Gather two encodings,
	select top 1 @SenseEnc=le.Id
	from LanguageProject_CurrentAnalysisWritingSystems ce 
	join LgWritingSystem le  On le.Id = ce.Dst
	order by ce.Src, ce.ord
	select top 1 @FormEnc=le.Id
	from LanguageProject_CurrentVernacularWritingSystems ce 
	join LgWritingSystem le  On le.Id = ce.Dst
	order by ce.Src, ce.ord

	--Table variable.
	declare @DisplayNameLexEntry table (
		LeId int primary key,
		Class int,
		HNum int default 0,
		--( See the notes under string tables in FwCore.sql about the 
		--( COLLATE clause.
		FullTxt NVARCHAR(4000) COLLATE Latin1_General_BIN,
		FormId int default 0,
		Ord int default 0,
		Flid int default 0,
		FormTxt nvarchar(4000),
		FormFmt int,
		FormEnc int,
		SenseId int default 0,
		SenseGloss nvarchar(4000),
		SenseFmt int,
		SenseEnc int
		)
	
	if @XMLIds is null begin
		-- Do all lex entries.
		set @myCursor = CURSOR FAST_FORWARD for
			select Id, Class$ 
			from CmObject 
			where Class$ IN (5007, 5008, 5009)
			order by id
		open @myCursor
	end
	else begin
		-- Do lex entries provided in xml string.
		declare @hdoc int
		exec sp_xml_preparedocument @hdoc output, @XMLIds
		if @@error <> 0 begin
			set @retval = 1
			goto LExitNoCursor
		end
		set @myCursor = CURSOR FAST_FORWARD for
			select cmo.Id, cmo.Class$ 
			from	openxml(@hdoc, '/root/Obj')
			with ([Id] int) as ol
			-- Remove all pretenders, since they won't 'join'.
			join CmObject cmo 
				On ol.Id=cmo.Id
				and cmo.Class$ IN (5007, 5008, 5009)
			order by ol.[Id]
		open @myCursor
		-- Turn loose of the handle
		exec sp_xml_removedocument @hdoc
		if @@error <> 0 begin
			set @retval = 1
			goto LExitWithCursor
		end
	end
	
	-- REVIEW (SteveMiller): MultiTxt$.fmt was always NULL. Don't understand the 
	-- reason for @FormFmt being set to Fmt. Changed to cast(null as varbinary).
	
	-- Loop through all ids.
	fetch next from @myCursor into @LeId, @Class
	while @@fetch_status = 0
	begin
		select top 1 @FormId=0, @Ord=0, @Flid = 5002003, @FormTxt=Txt, @FormFmt=cast(null as varbinary)
		from LexEntry_CitationForm 
		where Obj=@LeId and Ws=@FormEnc
		if @@rowcount = 0 begin
			select top 1 @FormId=f.Obj, @Ord=0, @Flid = 5035001, @FormTxt=f.Txt, @FormFmt=cast(null as varbinary)
			from LexEntry_UnderlyingForm uf 
			join MoForm_Form f  On f.Obj=uf.Dst and f.Ws=@FormEnc
			where uf.Src=@LeId
			if @@rowcount = 0 begin
				select top 1 @FormId=f.Obj, @Ord=a.Ord, @Flid=5035001, @FormTxt=f.Txt, @FormFmt=cast(null as varbinary)
				from LexEntry_Allomorphs a 
				join MoForm_Form f  On f.Obj=a.Dst and f.Ws=@FormEnc
				where a.Src=@LeId
				if @@rowcount = 0 begin
					set @FormId = 0
					set @Ord = 0
					set @Flid = 0
					set @FormTxt = '***'
				end
			end
		end
		set @FullTxt = @FormTxt

		-- Deal with homograph number.
		select @HNum=HomographNumber
		from LexEntry 
		where Id=@LeId
		if @HNum > 0
			set @FullTxt = @FullTxt + '-' + cast(@HNum as nvarchar(100))

		-- Deal with conceptual model class.

		-- Deal with sense gloss.
		select top 1 @SenseId=ls.Id, @SenseGloss = isnull(g.Txt, '***'), @SenseFmt= cast(null as varbinary)
		from LexEntry_Senses mes 
		left outer join LexSense ls 
			On ls.Id=mes.Dst
		left outer join LexSense_Gloss g 
			On g.Obj=ls.Id and g.Ws=@SenseEnc
		where mes.Src=@LeId
		order by mes.Ord
		set @FullTxt = @FullTxt + ' : ' + @SenseGloss

		insert into @DisplayNameLexEntry (LeId, Class, HNum, FullTxt,
					FormId, Ord, Flid, FormTxt, FormFmt, FormEnc,
					SenseId, SenseGloss, SenseFmt, SenseEnc)
			values (@LeId, @Class, @HNum, @FullTxt,
					@FormId, @Ord, @Flid, @FormTxt, @FormFmt, @FormEnc,
					@SenseId, @SenseGloss, @SenseFmt, @SenseEnc)
		-- Try for another one.
		fetch next from @myCursor into @LeId, @Class
	end

	set @retval = 0
	select * from @DisplayNameLexEntry order by FullTxt

LExitWithCursor:
	close @myCursor
	deallocate @myCursor

LExitNoCursor:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @retval
go


if object_id('DisplayName_Msa') is not null begin
	drop proc DisplayName_MSA
end
go
print 'creating proc DisplayName_Msa'
go










create proc [DisplayName_Msa]
	@XMLIds ntext = null, @ShowForm bit = 1
as
	
declare @retval int, @fIsNocountOn int,
	@MsaId int, @MsaClass int, @MsaForm nvarchar(4000),
	@FormId int, @FormClass int, @FormOwner int, @FormFlid int,
		@FormTxt nvarchar(4000), @FormFmt int, @FormEnc int,
	@SenseId int, @SenseTxt nvarchar(4000), @SenseFmt int, @SenseEnc int,
	@POSaID int, @POSaTxt nvarchar(4000), @POSaFmt int, @POSaEnc int,
	@POSbID int, @POSbTxt nvarchar(4000), @POSbFmt int, @POSbEnc int,
	@Defined bit, @myCursor CURSOR

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- table variable to hold return information.
	declare @DisplayNameMsa table (
		MsaId int,	-- 1
		MsaClass int,	-- 2
		MsaForm nvarchar(4000),	-- 3
		FormId int,	-- 4
		FormClass int,	-- 5
		FormOwner int,	-- 6
		FormFlid int,	-- 7
		--( See the notes under string tables in FwCore.sql about the 
		--( COLLATE clause.
		FormTxt NVARCHAR(4000) COLLATE Latin1_General_BIN, -- 8
		FormFmt int,	-- 9
		FormEnc int,	-- 10
		SenseId int,	-- 11
		--( See the notes under string tables in FwCore.sql about the 
		--( COLLATE clause.
		SenseTxt NVARCHAR(4000) COLLATE Latin1_General_BIN, -- 12
		SenseFmt int,	-- 13
		SenseEnc int,	-- 14
		POSaID int,	-- 15
		--( See the notes under string tables in FwCore.sql about the 
		--( COLLATE clause.
		POSaTxt NVARCHAR(4000) COLLATE Latin1_General_BIN, --16
		POSaFmt int,	-- 17
		POSaEnc int,	-- 18
		POSbID int,	-- 19
		--( See the notes under string tables in FwCore.sql about the 
		--( COLLATE clause.
		POSbTxt NVARCHAR(4000) COLLATE Latin1_General_BIN, --20
		POSbFmt int,	-- 21
		POSbEnc int	-- 22
		)




	--Note: This can't be a table variable, because we do:
	-- insert #DNLE exec DisplayName_LexEntry null
	--And that can't be done using table variables.
	create table #DNLE (
		LeId int primary key,
		Class int,
		HNum int default 0,
		--( See the notes under string tables in FwCore.sql about the 
		--( COLLATE clause.
		FullTxt NVARCHAR(4000) COLLATE Latin1_General_BIN,
		FormId int default 0,
		Ord int default 0,
		Flid int default 0,
		--( See the notes under string tables in FwCore.sql about the 
		--( COLLATE clause.
		FormTxt NVARCHAR(4000) COLLATE Latin1_General_BIN,
		FormFmt int,
		FormEnc int,
		SenseId int default 0,
		SenseGloss nvarchar(4000),
		SenseFmt int,
		SenseEnc int
		)







	
	if @XMLIds is null begin
		insert #DNLE exec DisplayName_LexEntry null
		-- Do all MSAes.
		set @myCursor = CURSOR FAST_FORWARD for
			select Id, Class$ 
			from CmObject 
			where Class$ IN (5001, 5031, 5032, 5038)
			order by Id
		open @myCursor
	end
	else begin
		-- Do MSAes provided in xml string.
		declare @hdoc int
		exec sp_xml_preparedocument @hdoc output, @XMLIds
		if @@error <> 0 begin
			set @retval = 1
			goto LExitNoCursor
		end
		set @myCursor = CURSOR FAST_FORWARD for
			select cmo.Id, cmo.Class$ 
			from	openxml(@hdoc, '/root/Obj')
			with ([Id] int) as ol
			-- Remove all pretenders, since they won't 'join'.
			join CmObject cmo 
				On ol.Id=cmo.Id
				and cmo.Class$ IN (5001, 5031, 5032, 5038)
			order by ol.[Id]
		open @myCursor
		-- Turn loose of the handle
		exec sp_xml_removedocument @hdoc
		if @@error <> 0 begin
			set @retval = 1
			goto LExitWithCursor
		end
	end

	-- Loop through all ids.
	fetch next from @myCursor into @MsaId, @MsaClass
	while @@fetch_status = 0
	begin
		-- Get display name for LexEntry.
		declare @LeId int, @XMLLEId nvarchar(4000), @cnt int

		select @LeId=Owner$
		from CmObject 
		where Id=@MsaId

		set @XMLLEId = '<root><Obj Id="' + cast(@LeId as nvarchar(100)) + '"/></root>'

		if @XMLIds is not null
			insert #DNLE exec DisplayName_LexEntry @XMLLEId
		select @MsaForm=FullTxt,
			@FormId=FormId, @FormFlid=Flid, @FormTxt=FormTxt, @FormFmt=FormFmt, @FormEnc=FormEnc,
			@SenseId=SenseId, @SenseTxt=SenseGloss, @SenseFmt=SenseFmt, @SenseEnc=SenseEnc
		from #DNLE 
		where LeId=@LeId
		if @ShowForm = 0
			set @MsaForm = ''
		else
			set @MsaForm = @MsaForm + ' '
		if @FormId = 0
			set @FormOwner = @LeId
		else
			set @FormOwner = @FormId
		if @XMLIds is not null
			truncate table #DNLE

		-- REVIEW (SteveMiller): MultiTxt$.fmt was always NULL. Don't understand the 
		-- reason for @POSaFmt being set to Fmt. Changed to cast(null as varbinary).
		
		if @MsaClass=5001 begin		--MoStemMsa
			select top 1 @POSaID=pos.Id, @POSaTxt=isnull(nm.Txt, '***'),
					@POSaFmt=cast(null as varbinary), @POSaEnc=nm.Ws
			from MoStemMsa msa 
			left outer join PartOfSpeech pos  On pos.Id=msa.PartOfSpeech
			left outer join CmPossibility_Name nm  On nm.Obj=pos.Id and nm.Ws=@SenseEnc
			where msa.Id=@MsaId
			set @MsaForm = @MsaForm + 'stem/root: ' + @POSaTxt
		end
		else if @MsaClass=5031 begin	--MoDerivationalAffixMsa
			-- Defined
			select @Defined=defined
			from MoDerivationalAffixMsa msa 
			where msa.Id=@MsaId
			if @Defined=1 begin
				-- FromPartOfSpeech
				select top 1 @POSaID=pos.Id, @POSaTxt=isnull(nm.Txt, '***'),
						@POSaFmt=cast(null as varbinary), @POSaEnc=nm.Ws
				from MoDerivationalAffixMsa msa 
				left outer join PartOfSpeech pos  On pos.Id=msa.FromPartOfSpeech
				left outer join CmPossibility_Name nm  On nm.Obj=pos.Id and nm.Ws=@SenseEnc
				where msa.Id=@MsaId
				-- ToPartOfSpeech
				select top 1 @POSbID=pos.Id, @POSbTxt=isnull(nm.Txt, '***'),
						@POSbFmt=cast(null as varbinary), @POSbEnc=nm.Ws
				from MoDerivationalAffixMsa msa 
				left outer join PartOfSpeech pos  On pos.Id=msa.ToPartOfSpeech
				left outer join CmPossibility_Name nm  On nm.Obj=pos.Id and nm.Ws=@SenseEnc
				where msa.Id=@MsaId
				set @MsaForm = @MsaForm + 'derivational: ' + @POSaTxt + ' to ' + @POSbTxt
			end
			else set @MsaForm = @MsaForm + 'unknown'
		end
		else if @MsaClass=5032 begin	--MoDerivationalStepMsa
			select top 1 @POSaID=pos.Id, @POSaTxt=isnull(nm.Txt, '***'),
					@POSaFmt=cast(null as varbinary), @POSaEnc=nm.Ws
			from MoDerivationalStepMsa msa 
			left outer join PartOfSpeech pos  On pos.Id=msa.PartOfSpeech
			left outer join CmPossibility_Name nm  On nm.Obj=pos.Id and nm.Ws=@SenseEnc
			where msa.Id=@MsaId
			set @MsaForm = @MsaForm + ' : ' + @POSaTxt
		end
		if @MsaClass=5038 begin --MoInflectionalAffixMsa
			set @MsaForm = @MsaForm + 'inflectional: MoInflAffixSlot inflects PartsOfSpeech'
		end

		--Put everything in temporary table
		insert @DisplayNameMsa (MsaId, MsaClass,
			MsaForm, FormId, FormClass, FormOwner, FormFlid, FormTxt, FormFmt, FormEnc,
			SenseId, SenseTxt, SenseFmt, SenseEnc,
			POSaID, POSaTxt, POSaFmt, POSaEnc,
			POSbID, POSbTxt, POSbFmt, POSbEnc)
		values (@MsaId, @MsaClass, @MsaForm,
			@FormId, @FormClass, @FormOwner, @FormFlid, @FormTxt, @FormFmt, @FormEnc,
			@SenseId, @SenseTxt, @SenseFmt, @SenseEnc,
			@POSaID, @POSaTxt, @POSaFmt, @POSaEnc,
			@POSbID, @POSbTxt, @POSbFmt, @POSbEnc)
		-- Try for another MSA.
		fetch next from @myCursor into @MsaId, @MsaClass
	end

	set @retval = 0
	select * from @DisplayNameMsa order by MsaForm

LExitWithCursor:
	close @myCursor
	deallocate @myCursor

LExitNoCursor:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	drop table #DNLE

	return @retval
go

if object_id('MatchingEntries') is not null begin
	print 'removing proc MatchingEntries'
	drop proc MatchingEntries
end
print 'creating proc MatchingEntries'
go















create proc [MatchingEntries]
	@cf nvarchar(4000),
	@uf nvarchar(4000),
	@af nvarchar(4000),
	@gl nvarchar(4000)
AS
	declare @CFTxt nvarchar(4000), @cftext nvarchar(4000),
		@UFTxt nvarchar(4000), @uftext nvarchar(4000),
		@AFTxt nvarchar(4000), @aftext nvarchar(4000),
		@GLTxt nvarchar(4000), @gltext nvarchar(4000),
		@entryID int, @senseID int, @prevID int, @ObjId int,
		@class int
	declare @fIsNocountOn int
	-- deterimine if no count is currently set to on
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- table variable to hold return information.
	declare @MatchingEntries table (
		EntryID int primary key,		-- 1
		Class int,				-- 2
		CFTxt nvarchar(4000) default '***',	-- 3
		UFTxt nvarchar(4000) default '***',	-- 4
		AFTxt nvarchar(4000) default '***',	-- 5
		GLTxt nvarchar(4000) default '***'	-- 6
		)

	insert into @MatchingEntries (EntryID, Class, CFTxt, UFTxt)
		select le.id, le.Class$, cf.Txt, uff.Txt
		from LexEntry_ le 
		join LexEntry_CitationForm cf  ON le.id = cf.Obj
		join LexEntry_UnderlyingForm uf  ON cf.Obj = uf.Src
		join MoForm_Form uff  ON uff.Obj = uf.Dst
		where cf.Txt LIKE RTRIM(LTRIM(@cf)) + '%'
			or uff.Txt LIKE RTRIM(LTRIM(@uf)) + '%'

	declare @curAllos CURSOR
	set @curAllos = CURSOR FAST_FORWARD for
		select le.id, le.Class$, amf.Txt
		from LexEntry_ le 
		join LexEntry_Allomorphs lea  ON lea.Src = le.id
		join MoForm_Form amf  ON amf.Obj = lea.Dst
		where amf.Txt LIKE RTRIM(LTRIM(@af)) + '%'
				
	OPEN @curAllos
	FETCH NEXT FROM @curAllos INTO @entryID, @class, @aftext
	WHILE @@FETCH_STATUS = 0
	BEGIN
		if @prevID = @entryID
			set @AFTxt = @AFTxt + '; ' + @aftext
		else
			set @AFTxt = @aftext
		select @ObjId=EntryID
		from @MatchingEntries
		where EntryID=@entryID
		if @@ROWCOUNT = 0
			insert into @MatchingEntries (EntryID, Class, AFTxt)
			values (@entryID, @class, @AFTxt)
		else
			update @MatchingEntries
			set AFTxt=@AFTxt
			where EntryID=@entryID
		set @prevID = @entryID
		FETCH NEXT FROM @curAllos INTO @entryID, @class, @aftext
	END
	CLOSE @curAllos
	DEALLOCATE @curAllos

	declare @curSenses CURSOR
	declare @OwnerId int, @OwnFlid int
	set @prevID = 0
	set @curSenses = CURSOR FAST_FORWARD for
		select Obj, Txt
		from LexSense_Gloss 
		where Txt LIKE RTRIM(LTRIM(@gl)) + '%'
				
	OPEN @curSenses
	FETCH NEXT FROM @curSenses INTO @senseId, @gltext
	WHILE @@FETCH_STATUS = 0
	BEGIN
		set @OwnFlid = 0
		set @entryID = @SenseId
		-- Loop until we find an owning flid of 5002011.
		while @OwnFlid != 5002011
		begin
			select 	@OwnerId=isnull(Owner$, 0), @OwnFlid=OwnFlid$
			from	CmObject 
			where	Id=@entryID
			set @entryID=@OwnerId
			if @OwnerId = 0
				return 1
		end

		select @class=class$
		from CmObject 
		where id=@entryID

		if @prevID = @senseId
			set @GLTxt = @GLTxt + '; ' + @gltext
		else
			set @GLTxt = @gltext

		select @ObjId=EntryID
		from @MatchingEntries
		where EntryID=@entryID

		if @@ROWCOUNT = 0
			insert into @MatchingEntries (EntryID, Class, GLTxt)
			values (@entryID, @class, @GLTxt)
		else
			update @MatchingEntries
			set GLTxt=@GLTxt
			where EntryID=@entryID

		set @prevID = @senseId
		FETCH NEXT FROM @curSenses INTO @senseId, @gltext
	END
	CLOSE @curSenses
	DEALLOCATE @curSenses

	declare @curFinalPass CURSOR
	set @curFinalPass = CURSOR FAST_FORWARD for
		select EntryID, CFTxt, UFTxt, AFTxt, GLTxt
		from @MatchingEntries
		where	CFTxt = '***'
			or UFTxt = '***'
			or AFTxt = '***'
			or GLTxt = '***'

	-- Try to find some kind of string for any items that have not matched,
	OPEN @curFinalPass
	FETCH NEXT FROM @curFinalPass INTO @entryID, @cftext, @uftext, @aftext, @gltext
	WHILE @@FETCH_STATUS = 0
	BEGIN
		if @cftext = '***'
		begin
			select top 1 @CFTxt=Txt
			from LexEntry_CitationForm 
			where Obj = @entryID

			if @CFTxt is not null
			begin
				update @MatchingEntries
				set CFTxt=@CFTxt
				where EntryID=@entryID
			end
		end
		if @uftext = '***'
		begin
			select top 1 @UFTxt=uff.Txt
			from LexEntry_UnderlyingForm uf 
			join MoForm_Form uff  ON uff.Obj = uf.Dst
			where uf.Src = @entryID

			if @UFTxt is not null
			begin
				update @MatchingEntries
				set UFTxt=@UFTxt
				where EntryID=@entryID
			end
		end
		if @aftext = '***'
		begin
			select top 1 @AFTxt=amf.Txt
			from LexEntry_ le 
			join LexEntry_Allomorphs lea  ON lea.Src = le.id
			join MoForm_Form amf  ON amf.Obj = lea.Dst
			where le.id = @entryID

			if @AFTxt is not null
			begin
				update @MatchingEntries
				set AFTxt=@AFTxt
				where EntryID=@entryID
			end
		end
		if @gltext = '***'
		begin
			SELECT top 1 @GLTxt=lsg.Txt
			FROM dbo.fnGetSensesInEntry$(@entryID)
			join LexSense_Gloss lsg  On lsg.Obj=SenseId

			if @GLTxt is not null
			begin
				update @MatchingEntries
				set GLTxt=@GLTxt
				where EntryID=@entryID
			end
		end
		FETCH NEXT FROM @curFinalPass INTO @entryID, @cftext, @uftext, @aftext, @gltext
	END
	CLOSE @curFinalPass
	DEALLOCATE @curFinalPass

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	select *
	from @MatchingEntries

go


if object_id('DisplayName_PhTerminalUnit') is not null begin
	drop proc DisplayName_PhTerminalUnit
end
go
print 'creating proc DisplayName_PhTerminalUnit'
go










create proc [DisplayName_PhTerminalUnit]
	@XMLIds ntext = null,
	@Cls int = 5092	-- PhPhoneme. 5091 is PhBdryMarker
as
	
declare @retval int, @fIsNocountOn int,
	@TUId int, @TUForm nvarchar(4000),
	@myCursor CURSOR

	if @Cls < 5091 or @Cls > 5092
		return 1	-- Wrong class.

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	--Table variable.
	declare @DisplayNameTU table (
		TUId int,	-- 1
		TUForm nvarchar(4000)	-- 2
		)
	
	if @XMLIds is null begin
		-- Do all MSAes.
		set @myCursor = CURSOR FAST_FORWARD for
			select Id
			from CmObject 
			where Class$ = @Cls
			order by Id
		open @myCursor
	end
	else begin
		-- Do MSAes provided in xml string.
		declare @hdoc int
		exec sp_xml_preparedocument @hdoc output, @XMLIds
		if @@error <> 0 begin
			set @retval = 1
			goto LExitNoCursor
		end
		set @myCursor = CURSOR FAST_FORWARD for
			select cmo.Id
			from	openxml(@hdoc, '/root/Obj')
			with ([Id] int) as ol
			-- Remove all pretenders, since they won't 'join'.
			join CmObject cmo 
				On ol.Id=cmo.Id
				and cmo.Class$ = @Cls
			order by ol.[Id]
		open @myCursor
		-- Turn loose of the handle
		exec sp_xml_removedocument @hdoc
		if @@error <> 0 begin
			set @retval = 1
			goto LExitWithCursor
		end
	end

	-- Loop through all ids.
	fetch next from @myCursor into @TUId
	while @@fetch_status = 0
	begin
		set @TUForm = '***'
		select top 1 @TUForm = isnull(Txt, '***')
		from PhTerminalUnit_Name 
		where Obj = @TUId
		order by Ws

		select top 1 @TUForm = @TUForm + ' : ' + isnull(r.Txt, '***')
		from PhTerminalUnit_Codes c 
		left outer join PhCode_Representation r  On r.Obj = c.Dst
		where c.Src = @TUId
		order by c.Ord, r.Ws

		--Put everything in temporary table
		insert @DisplayNameTU (TUId, TUForm)
		values (@TUId, @TUForm)
		-- Try for another MSA.
		fetch next from @myCursor into @TUId
	end

	set @retval = 0
	select * from @DisplayNameTU order by TUForm

LExitWithCursor:
	close @myCursor
	deallocate @myCursor

LExitNoCursor:
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	return @retval
go

print '****************************** Finished Loading LingSP.sql ******************************'
go


insert into Module$ ([Id], [Name], [Ver], [VerBack])
	values(3, 'Scripture', 1, 1)





insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(3002, 3, 0, 0, 'ScrBook')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(3007, 3, 0, 0, 'ScrBookGroup')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(3004, 3, 0, 0, 'ScrBookRef')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(3011, 3, 0, 0, 'ScrDifference')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(3010, 3, 0, 0, 'ScrDraft')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(3012, 3, 0, 0, 'ScrImportFootnoteSettings')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(3009, 3, 0, 0, 'ScrImportMapping')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(3008, 3, 0, 0, 'ScrImportSettings')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(3003, 3, 0, 0, 'ScrRefSystem')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(3005, 3, 0, 0, 'ScrSection')



insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(3001, 3, 5, 0, 'Scripture')



insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3002001, 27, 3002,
		3005, 'Sections',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3002002, 16, 3002,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3002003, 24, 3002,
		3004, 'BookId',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3002004, 23, 3002,
		14, 'Title',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3002005, 16, 3002,
		null, 'Abbrev',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3002008, 15, 3002,
		null, 'IdText',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3002009, 15, 3002,
		null, 'RunningHeader',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3002010, 27, 3002,
		39, 'Footnotes',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3002011, 25, 3002,
		3011, 'Diffs',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3007001, 14, 3007,
		null, 'Name',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3007002, 28, 3007,
		3004, 'Books',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3007003, 25, 3007,
		3007, 'BookGroups',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3004001, 16, 3004,
		null, 'BookName',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3004002, 15, 3004,
		null, 'BookId',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3004003, 16, 3004,
		null, 'BookAbbrev',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3004004, 16, 3004,
		null, 'BookNameAlt',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3011001, 2, 3011,
		null, 'RefStart',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3011002, 2, 3011,
		null, 'RefEnd',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3011003, 2, 3011,
		null, 'DiffType',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3011004, 2, 3011,
		null, 'RevMin',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3011005, 2, 3011,
		null, 'RevLim',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3011006, 24, 3011,
		15, 'RevParagraph',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3010001, 15, 3010,
		null, 'Description',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3010002, 27, 3010,
		3002, 'Books',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3012001, 15, 3012,
		null, 'Marker',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3012002, 15, 3012,
		null, 'FootnoteMarker',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3012003, 1, 3012,
		null, 'DisplayFootnoteMarker',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3012004, 1, 3012,
		null, 'DisplayFootnoteReference',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3009001, 15, 3009,
		null, 'Marker',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3009002, 15, 3009,
		null, 'TeStyleName',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3009003, 2, 3009,
		null, 'Domain',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3009005, 24, 3009,
		24, 'WritingSystem',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3008001, 2, 3008,
		null, 'ImportType',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3008002, 9, 3008,
		null, 'ImportSettings',0,Null, null, null, 0)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3008003, 15, 3008,
		null, 'ImportProjToken',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3008004, 25, 3008,
		3012, 'FootnoteSettings',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3003001, 27, 3003,
		3004, 'Books',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3005001, 23, 3005,
		14, 'Heading',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3005002, 23, 3005,
		14, 'Content',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3005003, 2, 3005,
		null, 'VerseRefStart',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3005004, 2, 3005,
		null, 'VerseRefEnd',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3005005, 27, 3005,
		39, 'Footnotes',0,Null, null, null, null)
go

insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3001001, 27, 3001,
		3002, 'ScriptureBooks',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3001002, 25, 3001,
		17, 'Styles',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3001003, 15, 3001,
		null, 'RefSepr',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3001004, 15, 3001,
		null, 'ChapterVerseSepr',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3001005, 15, 3001,
		null, 'VerseSepr',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3001006, 15, 3001,
		null, 'Bridge',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3001007, 23, 3001,
		3008, 'ImportSettings',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3001008, 25, 3001,
		3002, 'BookRevisions',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3001009, 25, 3001,
		3010, 'ArchivedDrafts',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3001010, 15, 3001,
		null, 'DefaultFootnoteMarker',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3001011, 1, 3001,
		null, 'DefaultDisplayFootnoteMarker',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3001012, 1, 3001,
		null, 'DefaultDisplayFootnoteReference',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3001013, 1, 3001,
		null, 'RestartFootnoteSequence',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3001014, 2, 3001,
		null, 'RestartFootnoteBoundary',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3001015, 1, 3001,
		null, 'UseScriptDigits',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3001016, 2, 3001,
		null, 'ScriptDigitZero',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(3001018, 1, 3001,
		null, 'ConvertCVNumsToEuropeanDigitsOnExport',0,Null, null, null, null)
go












print '****************************** Loading ScriptureSP.sql ******************************'
go


if exists (select *
             from sysobjects
            where name = 'CreateNewScrBook')
	drop proc CreateNewScrBook
go
print 'creating proc CreateNewScrBook'
go














create proc CreateNewScrBook
	@hvoScripture	int,
	@nBookNumber	int,
 	@hvoBook	int = null output,
	@hvoBookTitle	int = null output
as
  	declare @clid int, @flid int, @guid uniqueidentifier,
		@err int, @nTrnCnt int, @sTranName varchar(50),
		@fIsNocountOn int, @ord int, @hvoScrBookRef int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- Determine if a transaction already exists; if one does then create a savepoint, otherwise create a 
	-- transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'NewScrBook_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName

	-- Determine the ScrBookRef corresponding to this book and the relative position
	-- of this book in the ScrBook table.
	set @hvoScrBookRef = 0
	select @hvoScrBookRef = [id]
	from ScrBookRef_
	where OwnOrd$ = @nBookNumber
	if @hvoScrBookRef = 0 begin
		set @err = 55678
		raiserror('No matching ScrBookRef: %d', 16, 1, @nBookNumber) 
		goto LFail
	end

  	set @clid = 3002 -- ScrBook
	set @flid = 3001001 -- Scripture_ScriptureBooks
	set @ord = 0

	-- In the case of redo, the book id could be passed in as a prameter.
	-- If not, then we check to see if there's an existing book in the
	-- ScriptureBooks sequence. If we do find an existing book, @ord will
        -- get set > 0, and we will delete it below.
	if @hvoBook is null begin
		select @ord = OwnOrd$, @hvoBook = [id]
		from ScrBook_
		where BookId = @hvoScrBookRef
		and OwnFlid$ = @flid
		and Owner$ = @hvoScripture
	end
	else if EXISTS(SELECT * FROM ScrBook_ WHERE BookId = @hvoScrBookRef) begin
		set @err = 55679
		raiserror('Redo attempting to insert existing book: ID=%d', 16, 4, @hvoBook) 
		goto LFail
	end

	if @ord > 0 begin
		-- Delete the existing book
		declare @uid uniqueidentifier
		exec DeleteObject$ @uid, @objId = @hvoBook
		if @@error <> 0 begin 
			set @err = @@error 
			goto LFail
		end
		SET @hvoBook = null
-- REVIEW TomB: Should we be calling DeletOwnSeq here instead in order to preserve other book info?
	end
	else begin
		-- Select the lowest ord for any existing book beyond the one we want
		-- to create.
		select	@ord = coalesce(max(bk.[OwnOrd$])+1, 1)
		from	[ScrBook_] bk with (serializable)
		join	ScrBookRef_ on ScrBookRef_.[id] = bk.BookId
		and	ScrBookRef_.OwnOrd$ < @nBookNumber
		where	bk.[Owner$] = @hvoScripture
			and bk.[OwnFlid$] = @flid
  
  		update	[CmObject] with (serializable)
  		set 	[OwnOrd$]=[OwnOrd$]+1
  		where 	[Owner$] = @hvoScripture
  			and [OwnFlid$] = @flid
  			and [OwnOrd$] >= @ord 
		if @@error <> 0 begin 
			set @err = @@error 
			goto LFail
		end
	end

	-- Create the new ScrBook (base) object
	set @guid = NewId()
	if @hvoBook is null begin
		insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
		values(@guid, @clid, @hvoScripture, @flid, @ord)
		if @@error <> 0 begin 
			set @err = @@error 
			goto LFail
		end
		set @hvoBook = @@identity
	end
	else begin
		insert [CmObject] ([id], [Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
		values(@hvoBook, @guid, @clid, @hvoScripture, @flid, @ord)
		if @@error <> 0 begin 
			set @err = @@error 
			goto LFail 
		end
	end

	-- Create the new Title (base) object
	set @clid = 14 -- StText
	set @flid = 3002004 -- Scripture_ScriptureBooks
	set @guid = NewId()

	if @hvoBookTitle is null begin
		insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
		values(@guid, @clid, @hvoBook, @flid, NULL)
		if @@error <> 0 begin 
			set @err = @@error 
			goto LFail
		end
		set @hvoBookTitle = @@identity
	end
	else begin
		insert [CmObject] ([id], [Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
		values(@hvoBookTitle, @guid, @clid, @hvoBook, @flid, NULL)
		if @@error <> 0 begin 
			set @err = @@error 
			goto LFail
		end
	end

	-- Insert into ScrBook
	insert [ScrBook] ([Id], [BookId])
	values(@hvoBook, @hvoScrBookRef)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to ScrBook: ID=%d', 16, 2, @hvoBook) 
		goto LFail
	end

	-- Insert into StText
	-- ENHANCE TomB: Implement Right-to-left
	insert [StText] ([Id], [RightToLeft])
	values(@hvoBookTitle, 0)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to StText: ID=%d', 16, 3, @hvoBookTitle) 
		goto LFail
	end

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	-- if a transaction was created within this procedure commit it
	if @nTrnCnt = 0 commit tran @sTranName 
	return 0 

LFail: 
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	rollback tran @sTranName 
	return @err
GO


if exists (select *
             from sysobjects
            where name = 'Import_NewScrBookJRP')
	drop proc Import_NewScrBookJRP
go
print 'creating proc Import_NewScrBookJRP'
go
















create proc Import_NewScrBookJRP
	@hvoScripture	int,
	@nBookNumber	int,
 	@hvoBook	int = null output,
	@hvoBookTitle	int = null output
as
	declare @clid int, @flid int, @guid uniqueidentifier,
		@err int, @nTrnCnt int, @sTranName varchar(50),
		@fIsNocountOn int, @ord int, @hvoScrBookRef int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- Determine if a transaction already exists; if one does then create a savepoint, otherwise create a 
	-- transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'NewScrBookJRP_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName

	-- Determine the ScrBookRef corresponding to this book and the relative position
	-- of this book in the ScrBook table.
	set @hvoScrBookRef = 0
	select @hvoScrBookRef = [id]
	from ScrBookRef_
	where OwnOrd$ = @nBookNumber
	if @hvoScrBookRef = 0 begin
		set @err = 55678
		raiserror('No matching ScrBookRef: %d', 16, 1, @nBookNumber) 
		goto LFail
	end

	set @flid = 3001001 -- Scripture_ScriptureBooks
	set @ord = 0
	select @ord = OwnOrd$, @hvoBook = [id]
	from ScrBook_
	where BookId = @hvoScrBookRef

	if @ord > 0 begin
		-- Delete the existing book
		declare @uid uniqueidentifier
		exec DeleteObject$ @uid, @objId = @hvoBook
-- REVIEW TomB: Should we be calling DeletOwnSeq here instead in order to preserve other book info?
	end
	else begin
		-- Select the lowest ord for any existing book beyond the one we want
		-- to create.
		select	@ord = coalesce(max(bk.[OwnOrd$])+1, 1)
		from	[ScrBook_] bk with (serializable)
		join	ScrBookRef_ on ScrBookRef_.[id] = bk.BookId
		and	ScrBookRef_.OwnOrd$ < @nBookNumber
		where	bk.[Owner$] = @hvoScripture
			and bk.[OwnFlid$] = @flid
	end

	-- Create the new ScrBook (base) object
	exec CreateObject_ScrBook
	@ScrBook_Name_ws = NULL, @ScrBook_Name_txt = NULL, 
	@ScrBook_Abbrev_ws = NULL, @ScrBook_Abbrev_txt = NULL, 
	@Owner = @hvoScripture,
	@OwnFlid = @flid,
	@StartObj = NULL,
	@NewObjId = @hvoBook output,
	@NewObjGuid = NULL

	set @guid = NewId()
	insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
	values(@guid, @clid, @hvoScripture, @flid, @ord)
	if @@error <> 0 begin 
		set @err = @@error 
		goto LFail 
	end
	set @hvoBook = @@identity

	-- Create the new Title (base) object
	set @clid = 14 -- StText
	set @flid = 3002004 -- Scripture_ScriptureBooks
	set @guid = NewId()
	insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
	values(@guid, @clid, @hvoBook, @flid, NULL)
	if @@error <> 0 begin 
		set @err = @@error 
		goto LFail 
	end
	set @hvoBookTitle = @@identity

	-- Insert into ScrBook
	insert [ScrBook] ([Id], [BookId])
	values(@hvoBook, @hvoScrBookRef)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to ScrBook: ID=%d', 16, 1, @hvoBook) 
		goto LFail
	end

	-- Insert into StText
	-- ENHANCE TomB: Implement Right-to-left
	insert [StText] ([Id], [RightToLeft])
	values(@hvoBookTitle, 0)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to StText: ID=%d', 16, 1, @hvoBookTitle) 
		goto LFail
	end

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	-- if a transaction was created within this procedure commit it
	if @nTrnCnt = 0 commit tran @sTranName 
	return 0 

LFail: 
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	rollback tran @sTranName 
	return @err
GO


if exists (select *
             from sysobjects
            where name = 'Import_AppendScrSection')
	drop proc Import_AppendScrSection
go
print 'creating proc Import_AppendScrSection'
go














create proc Import_AppendScrSection
	@hvoScrBook int,			-- Id of owning ScrBook
	@ord int,				-- position for new section
	@hvoSection int = null output,		-- Id of new ScrSection
	@hvoSectHeading int = null output,	-- Id of new StText for section heading
	@hvoSectContent int = null output	-- Id of new StText for section contents
as
	declare @clid int, @flid int, @guid uniqueidentifier,
		@err int, @nTrnCnt int, @sTranName varchar(50),
		@fIsNocountOn int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	-- Determine if a transaction already exists; if one does then create a savepoint, otherwise create a 
	-- transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'AppendScrSection_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName

	set @clid = 3005 -- ScrSection
	set @flid = 3002001 -- ScrBook_Sections

	-- Create the new ScrSection object
	set @guid = NewId()
	insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
	values(@guid, @clid, @hvoScrBook, @flid, @ord)
	if @@error <> 0 begin 
		set @err = @@error 
		goto LFail 
	end
	set @hvoSection = @@identity

	insert [ScrSection] ([Id])
	values(@hvoSection)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to ScrSection: ID=%d', 16, 1, @hvoSection) 
		goto LFail
	end

	-- Create the StTexts
	set @clid = 14 -- StText

	-- Create the new Section Heading object
	set @flid = 3005001 -- ScrSection_Heading
	set @guid = NewId()
	insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
	values(@guid, @clid, @hvoSection, @flid, NULL)
	if @@error <> 0 begin 
		set @err = @@error 
		goto LFail 
	end
	set @hvoSectHeading = @@identity

	-- ENHANCE TomB: Implement Right-to-left
	insert [StText] ([Id], [RightToLeft])
	values(@hvoSectHeading, 0)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to StText: ID=%d', 16, 1, @hvoSectHeading) 
		goto LFail
	end

	-- Create the new Section Content object
	set @flid = 3005002 -- ScrSection_Content
	set @guid = NewId()
	insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
	values(@guid, @clid, @hvoSection, @flid, NULL)
	if @@error <> 0 begin 
		set @err = @@error 
		goto LFail 
	end
	set @hvoSectContent = @@identity

	-- ENHANCE TomB: Implement Right-to-left
	insert [StText] ([Id], [RightToLeft])
	values(@hvoSectContent, 0)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to StText: ID=%d', 16, 1, @hvoSectContent) 
		goto LFail
	end

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	-- if a transaction was created within this procedure commit it
	if @nTrnCnt = 0 commit tran @sTranName 
	return 0 

LFail: 
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	rollback tran @sTranName 
	return @err
GO


if exists (select *
             from sysobjects
            where name = 'Import_AppendPara')
	drop proc Import_AppendPara
go
print 'creating proc Import_AppendPara'
go















create proc Import_AppendPara
	@hvoText int,
	@ord int,				-- position for new paragraph
	@stuContents ntext,		-- Contents of new paragraph
	@rgbContentsFmt image,	-- format data for Contents
	@hvoPara int = null output,		-- id of new object
	@rgbStParaFmt varbinary(8000) = null	-- format data for paragraph
as
	declare @clid int, @flid int, @guid uniqueidentifier,
		@err int, @nTrnCnt int, @sTranName varchar(50),
		@fIsNocountOn int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	set @clid = 16 -- StTxtPara
	set @flid = 14001 -- StText_Paragraphs

	-- Determine if a transaction already exists; if one does then create a savepoint, otherwise create a 
	-- transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'AppendPara_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName

	-- Create the new object
	set @guid = NewId()
	insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
	values(@guid, @clid, @hvoText, @flid, @ord)
	if @@error <> 0 begin 
		set @err = @@error 
		goto LFail 
	end
	set @hvoPara = @@identity

	-- Insert into StPara
	insert [StPara] ([Id], [StyleRules])
	values(@hvoPara, @rgbStParaFmt)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to StPara: ID=%d', 16, 1, @hvoPara) 
		goto LFail
	end

	-- Insert into StTxtPara
	insert StTxtPara ([Id],[Contents],[Contents_Fmt])
	values (@hvoPara, @stuContents, @rgbContentsFmt)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to StTextPara: ID=%d', 16, 1, @hvoPara) 
		goto LFail
	end

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	-- if a transaction was created within this procedure commit it
	if @nTrnCnt = 0 commit tran @sTranName 
	return 0 

LFail: 
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	rollback tran @sTranName 
	return @err
GO


if exists (select *
             from sysobjects
            where name = 'GetScrBookInfo')
	drop proc GetScrBookInfo
go
print 'creating proc GetScrBookInfo'
go












create proc GetScrBookInfo
	@hvoScripture	int
as
	-- REVIEW (SteveMiller): This apparently is not in use when I came through
	-- refactoring MultiTxt$ out of the system. As it stood, the query would
	-- return one row for the book name, and another for the book abbreviation.
	-- I put the name and abbrev in one row. Hope that doesn't mess someone up.
	
	SELECT
		bk.[Id],
		bk.BookId,
		sbn.Txt AS BookName,
		sbn.Txt AS BookAbbrev,
		sbn.Ws
	FROM ScrBook_ bk
	LEFT OUTER JOIN ScrBook_Name sbn ON sbn.Obj = bk.[Id]
	LEFT OUTER JOIN ScrBook_Abbrev sba ON 
		sba.Obj = sbn.Obj AND sba.Obj = bk.[Id] AND sba.WS = sbn.WS
	WHERE bk.Owner$ = @hvoScripture AND bk.OwnFlid$ = 3001001 -- Scripture_ScriptureBooks
	ORDER BY bk.OwnOrd$

go


if exists (select *
             from sysobjects
            where name = 'GetScrBookTitle')
	drop proc GetScrBookTitle
go
print 'creating proc GetScrBookTitle'
go










create proc GetScrBookTitle
	@hvoScrBook	int
as
	select	[Id] "hvoTitle",
		[Owner$] "hvoOwner"
	from	StText_
	where	[Owner$] = @hvoScrBook
		and [OwnFlid$] = 3002004 -- ScrBook_Ttitle
go


if exists (select *
             from sysobjects
            where name = 'CreateObj_WfiWordForm')
	drop proc CreateObj_WfiWordForm
go
print 'creating proc CreateObj_WfiWordForm'
go















create proc CreateObj_WfiWordForm
	@hvoWfi		int,
	@stuForm	nvarchar(4000),
	@Ws		int,
	@id		int = null output,
	@nSpellingStat	tinyint = 0 output
as
	-- Begin by checking to see if it already exists. If so, then our
	-- job is easy.
	select	@id = f.[Obj],
		@nSpellingStat = w.[SpellingStatus]
	from	WfiWordform_Form f
	join	WfiWordform w on w.[id] = f.[Obj]
	where	CONVERT ( varbinary(8000), f.[Txt]) = CONVERT ( varbinary(8000), @stuForm)
	and	f.[Ws] = @Ws

	if @id is not null return 0

	declare @clid int, @flid int, @guid uniqueidentifier,
		@err int, @nTrnCnt int, @sTranName varchar(50),
		@fIsNocountOn int

	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on

	set @clid = 5062 -- WfiWordform
	set @flid = 5063001 -- WordformInventory_Wordforms

	-- Determine if a transaction already exists; if one does then create a savepoint, otherwise create a 
	-- transaction
	set @nTrnCnt = @@trancount 
	set @sTranName = 'WfiWordform_tr' + convert(varchar(8), @@nestlevel) 
	if @nTrnCnt = 0 begin tran @sTranName 
	else save tran @sTranName

	-- Create the new object
	set @guid = NewId()
	insert [CmObject] ([Guid$], [Class$], [Owner$], [OwnFlid$], [OwnOrd$])
	values(@guid, @clid, @hvoWfi, @flid, NULL)
	if @@error <> 0 begin 
		set @err = @@error 
		goto LFail 
	end
	set @id = @@identity

	-- Insert into WfiWordform
	insert WfiWordform ([Id], [SpellingStatus])
	values (@id, @nSpellingStat)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to WfiWordform: ID=%d', 16, 1, @id) 
		goto LFail
	end

	-- Insert into WfiWordform_Form
	insert WfiWordform_Form ([Obj],[Ws],[Txt])
	values (@id, @Ws, @stuForm)
	if @@error <> 0 begin 
		set @err = @@error 
		raiserror('Unable to add a row to WfiWordform_Form: ID=%d, Ws=%d, Txt=%s', 16, 1, @id, @Ws, @stuForm) 
		goto LFail
	end

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	-- if a transaction was created within this procedure commit it
	if @nTrnCnt = 0 commit tran @sTranName 
	return 0 

LFail: 
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

	rollback tran @sTranName 
	return @err
GO



insert into Module$ ([Id], [Name], [Ver], [VerBack])
	values(6, 'LangProj', 1, 1)





insert into Class$ ([Id], [Mod], [Base], [Abstract], [Name])
	values(6001, 6, 1, 0, 'LanguageProject')



insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001001, 15, 6001,
		null, 'EthnologueCode',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001002, 16, 6001,
		null, 'WorldRegion',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001003, 16, 6001,
		null, 'MainCountry',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001004, 16, 6001,
		null, 'FieldWorkLocation',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001005, 23, 6001,
		8, 'PartsOfSpeech',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001006, 25, 6001,
		5054, 'Texts',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001007, 23, 6001,
		8, 'TranslationTags',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001009, 24, 6001,
		8, 'Thesaurus',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001010, 26, 6001,
		5052, 'ReversalIndexes',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001011, 26, 6001,
		5065, 'WordformLookupLists',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001012, 23, 6001,
		8, 'AnthroList',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001013, 23, 6001,
		5063, 'WordformInventory',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001014, 23, 6001,
		5005, 'LexicalDatabase',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001015, 23, 6001,
		4001, 'ResearchNotebook',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001017, 26, 6001,
		24, 'AnalysisWritingSystems',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001018, 28, 6001,
		24, 'CurrentVernacularWritingSystems',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001019, 28, 6001,
		24, 'CurrentAnalysisWritingSystems',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001020, 28, 6001,
		24, 'CurrentPronunciationWritingSystems',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001021, 23, 6001,
		49, 'MsFeatureSystem',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001022, 23, 6001,
		5040, 'MorphologicalData',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001023, 25, 6001,
		17, 'Styles',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001024, 25, 6001,
		9, 'Filters',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001025, 23, 6001,
		8, 'ConfidenceLevels',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001026, 23, 6001,
		8, 'Restrictions',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001027, 23, 6001,
		8, 'WeatherConditions',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001028, 23, 6001,
		8, 'Roles',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001029, 23, 6001,
		8, 'AnalysisStatus',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001030, 23, 6001,
		8, 'Locations',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001031, 23, 6001,
		8, 'People',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001032, 23, 6001,
		8, 'Education',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001033, 23, 6001,
		8, 'TimeOfDay',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001034, 23, 6001,
		8, 'AffixCategories',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001035, 23, 6001,
		5099, 'PhonologicalData',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001036, 23, 6001,
		8, 'Positions',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001037, 25, 6001,
		21, 'Overlays',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001038, 25, 6001,
		23, 'AnalyzingAgents',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001040, 23, 6001,
		3001, 'TranslatedScripture',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001041, 26, 6001,
		24, 'VernacularWritingSystems',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001042, 15, 6001,
		null, 'ExtLinkRootDir',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001043, 25, 6001,
		31, 'SortSpecs',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001044, 25, 6001,
		34, 'Annotations',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001045, 25, 6001,
		40, 'UserAccounts',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001046, 25, 6001,
		41, 'ActivatedFeatures',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001047, 23, 6001,
		8, 'AnnotationDefinitions',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001048, 25, 6001,
		2, 'Pictures',0,Null, null, null, null)
insert into [Field$]
	([Id], [Type], [Class], [DstCls], [Name], [Custom], [CustomId], [Min], [Max], [Big])
	values(6001049, 23, 6001,
		8, 'SemanticDomainList',0,Null, null, null, null)
go












print '****************************** Loading LangProjSP.sql ******************************'
go

--
-- post model creation performance enhancements
--

-- once the model is built very few modifications are made to the following 
--	tables, so use a 95% fillfactor
dbcc dbreindex ('Field$', '', 95)

-- once the model is built no modifications are made to the following tables, 
--	so use a 100% fillfactor
dbcc dbreindex ('Class$', '', 100)
dbcc dbreindex ('ClassPar$', '', 100)
go

--
-- create CreateObject_ procedures for all non-abstract classes
--
begin
	print 'creating CreateObject_ procedures...'

	declare @sClassName sysname, @clid int

	declare class_cur cursor local fast_forward for
	select	[Name], [Id]
	from	[Class$]
	where	[Abstract] = 0

	-- loop through each non-abstract class and build an ObjectCreate_ procedure
	open class_cur
	fetch class_cur into @sClassName, @clid
	while @@fetch_status = 0 begin
		exec DefineCreateProc$ @clid
		fetch class_cur into @sClassName, @clid
	end

	close class_cur
	deallocate class_cur
end
go

--
-- create class views that contain all base classes including CmObject
--
begin
	print 'creating class views...'

	declare @depth int, @clid int, @sClass sysname

	create table #tblInheritStack (depth int, clid int)
	create clustered index ind_#tblInheritStack on #tblInheritStack (depth)

	-- start with CmObject
	insert into #tblInheritStack (Depth, clid)
	select	0, [Id]
	from	[Class$] 
	where	name = 'CmObject'

	-- loop through the inheritance hierarchy and build the inheritance stack
	set @depth = 0
	while 1 = 1 begin
		insert into #tblInheritStack (Depth, clid)
		select	@depth+1, cp.[Src]
		from	[ClassPar$] cp join #tblInheritStack inhstack on cp.[Dst] = inhstack.[clid]
		where	cp.[Depth] = 1
			and inhstack.[Depth] = @depth
		if @@rowcount = 0 break

		set @depth = @depth + 1
	end

	declare classview_cur cursor local fast_forward for
	select	[clid]
	from	#tblInheritStack
	where	depth > 0
	order by [Depth]

	open classview_cur
	fetch classview_cur into @clid
	while @@fetch_status = 0 begin
		select	@sClass = [Name]
		from	Class$
		where	[Id] = @clid
		exec UpdateClassView$ @clid, 0
		fetch classview_cur into @clid
	end
	close classview_cur
	deallocate classview_cur
	
	drop table #tblInheritStack
end
go







if not object_id('ObjHierarchy$') is null begin
	print 'removing table ObjHierarchy$'
	drop table ObjHierarchy$
end
print 'creating table ObjHierarchy$'
go
create table ObjHierarchy$ (
	strDepth varchar(50),
	intDepth int,
	ownOrd int,
	ownFlid int,
	owner int,
	class int,
	guid uniqueidentifier,
	id int
)
create index idx_id on ObjHierarchy$ (id)
create index idx_strDepth on ObjHierarchy$ (strDepth)
create index idx_flid on ObjHierarchy$ (ownFlid)
create index idx_owner on ObjHierarchy$ (owner)
go









if not object_id('UpdateHierarchy') is null begin
	print 'removing proc UpdateHierarchy'
	drop proc UpdateHierarchy
end
print 'creating proc UpdateHierarchy'
go
create proc UpdateHierarchy
as
	set nocount on

	--  Delete all objects in the ObjHierarchy$ table.
	truncate table ObjHierarchy$

	--  Copy all the CmObject records to the ObjHierarchy$ table.
	insert into ObjHierarchy$ (strDepth, intDepth, ownOrd, ownFlid, owner, class, guid, id) 
		select NULL, NULL, ownOrd$, ownFlid$, owner$, class$, guid$, id from CmObject


	--  Set the intDepth=1 and strDepth for top level (root) objects.
	--  These will be numbered according to the order of id.

	declare @intChildCounter int
	declare @intId int
	declare @intNumChildren int
	declare @intNumSigDigits int

	select @intChildCounter=1
	select @intNumChildren=count(*) from ObjHierarchy$ where owner is null
	select @intNumSigDigits=log10(@intNumChildren + 0.5) + 1

	declare curRootObjects cursor FAST_FORWARD for select id from objhierarchy$ where owner is null order by id
	open curRootObjects
	fetch next from curRootObjects into @intId
	while @@fetch_status = 0
	begin
		update ObjHierarchy$ set intDepth=1,
			strDepth=replicate('0', @intNumSigDigits - log10(@intChildCounter + 0.5)) + cast(@intChildCounter as varchar) 
			where id=@intId
		select @intChildCounter=@intChildCounter + 1
		fetch next from curRootObjects into @intId
	end
	close curRootObjects
	deallocate curRootObjects


	--  Determine how many objects there are

	declare @intDepth int
	declare @strDepth varchar(100)

	select @intDepth=2
	select @intNumChildren=count(*) from ObjHierarchy$ where owner in (select id from ObjHierarchy$ where intDepth=1)
	select @intNumSigDigits=log10(@intNumChildren + 0.5) + 1

	while (@intNumChildren > 0)
	begin
		select @intChildCounter=1

		-- This is ordered by FLID and OWNORD so 2 or more owning sequences are not interleaved

		declare curObjects cursor FAST_FORWARD for select c.id, p.strDepth from objhierarchy$ c, objHierarchy$ p where c.owner=p.id and p.intdepth=(select max(intDepth) from ObjHierarchy$ where intDepth is not NULL) order by p.strDepth, c.ownFlid, c.ownOrd, c.id
		open curObjects
		fetch next from curObjects into @intId, @strDepth
		while @@fetch_status = 0
		begin
			update ObjHierarchy$ set intDepth=@intDepth, 
				strDepth=@strDepth + replicate('0', @intNumSigDigits - log10(@intChildCounter + 0.5)) + cast(@intChildCounter as varchar)
				where id=@intId
			select @intChildCounter=@intChildCounter + 1
			fetch next from curObjects into @intId, @strDepth
		end
		close curObjects
		deallocate curObjects

		--  Increment the depth and see if there are more child records
		select @intNumChildren=count(*) from ObjHierarchy$ where owner in (select id from ObjHierarchy$ where intDepth=@intDepth)
		select @intDepth=@intDepth + 1
		if (@@ROWCOUNT = 0 ) return   
		select @intNumSigDigits=log10(@intNumChildren + 0.5) + 1
	end
go


if object_id('dbo.GetStTexts$') is not null
begin
	print 'Removing procedure: GetStTexts$'
	drop proc GetStTexts$
end
go
print 'Creating procedure: GetStTexts$'
go
create proc GetStTexts$
	@uid uniqueidentifier
as
	declare @StTextClassId int

	-- get the StText (structured text) class type
	select	@StTextClassId = id
	from	Class$
	where	name = 'StText'

	-- select the structured text information based on the IDs of class type StText
	select	stp.Src,
		stp.Dst,
		sp.StyleRules,
		sttp.Contents
	from	StText_Paragraphs stp 
			join StPara sp on sp.Id = stp.Dst
			join ObjInfoTbl$ oi  on stp.Src = oi.ObjId 
			left outer join StTxtPara sttp  on sttp.Id = sp.Id
	where	oi.uid = @uid
		and oi.ObjClass = @StTextClassId
go







-- PageSetup$ table.
if not object_id('PageSetup$') is null
  begin print 'removing table PageSetup$' drop table PageSetup$
end
go


-- Strictly speaking, the "Id" column should have a foreign key constraint to the ID column of
-- CmMajorObject but this would make deletions difficult, and a few stray records in this 
-- table won't hurt.
print 'creating table PageSetup$'
go
create table [PageSetup$] (
	[Id] int primary key clustered,
	[MarginLeft] int not null,
	[MarginRight] int not null,
	[MarginTop] int not null,
	[MarginBottom] int not null,
	[MarginHeader] int not null,
	[MarginFooter] int not null,
	[PaperSize] int not null,
	[PaperWidth] int not null,
	[PaperHeight] int not null,
	[Orientation] int not null,
	[Header] nvarchar(400),
	[Header_Fmt] varbinary(400),
	[Footer] nvarchar(400),
	[Footer_Fmt] varbinary(400),
	[PrintFirstHeader] bit
)
go



















if object_id('AlignBinary') is not null
begin
	drop function AlignBinary
end
go
print 'creating function AlignBinary'
go
create function AlignBinary (@b binary(4))
returns binary(4)
as
begin
	declare @New binary(4)

	set @New = substring(@b, 4, 1) + substring(@b, 3, 1) + substring(@b, 2, 1) + substring(@b, 1, 1)
	return @New
end
go
















if object_id('GetRunProp') is not null begin
	print 'removing function GetRunProp'
	drop function GetRunProp
end
go
print 'creating function GetRunProp'
go
create function GetRunProp (@fmt varbinary(8000), @sTxt nvarchar(4000))
returns @t 
	table (	
		iRun 		int		not null, 
		ichMin 		int		not null, 
		ibProp 		int		not null, 
		ictip 		tinyint		null, 
		scp 		int		null,
		rgbTip 		varbinary(8)	null,
		rgbTipNumBytes	tinyint		null,
		ictsp 		tinyint		null,
		cbTsp		int		null,
		rgbTsp		varbinary(8000)	null,
		--( See the notes under string tables in FwCore.sql about the 
		--( COLLATE clause.
		sRunTxt 	NVARCHAR(4000) COLLATE Latin1_General_BIN NOT NULL
	)
as
begin
	declare @nRuns int, @i int, @nFmtLen int, @nPropRegion int
	declare @ichMin int, @ibProp int, @nRunLen int
	declare @ctip tinyint, @iCurrScp tinyint, @scp int, @scpNumBytes tinyint, 
		@rgbTipNumBytes tinyint, @rgbTip bigint
	declare @ctsp tinyint, @iCurrStp tinyint, @cbTsp int, @stpNumBytes tinyint
	declare @NumBytes tinyint, @byteOffset int

	set @nRuns = dbo.AlignBinary(substring(@fmt, 1, 4))
	
	set @i = 0
	set @nFmtLen = len(@fmt)
	set @nPropRegion = 4+@nRuns*8+1

	while @i < @nRuns begin
	
		-- get the character offset into the text region for the current run
		set @ichMin = dbo.AlignBinary(substring(@fmt, 5+@i*8, 4))
		-- get the byte offset into the property region for the current run
		set @ibProp = dbo.AlignBinary(substring(@fmt, 9+@i*8, 4))

		-- get the length of the run
		if @i+1 < @nRuns begin
			set @nRunLen = dbo.AlignBinary(substring(@fmt, 5+(@i+1)*8, 4)) - @ichMin
		end
		else begin
			set @nRunLen = len(@sTxt) - @ichMin
		end

		-- get the number of scalar properties
		set @ctip = convert(tinyint, substring(@fmt, @nPropRegion+@ibProp, 1))
		-- get the number of string properties
		set @ctsp = convert(tinyint, substring(@fmt, @nPropRegion+@ibProp+1, 1))

		-- loop through the scalar properties
		set @iCurrScp = 0
		set @byteOffset = @nPropRegion+@ibProp+2
		while @iCurrScp < @ctip begin

			-- determine how many bytes the scp (scalar property) is stored in
			set @NumBytes = convert(tinyint, substring(@fmt, @byteOffset, 1))
			if (0x00 & @NumBytes = 0x00) or (0x40 & @NumBytes = 0x40) begin -- top bits = 00 or 01
				-- use 1 byte to store 7 significant bits
				set @scpNumBytes = 1
				set @scp = convert(tinyint, @Numbytes) -- @NumBytes contains the first byte 
			end
			else if 0x80 & @NumBytes = 0x80 begin -- top bits = 10 
				-- use 2 bytes to store 14 significant bits
				set @scpNumBytes = 2
				set @scp = convert(smallint, substring(@fmt, @byteOffset+1, 1)+substring(@fmt, @byteOffset, 1)) - 128
			end
			else if 0xc0 & @NumBytes = 0xc0 begin -- top bits = 11
				-- use 5 bytes to store 32 significant bits
				set @scpNumBytes = 5
				set @scp = dbo.AlignBinary(substring(@fmt, @byteOffset, 4)) - 192
			end

			set @byteOffset = @byteOffset + @scpNumBytes

			-- determine how many bytes the rgbTip value is stored in; also subtract the bottom 
			--	2 bits of the first byte of the scp, which are used to specify the rgbTip 
			--	byte length, from the scp value
			set @NumBytes = convert(tinyint, substring(@fmt, @nPropRegion+@ibProp+2, 1))
			if 0x00 & @NumBytes = 0x00 begin
				set @rgbTipNumBytes = 1
			end
			else if 0x01 & @NumBytes = 0x01 begin
				set @rgbTipNumBytes = 2
				set @scp = @scp - 1
			end
			else if 0x02 & @NumBytes = 0x02 begin
				set @rgbTipNumBytes = 4
				set @scp = @scp - 2
			end
			else if 0x03 & @NumBytes = 0x03 begin
				set @rgbTipNumBytes = 8
				set @scp = @scp - 3
			end
			set @rgbTip = substring(@fmt, @byteOffset, @rgbTipNumbytes)

			set @byteOffset = @byteOffset + @rgbTipNumBytes
						
			-- insert the data into the logical table @t
			insert into @t (iRun, ichMin, ibProp, ictip, scp, rgbTip, rgbTipNumBytes, ictsp, cbTsp, rgbTsp, sRunTxt)
				values (@i, @ichMin, @ibProp, @iCurrScp, @scp, @rgbTip,	@rgbTipNumBytes,
					null, null, null, substring(@sTxt, @ichMin+1, @nRunLen)
				)

			set @iCurrScp = @iCurrScp + 1
		end

		-- loop through the string-valued properties
		set @iCurrStp = 0
		while @iCurrStp < @ctsp begin
			
			-- determine how many bytes the stp (string-valued property) is stored in
			set @NumBytes = convert(tinyint, substring(@fmt, @byteOffset, 1))
			if (0x00 & @NumBytes = 0x00) or (0x40 & @NumBytes = 0x40) begin -- top bits = 00 or 01
				-- use 1 byte to store 7 significant bits
				set @stpNumBytes = 1
				set @cbTsp = convert(tinyint, @NumBytes) -- @stpNumBytes contains the first byte 
			end
			else if 0x80 & @NumBytes = 0x80 begin -- top bits = 10 
				-- use 2 bytes to store 14 significant bits
				set @stpNumBytes = 2
				set @cbTsp = convert(smallint, substring(@fmt, @byteOffset+1, 1)+substring(@fmt, @byteOffset, 1)) - 128
			end
			else if 0xc0 & @NumBytes = 0xc0 begin -- top bits = 11
				-- use 5 bytes to store 32 significant bits
				set @stpNumBytes = 4
				set @cbTsp = dbo.AlignBinary(substring(@fmt, @byteOffset, 4)) - 192
			end

			set @byteOffset = @byteOffset + @stpNumBytes

			-- insert the data into the logical table @t
			insert into @t (iRun, ichMin, ibProp, ictip, scp, rgbTip, rgbTipNumBytes, ictsp, cbTsp, rgbTsp, sRunTxt)
				values (@i, @ichMin, @ibProp, null, null, null, null, @iCurrStp, @cbTsp,
					substring(@fmt, @byteOffset, @cbTsp), substring(@sTxt, @ichMin+1, @nRunLen)
				)

			set @byteOffset = @byteOffset + @cbTsp

			set @iCurrStp = @iCurrStp + 1
		end

		-- check to see if there are no scalar or string-valued properties, in which case insert 
		--	the run without any property information
		if @ctsp = 0 and @ctip = 0 begin
			-- insert the data into the logical table @t
			insert into @t (iRun, ichMin, ibProp, ictip, scp, rgbTip, rgbTipNumBytes, ictsp, cbTsp, rgbTsp, sRunTxt)
				values (@i, @ichMin, @ibProp, null, null, null, null, null, null, null,
					substring(@sTxt, @ichMin+1, @nRunLen)
				)
		end

		set @i = @i + 1
	end

	return
end
go


if object_id('IsA') is not null begin
print 'drop function IsA'
	drop function IsA
end
go
print 'creating function IsA'
go
create function IsA
	(@SuperClid int,
	@Clid int)
returns int
as
begin
	return 0
end
go
print 'altering function IsA'
go

-----------------------------------------------------------------------------------------
-- Function: IsA
-- Description: This function checks to see if @SuperClid is a superclass of @Clid.
-- Parameters:	
--    @SuperClid - the class id of the superclass
--    @Clid - the class id of the object
-- Return: 1 if @SuperClid is a superclass of @Clid, otherwise 0.
-----------------------------------------------------------------------------------------
alter function IsA
	(@SuperClid int,
	@Clid int)
returns int
as
begin
	declare @BaseId int, @retVal int

	if (@Clid = 0) return 0	-- CmObject has no superclass.
	if ((@SuperClid < 0) Or (@Clid < 0)) return 0

	set @retVal = 0
	set @BaseId = -1

	-- Check to see if it is the same class.
	if (@SuperClid = @Clid) return 1

	select @BaseId = Base from Class$ where Id=@Clid
	if (@BaseId = -1) return 0	-- Couldn't find @Clid

	if (@BaseId = 0) return 0	-- Have run into CmObject, so quit.

	-- Check to see if superclass is CmObject.
	if (@SuperClid = 0) return 1

	-- Now do it the hard way.
	if (@BaseId = @SuperClid) return 1
	else exec @retVal=dbo.IsA @SuperClid, @BaseId

	return @retVal
end
go
































if exists (select * from sysobjects where name = 'GetOrderedMultiTxt')
	drop proc GetOrderedMultiTxt
go
print 'creating proc GetOrderedMultiTxt'
go

create proc GetOrderedMultiTxt
	@id int,
	@flid int,
 	@anal tinyint = 1
as
	
	declare @fIsNocountOn int
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on
	
	declare 
		@iFieldType int,
		@nvcTable NVARCHAR(60),
		@nvcSql NVARCHAR(4000)
	
	select @iFieldType = [Type] from Field$ where [Id] = @flid
	EXEC GetMultiTableName @flid, @nvcTable OUTPUT

	--== Analysis WritingSystems ==--
	
	if @anal = 1
	begin
		
		-- MultiStr$ --
		if @iFieldType = 14
			select
				isnull(ms.[txt], '***') txt,
				ms.[ws],
				isnull(lpcae.[ord], 99998) [ord]
			from MultiStr$ ms 
			left outer join LgWritingSystem le  on le.[Id] = ms.[ws]
			left outer join LanguageProject_AnalysisWritingSystems lpae  on lpae.[dst] = le.[id]
			left outer join LanguageProject_CurrentAnalysisWritingSystems lpcae  on lpcae.[dst] = lpae.[dst]
			where ms.[obj] = @id and ms.[flid] = @flid
			union all
			select '***', 0, 99999
			order by isnull([ord], 99998)
		
		-- MultiBigStr$ --
		else if @iFieldType = 18
		begin
			--( See note 2 in the header 
			declare @tblMultiBigStrAnalysis table (
				--( See the notes under string tables in FwCore.sql about the 
				--( COLLATE clause.
				Txt NTEXT COLLATE Latin1_General_BIN,
				[ws] int,
				[ord] int primary key)
			
			insert into @tblMultiBigStrAnalysis
			select
				isnull(mbs.[txt], '***') txt,
				mbs.[ws],
				isnull(lpcae.[ord], 99998) [ord]
			from MultiBigStr$ mbs 
			left outer join LgWritingSystem le  on le.[Id] = mbs.[ws]
			left outer join LanguageProject_AnalysisWritingSystems lpae  on lpae.[dst] = le.[id]
			left outer join LanguageProject_CurrentAnalysisWritingSystems lpcae  on lpcae.[dst] = lpae.[dst]
			where mbs.[obj] = @id and mbs.[flid] = @flid
			order by isnull([ord], 99998)
			
			insert into @tblMultiBigStrAnalysis
			select convert(ntext, '***') [txt], 0 [ws], 99999 [ord]

			select * from @tblMultiBigStrAnalysis order by [ord]
		end
		
		-- MultiBigTxt$ --
		else if @iFieldType = 20
		begin
			--( See note 2 in the header 
			declare @tblMultiBigTxtAnalysis table (
				--( See the notes under string tables in FwCore.sql about the 
				--( COLLATE clause.
				Txt NTEXT COLLATE Latin1_General_BIN,
				[ws] int,
				[ord] int primary key)
			
			insert into @tblMultiBigTxtAnalysis
			select
				isnull(mbt.[txt], '***') txt,
				mbt.[ws],
				isnull(lpcae.[ord], 99998) [ord]
			from MultiBigTxt$ mbt 
			left outer join LgWritingSystem le  on le.[Id] = mbt.[ws]
			left outer join LanguageProject_AnalysisWritingSystems lpae  on lpae.[dst] = le.[id]
			left outer join LanguageProject_CurrentAnalysisWritingSystems lpcae  on lpcae.[dst] = lpae.[dst]
			where mbt.[obj] = @id and mbt.[flid] = @flid
			order by isnull([ord], 99998)
			
			insert into @tblMultiBigTxtAnalysis
			select convert(ntext, '***') [txt], 0 [ws], 99999 [ord]

			select * from @tblMultiBigTxtAnalysis order by [ord]
		end
		
		-- MultiTxt$ -- 
		else if @iFieldType = 16 BEGIN
			SET @nvcSql =
				N'select ' + CHAR(13) +
					N'isnull(mt.[txt], ''***'') txt, ' + CHAR(13) +
					N'mt.[ws], ' + CHAR(13) +
					N'isnull(lpcae.[ord], 99998) [ord] ' + CHAR(13) +
				N'from ' + @nvcTable + N' mt  ' + CHAR(13) +
				N'left outer join LgWritingSystem le  on le.[Id] = mt.[ws] ' + CHAR(13) +
				N'left outer join LanguageProject_AnalysisWritingSystems lpae  ' + 
					N'on lpae.[dst] = le.[id] ' + CHAR(13) +
				N'left outer join LanguageProject_CurrentAnalysisWritingSystems lpcae  ' +
					N'on lpcae.[dst] = lpae.[dst] ' + CHAR(13) +
				N'where mt.[obj] = @id ' + CHAR(13) +
				N'union all ' + CHAR(13) +
				N'select ''***'', 0, 99999 ' + CHAR(13) +
				N'order by isnull([ord], 99998) '
			
			EXEC sp_executesql @nvcSql, N'@id INT', @id
		END

	end
	
	--== Vernacular WritingSystems ==--
	
	else if @anal = 0
	begin
		
		-- MultiStr$ --
		if @iFieldType = 14
			select
				isnull(ms.[txt], '***') txt,
				ms.[ws],
				isnull(lpcve.[ord], 99998) [ord]
			from MultiStr$ ms 
			left outer join LgWritingSystem le  on le.[Id] = ms.[ws]
			left outer join LanguageProject_VernacularWritingSystems lpve  on lpve.[dst] = le.[id]
			left outer join LanguageProject_CurrentVernacularWritingSystems lpcve  on lpcve.[dst] = lpve.[dst]
			where ms.[obj] = @id and ms.[flid] = @flid
			union all
			select '***', 0, 99999
			order by isnull([ord], 99998)
		
		-- MultiBigStr$ --
		else if @iFieldType = 18
		begin
			--( See note 2 in the header 
			declare @tblMultiBigStrVernacular table (
				--( See the notes under string tables in FwCore.sql about the 
				--( COLLATE clause.
				Txt NTEXT COLLATE Latin1_General_BIN,
				[ws] int,
				[ord] int primary key)
			
			insert into @tblMultiBigStrVernacular
			select
				isnull(mbs.[txt], '***') txt,
				mbs.[ws],
				isnull(lpcve.[ord], 99998) [ord]
			from MultiBigStr$ mbs 
			left outer join LgWritingSystem le  on le.[Id] = mbs.[ws]
			left outer join LanguageProject_VernacularWritingSystems lpve  on lpve.[dst] = le.[id]
			left outer join LanguageProject_CurrentVernacularWritingSystems lpcve  on lpcve.[dst] = lpve.[dst]
			where mbs.[obj] = @id and mbs.[flid] = @flid
			order by isnull([ord], 99998)
			
			insert into @tblMultiBigStrVernacular
			select convert(ntext, '***') [txt], 0 [ws], 99999 [ord]

			select * from @tblMultiBigStrVernacular order by [ord]
		end
		
		-- MultiBigTxt$ --
		else if @iFieldType = 20
		begin
			--( See note 2 in the header 
			declare @tblMultiBigTxtVernacular table (
				--( See the notes under string tables in FwCore.sql about the 
				--( COLLATE clause.
				Txt NTEXT COLLATE Latin1_General_BIN,
				[ws] int,
				[ord] int primary key)
			
			insert into @tblMultiBigTxtVernacular
			select
				isnull(mbt.[txt], '***') txt,
				mbt.[ws],
				isnull(lpcve.[ord], 99998) [ord]
			from MultiBigTxt$ mbt 
			left outer join LgWritingSystem le  on le.[Id] = mbt.[ws]
			left outer join LanguageProject_VernacularWritingSystems lpve  on lpve.[dst] = le.[id]
			left outer join LanguageProject_CurrentVernacularWritingSystems lpcve  on lpcve.[dst] = lpve.[dst]
			where mbt.[obj] = @id and mbt.[flid] = @flid
			order by isnull([ord], 99998)
			
			insert into @tblMultiBigTxtVernacular
			select convert(ntext, '***') [txt], 0 [ws], 99999 [ord]

			select * from @tblMultiBigTxtVernacular order by [ord]
		end
		
		-- MultiTxt$ --
		else if @iFieldType = 16 BEGIN
			SET @nvcSql =
				N' select ' + CHAR(13) +
					N'isnull(mt.[txt], ''***'') txt, ' + CHAR(13) +
					N'mt.[ws], ' + CHAR(13) +
					N'isnull(lpcve.[ord], 99998) ord ' + CHAR(13) +
				N'from ' + @nvcTable + N' mt  ' + CHAR(13) +
				N'left outer join LgWritingSystem le  on le.[Id] = mt.[ws] ' + CHAR(13) +
				N'left outer join LanguageProject_VernacularWritingSystems lpve  ' + 
					N'on lpve.[dst] = le.[id] ' + CHAR(13) +
				N'left outer join LanguageProject_CurrentVernacularWritingSystems lpcve  ' + 
					N'on lpcve.[dst] = lpve.[dst] ' + CHAR(13) +
				N'where mt.[obj] = @id ' + CHAR(13) +
				N'union all ' + CHAR(13) +
				N'select ''***'', 0, 99999 ' + CHAR(13) +
				N'order by isnull([ord], 99998) ' 
			
			EXEC sp_executesql @nvcSql, N'@id INT', @id
		END
	end
	else
		raiserror('@anal flag not set correctly', 16, 1) 
		goto LFail

	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

LFail: 
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off
	go

































if object_id('GetOrderedMultiTxtXml$') is not null begin
	print 'removing procedure GetOrderedMultiTxtXml$'
	drop proc [GetOrderedMultiTxtXml$]
end
go
print 'creating proc GetOrderedMultiTxtXml$'
go

create proc GetOrderedMultiTxtXml$
	@hXMLDocObjList int = null,
	@iFlid int,
 	@tiAnal tinyint = 1
as
	
	declare @fIsNocountOn int
	set @fIsNocountOn = @@options & 512
	if @fIsNocountOn = 0 set nocount on
	
	DECLARE
		@nvcTable NVARCHAR(60),
		@nvcSql NVARCHAR(4000)
	
	EXEC GetMultiTableName @iflid, @nvcTable OUTPUT
	
	if @tiAnal = 1 BEGIN
		
		SET @nvcSql = N'select ' + CHAR(13) +
			N'ids.[Id], ' + CHAR(13) +
			N'isnull((select top 1 isnull(mt.[txt], ''***'') ' + CHAR(13) +
 				N'from ' + @nvcTable + N' mt  ' + CHAR(13) +
 				N'left outer join LgWritingSystem le  on le.[Id] = mt.[ws] ' + CHAR(13) +
 				N'left outer join LanguageProject_AnalysisWritingSystems lpae  ' +
					N'on lpae.[dst] = le.[id] ' + CHAR(13) +
 				N'left outer join LanguageProject_CurrentAnalysisWritingSystems lpcae  ' + 
					N'on lpcae.[dst] = lpae.[dst] ' + CHAR(13) +
				N'where mt.[obj] = ids.[Id] ' + CHAR(13) +
 				N'order by isnull(lpcae.[ord], 99999)), ''***'') as [txt] , ' + CHAR(13) +
			N'isnull((select top 1 isnull(mt.[ws], 0) ' + CHAR(13) +
 				N'from ' + @nvcTable + N' mt  ' + CHAR(13) +
 				N'left outer join LgWritingSystem le  on le.[Id] = mt.[ws] ' + CHAR(13) +
 				N'left outer join LanguageProject_AnalysisWritingSystems lpae  ' + 
					N' on lpae.[dst] = le.[id] ' + CHAR(13) +
 				N'left outer join LanguageProject_CurrentAnalysisWritingSystems lpcae  ' + 
					N'on lpcae.[dst] = lpae.[dst] ' + CHAR(13) +
				N'where mt.[obj] = ids.[Id] ' + CHAR(13) +
 				N'order by isnull(lpcae.[ord], 99999)), 0) as [ws] ' + CHAR(13) +
			N'from openxml (@hXMLDocObjList, ''/root/Obj'') with ([Id] int) ids '
			
		EXEC sp_executesql @nvcSql, N'@hXMLDocObjList INT', @hXMLDocObjList
	END
	else if @tiAnal = 0 BEGIN
		
		SET @nvcSql = N'select ' + CHAR(13) +
			N'ids.[Id], ' + CHAR(13) +
			N'isnull((select top 1 isnull(mt.[txt], ''***'') as [txt] ' + CHAR(13) +
 				N'from ' + @nvcTable + N' mt  ' + CHAR(13) +
 				N'left outer join LgWritingSystem le  on le.[Id] = mt.[ws] ' + CHAR(13) +
 				N'left outer join LanguageProject_VernacularWritingSystems lpve  ' +
					N'on lpve.[dst] = le.[id] ' + CHAR(13) +
 				N'left outer join LanguageProject_CurrentVernacularWritingSystems lpcve  ' + 
					N'on lpcve.[dst] = lpve.[dst] ' + CHAR(13) +
				N'where mt.[obj] = ids.[Id] ' + CHAR(13) +
 				N'order by isnull(lpcve.[ord], 99999)), ''***'') , ' + CHAR(13) +
			N'isnull((select top 1 isnull(mt.[ws], 0) as [ws] ' + CHAR(13) +
 				N'from ' + @nvcTable + N' mt  ' + CHAR(13) +
 				N'left outer join LgWritingSystem le  on le.[Id] = mt.[ws] ' + CHAR(13) +
 				N'left outer join LanguageProject_VernacularWritingSystems lpve  ' +
					N'on lpve.[dst] = le.[id] ' + CHAR(13) +
 				N'left outer join LanguageProject_CurrentVernacularWritingSystems lpcve  ' + 
					N'on lpcve.[dst] = lpve.[dst] ' + CHAR(13) +
				N'where mt.[obj] = ids.[Id] ' + CHAR(13) +
 				N'order by isnull(lpcve.[ord], 99999)), 0) ' + CHAR(13) +
			N'from openxml (@hXMLDocObjList, ''/root/Obj'') with ([Id] int) ids '
		
		EXEC sp_executesql @nvcSql, N'@hXMLDocObjList INT', @hXMLDocObjList
	END
	else begin
		raiserror('@tiAnal flag not set correctly', 16, 1) 
		goto LFail
	end
	
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

LFail: 
	-- if nocount was turned on turn it off
	if @fIsNocountOn = 0 set nocount off

go



















IF OBJECT_ID('TR_CmSortSpec_Ins') IS NOT NULL BEGIN
	PRINT 'removing trigger TR_CmSortSpec_Ins'
	DROP TRIGGER [TR_CmSortSpec_Ins]
END
GO
PRINT 'creating trigger TR_CmSortSpec_Ins'
GO
CREATE TRIGGER [TR_CmSortSpec_Ins] ON CmSortSpec FOR INSERT
AS
	
	DECLARE
		@nvcPrimary NVARCHAR(4000),
		@nvcSecondary NVARCHAR(4000),
		@nvcTertiary NVARCHAR(4000),
		@nID INT
	
	DECLARE curCmSortSpecIns CURSOR LOCAL STATIC FORWARD_ONLY READ_ONLY FOR
		SELECT [PrimaryField], [SecondaryField], [TertiaryField] FROM Inserted
	
	OPEN curCmSortSpecIns
	FETCH curCmSortSpecIns INTO @nvcPrimary, @nvcSecondary, @nvcTertiary
	WHILE @@FETCH_STATUS = 0 BEGIN
		
		SET @nID = dbo.fnGetLastCommaDelimID$(@nvcPrimary)
		EXEC CreateFlidCollations NULL, NULL, @nID
		
		SET @nID = dbo.fnGetLastCommaDelimID$(@nvcSecondary)
		EXEC CreateFlidCollations NULL, NULL, @nID
		
		SET @nID = dbo.fnGetLastCommaDelimID$(@nvcTertiary)
		EXEC CreateFlidCollations NULL, NULL, @nID		
		
		FETCH curCmSortSpecIns INTO @nvcPrimary, @nvcSecondary, @nvcTertiary
	END
	CLOSE curCmSortSpecIns
	DEALLOCATE curCmSortSpecIns
	
GO















IF OBJECT_ID('TR_CmSortSpec_Del') IS NOT NULL BEGIN
	PRINT 'removing trigger TR_CmSortSpec_Del'
	DROP TRIGGER [TR_CmSortSpec_Del]
END
GO
PRINT 'creating trigger TR_CmSortSpec_Del'
GO
CREATE TRIGGER [TR_CmSortSpec_Del] ON CmSortSpec FOR DELETE
AS
	
	DECLARE
		@nvcPrimary NVARCHAR(4000),
		@nvcSecondary NVARCHAR(4000),
		@nvcTertiary NVARCHAR(4000),
		@nID INT,
		@nFlid INT
	
	DECLARE curCmSortSpecDel CURSOR LOCAL STATIC FORWARD_ONLY READ_ONLY FOR
		SELECT [PrimaryField], [SecondaryField], [TertiaryField] FROM Deleted
	
	OPEN curCmSortSpecDel
	FETCH curCmSortSpecDel INTO @nvcPrimary, @nvcSecondary, @nvcTertiary
	WHILE @@FETCH_STATUS = 0 BEGIN
		
		-- this needs to work
		SELECT TOP 1 [PrimaryWs] FROM [CmSortSpec] WHERE [PrimaryWs] = @nFlid
		UNION
		SELECT TOP 1 [SecondaryWs] FROM [CmSortSpec] WHERE [SecondaryWs] = @nFlid
		UNION
		SELECT TOP 1 [TertiaryWs] FROM [CmSortSpec] WHERE [TertiaryWs] = @nFlid
		
		IF @@ROWCOUNT = 0
		SET @nID = dbo.fnGetLastCommaDelimID$(@nvcPrimary)
		EXEC DeleteFlidCollations NULL, NULL, @nID
		
		FETCH curCmSortSpecIns INTO @nvcPrimary, @nvcSecondary, @nvcTertiary
	END
	CLOSE curCmSortSpecDel
	DEALLOCATE curCmSortSpecDel
	
GO














IF OBJECT_ID('TR_CmSortSpec_Upd') IS NOT NULL BEGIN
	PRINT 'removing trigger TR_CmSortSpec_Upd'
	DROP TRIGGER [TR_CmSortSpec_Upd]
END
GO
PRINT 'creating trigger TR_CmSortSpec_Upd'
GO
CREATE TRIGGER [TR_CmSortSpec_Upd] ON CmSortSpec FOR INSERT
AS
	
	DECLARE
		@nvcPrimaryIns NVARCHAR(4000),
		@nvcSecondaryIns NVARCHAR(4000),
		@nvcTertiaryIns NVARCHAR(4000),
		@nvcPrimaryDel NVARCHAR(4000),
		@nvcSecondaryDel NVARCHAR(4000),
		@nvcTertiaryDel NVARCHAR(4000),
		@nID INT
	
	DECLARE curCmSortSpecIns CURSOR LOCAL STATIC FORWARD_ONLY READ_ONLY FOR
		SELECT
			ins.[PrimaryField] AS [PrimaryIns], 
			ins.[SecondaryField] AS [SecondaryIns],
			ins.[TertiaryField] AS [TertiaryIns],
			del.[PrimaryField] AS [PrimaryDel], 
			del.[SecondaryField] AS [SecondaryDel],
			del.[TertiaryField] AS [TertiaryDel]
		FROM Inserted ins
		JOIN Deleted del ON del.[ID] = ins.[Id]
	
	OPEN curCmSortSpecIns
	FETCH curCmSortSpecIns INTO
		@nvcPrimaryIns,
		@nvcSecondaryIns,
		@nvcTertiaryIns,
		@nvcPrimaryDel,
		@nvcSecondaryDel,
		@nvcTertiaryDel
	WHILE @@FETCH_STATUS = 0 BEGIN
		
		IF @nvcPrimaryIns IS NOT NULL AND @nvcPrimaryDel IS NULL BEGIN
			-- insert new
			SET @nId = NULL  --dummy line to make the compiler happy
		END
		ELSE IF @nvcPrimaryIns IS NULL AND @nvcPrimaryDel IS NOT NULL BEGIN
			-- delete old one
			SET @nId = NULL  --dummy line to make the compiler happy
		END
		ELSE IF @nvcPrimaryIns <> @nvcPrimaryDel BEGIN
			SET @nID = dbo.fnGetLastCommaDelimID$(@nvcPrimaryIns)
			EXEC CreateFlidCollations NULL, NULL, @nID
		END
		---
			SET @nID = dbo.fnGetLastCommaDelimID$(@nvcSecondaryIns)
			EXEC CreateFlidCollations NULL, NULL, @nID
	
			SET @nID = dbo.fnGetLastCommaDelimID$(@nvcTertiaryIns)
			EXEC CreateFlidCollations NULL, NULL, @nID		
		
		FETCH curCmSortSpecIns INTO @nvcPrimaryIns, @nvcSecondaryIns, @nvcTertiaryIns
	END
	CLOSE curCmSortSpecIns
	DEALLOCATE curCmSortSpecIns
	
GO
















IF object_id('TR_StTxtPara_Owner_Ins') IS NOT NULL BEGIN
	PRINT 'removing trigger TR_StTxtPara_Owner_Ins'
	DROP TRIGGER [TR_StTxtPara_Owner_Ins]
END
GO
PRINT 'creating trigger TR_StTxtPara_Owner_Ins'
GO

CREATE TRIGGER [TR_StTxtPara_Owner_Ins] on [StTxtPara] FOR INSERT
AS
	DECLARE @iErr INT, @fIsNocountOn INT
	
	SET @fIsNocountOn = @@options & 512
	IF @fIsNocountOn = 0 SET NOCOUNT ON
	
	UPDATE owner
		SET [UpdDttm] = getdate()
		FROM inserted ins
		JOIN [CmObject] AS owned ON owned.[Id] = ins.[Id]
		JOIN [CmObject] AS owner ON owner.[Id] = owned.Owner$
	
	UPDATE grandowner
		SET [UpdDttm] = getdate()
		FROM inserted ins
		JOIN [CmObject] AS owned ON owned.[Id] = ins.[Id]
		JOIN [CmObject] AS owner ON owner.[Id] = owned.Owner$
		JOIN [CmObject] AS grandowner ON grandowner.[Id] = owner.Owner$
	
	SET @iErr = @@error
	IF @iErr <> 0 GOTO LFail

	IF @fIsNocountOn = 0 SET NOCOUNT OFF
	RETURN

LFail:
	ROLLBACK TRAN
	IF @fIsNocountOn = 0 SET NOCOUNT OFF
	Raiserror ('TR_StTxtPara_Owner_Ins: SQL Error %d; Unable to insert rows into the StTxtPara.', 16, 1, @iErr)
	RETURN
GO
















IF object_id('TR_StTxtPara_Owner_UpdDel') IS NOT NULL BEGIN
	PRINT 'removing trigger TR_StTxtPara_Owner_UpdDel'
	DROP TRIGGER [TR_StTxtPara_Owner_UpdDel]
END
GO
PRINT 'creating trigger TR_StTxtPara_Owner_UpdDel'
GO

CREATE TRIGGER [TR_StTxtPara_Owner_UpdDel] on [StTxtPara] FOR UPDATE, DELETE
AS
	DECLARE @iErr INT, @fIsNocountOn INT
	
	SET @fIsNocountOn = @@options & 512
	IF @fIsNocountOn = 0 SET NOCOUNT ON
	
	UPDATE owner
		SET [UpdDttm] = getdate()
		FROM deleted del
		JOIN [CmObject] AS owned ON owned.[Id] = del.[Id]
		JOIN [CmObject] AS owner ON owner.[Id] = owned.Owner$
	
	UPDATE grandowner
		SET [UpdDttm] = getdate()
		FROM deleted del
		JOIN [CmObject] AS owned ON owned.[Id] = del.[Id]
		JOIN [CmObject] AS owner ON owner.[Id] = owned.Owner$
		JOIN [CmObject] AS grandowner ON grandowner.[Id] = owner.Owner$
	
	SET @iErr = @@error
	IF @iErr <> 0 GOTO LFail

	IF @fIsNocountOn = 0 SET NOCOUNT OFF
	RETURN

LFail:
	ROLLBACK TRAN
	IF @fIsNocountOn = 0 SET NOCOUNT OFF
	Raiserror ('TR_StTxtPara_Owner_UpdDel: SQL Error %d; Unable to insert rows into the StTxtPara.', 16, 1, @iErr)
	RETURN
GO
















IF object_id('TR_StPara_Owner_Ins') IS NOT NULL BEGIN
	PRINT 'removing trigger TR_StPara_Owner_Ins'
	DROP TRIGGER [TR_StPara_Owner_Ins]
END
GO
PRINT 'creating trigger TR_StPara_Owner_Ins'
GO

CREATE TRIGGER [TR_StPara_Owner_Ins] on [StPara] FOR INSERT
AS
	DECLARE @iErr INT, @fIsNocountOn INT
	
	SET @fIsNocountOn = @@options & 512
	IF @fIsNocountOn = 0 SET NOCOUNT ON
	
	UPDATE owner
		SET [UpdDttm] = getdate()
		FROM inserted ins
		JOIN [CmObject] AS owned ON owned.[Id] = ins.[Id]
		JOIN [CmObject] AS owner ON owner.[Id] = owned.Owner$
	
	UPDATE grandowner
		SET [UpdDttm] = getdate()
		FROM inserted ins
		JOIN [CmObject] AS owned ON owned.[Id] = ins.[Id]
		JOIN [CmObject] AS owner ON owner.[Id] = owned.Owner$
		JOIN [CmObject] AS grandowner ON grandowner.[Id] = owner.Owner$
	
	SET @iErr = @@error
	IF @iErr <> 0 GOTO LFail

	IF @fIsNocountOn = 0 SET NOCOUNT OFF
	RETURN

LFail:
	ROLLBACK TRAN
	IF @fIsNocountOn = 0 SET NOCOUNT OFF
	Raiserror ('TR_StPara_Owner_Ins: SQL Error %d; Unable to insert rows into the StPara.', 16, 1, @iErr)
	RETURN
















IF object_id('TR_StPara_Owner_UpdDel') IS NOT NULL BEGIN
	PRINT 'removing trigger TR_StPara_Owner_UpdDel'
	DROP TRIGGER [TR_StPara_Owner_UpdDel]
END
GO
PRINT 'creating trigger TR_StPara_Owner_UpdDel'
GO

CREATE TRIGGER [TR_StPara_Owner_UpdDel] on [StPara] FOR UPDATE, DELETE
AS
	DECLARE @iErr INT, @fIsNocountOn INT
	
	SET @fIsNocountOn = @@options & 512
	IF @fIsNocountOn = 0 SET NOCOUNT ON
	
	UPDATE owner
		SET [UpdDttm] = getdate()
		FROM deleted del
		JOIN [CmObject] AS owned ON owned.[Id] = del.[Id]
		JOIN [CmObject] AS owner ON owner.[Id] = owned.Owner$
	
	UPDATE grandowner
		SET [UpdDttm] = getdate()
		FROM deleted del
		JOIN [CmObject] AS owned ON owned.[Id] = del.[Id]
		JOIN [CmObject] AS owner ON owner.[Id] = owned.Owner$
		JOIN [CmObject] AS grandowner ON grandowner.[Id] = owner.Owner$
	
	SET @iErr = @@error
	IF @iErr <> 0 GOTO LFail

	IF @fIsNocountOn = 0 SET NOCOUNT OFF
	RETURN

LFail:
	ROLLBACK TRAN
	IF @fIsNocountOn = 0 SET NOCOUNT OFF
	Raiserror ('TR_StPara_Owner_UpdDel: SQL Error %d; Unable to insert rows into the StPara.', 16, 1, @iErr)
	RETURN
	










IF object_id('TR_StText_Owner_Ins') IS NOT NULL BEGIN
	PRINT 'removing trigger TR_StText_Owner_Ins'
	DROP TRIGGER [TR_StText_Owner_Ins]
END
GO
PRINT 'creating trigger TR_StText_Owner_Ins'
GO

CREATE TRIGGER [TR_StText_Owner_Ins] on [StText] FOR INSERT
AS
	DECLARE @iErr INT, @fIsNocountOn INT
	
	SET @fIsNocountOn = @@options & 512
	IF @fIsNocountOn = 0 SET NOCOUNT ON
	
	UPDATE owner
		SET [UpdDttm] = getdate()
		FROM inserted ins
		JOIN [CmObject] AS owned ON owned.[Id] = ins.[Id]
		JOIN [CmObject] AS owner ON owner.[Id] = owned.Owner$
	
	SET @iErr = @@error
	IF @iErr <> 0 GOTO LFail

	IF @fIsNocountOn = 0 SET NOCOUNT OFF
	RETURN

LFail:
	ROLLBACK TRAN
	IF @fIsNocountOn = 0 SET NOCOUNT OFF
	Raiserror ('TR_StText_Owner_Ins: SQL Error %d; Unable to insert rows into the StText.', 16, 1, @iErr)
	RETURN











IF object_id('TR_StText_Owner_UpdDel') IS NOT NULL BEGIN
	PRINT 'removing trigger TR_StText_Owner_UpdDel'
	DROP TRIGGER [TR_StText_Owner_UpdDel]
END
GO
PRINT 'creating trigger TR_StText_Owner_UpdDel'
GO

CREATE TRIGGER [TR_StText_Owner_UpdDel] on [StText] FOR UPDATE, DELETE
AS
	DECLARE @iErr INT, @fIsNocountOn INT
	
	SET @fIsNocountOn = @@options & 512
	IF @fIsNocountOn = 0 SET NOCOUNT ON
	
	UPDATE owner
		SET [UpdDttm] = getdate()
		FROM deleted del
		JOIN [CmObject] AS owned ON owned.[Id] = del.[Id]
		JOIN [CmObject] AS owner ON owner.[Id] = owned.Owner$
	
	SET @iErr = @@error
	IF @iErr <> 0 GOTO LFail

	IF @fIsNocountOn = 0 SET NOCOUNT OFF
	RETURN

LFail:
	ROLLBACK TRAN
	IF @fIsNocountOn = 0 SET NOCOUNT OFF
	Raiserror ('TR_StText_Owner_UpdDel: SQL Error %d; Unable to insert rows into the StText.', 16, 1, @iErr)
	RETURN










print '**************************** Loading NotebkSP.sql ****************************'
go
















if object_id('fnGetAddedNotebookObjects$') is not null begin
	print 'removing function fnGetAddedNotebookObjects$'
	drop function [fnGetAddedNotebookObjects$]
end
go
print 'creating function fnGetAddedNotebookObjects$'
go
create function [fnGetAddedNotebookObjects$] ()
returns @DelList table ([ObjId] int not null)
as
begin
	declare @nRowCnt int
	declare @nOwnerDepth int
	declare @Err int
	set @nOwnerDepth = 1
	set @Err = 0

	insert into @DelList
	select [Id] from CmObject 
	where OwnFlid$ = 4001001

	-- use a table variable to hold the possibility list item object ids
	declare @PossItems table (
		[ObjId] int primary key not null,
		[OwnerDepth] int null,
		[DateCreated] datetime null
	)

	-- Get the object ids for all of the possibility items in the lists used by Data Notebook
	-- (except for the Anthropology List, which is loaded separately).
	-- Note the hard-wired sets of possibility list flids.
	-- First, get the top-level possibility items from the standard data notebook lists.

	insert into @PossItems (ObjId, OwnerDepth, DateCreated)
	select co.[Id], @nOwnerDepth, cp.DateCreated
	from [CmObject] co 
	join [CmPossibility] cp  on cp.[id] = co.[id]
	join CmObject co2 on co2.[id] = co.Owner$ and co2.OwnFlid$ in (
			4001003,
			6001025,
			6001026,
			6001027,
			6001028,
			6001029,
			6001030,
			6001031,
			6001032,
			6001033,
			6001036
			)

	if @@error <> 0 goto LFail
	set @nRowCnt=@@rowcount

	-- Repeatedly get the list items owned at the next depth.

	while @nRowCnt > 0 begin	
		set @nOwnerDepth = @nOwnerDepth + 1

		insert into @PossItems (ObjId, OwnerDepth, DateCreated)
		select co.[id], @nOwnerDepth, cp.DateCreated
		from [CmObject] co 
		join [CmPossibility] cp  on cp.[id] = co.[id]
		join @PossItems pi on pi.[ObjId] = co.[Owner$] and pi.[OwnerDepth] = @nOwnerDepth - 1

		if @@error <> 0 goto LFail
		set @nRowCnt=@@rowcount
	end

	-- Extract all the items which are newer than the language project, ie, which cannot be
	-- factory list items.
	-- Omit list items which are owned by other non-factory list items, since they will be
	-- deleted by deleting their owner.

	insert into @DelList
	select pi.ObjId
	from @PossItems pi
	join CmObject co  on co.[id] = pi.ObjId
	where pi.DateCreated > (select top 1 DateCreated from CmProject order by DateCreated DESC)

	delete from @PossItems

	-- Get the object ids for all of the possibility items in the anthropology list.
	-- First, get the top-level possibility items from the anthropology list.

	set @nOwnerDepth = 1

	insert into @PossItems (ObjId, OwnerDepth, DateCreated)
	select co.[Id], @nOwnerDepth, cp.DateCreated
	from [CmObject] co 
	join [CmPossibility] cp  on cp.[id] = co.[id]
	where co.[Owner$] in (select id from CmObject  where OwnFlid$ = 6001012)

	set @nRowCnt=@@rowcount
	if @@error <> 0 goto LFail

	-- Repeatedly get the anthropology list items owned at the next depth.

	while @nRowCnt > 0 begin	
		set @nOwnerDepth = @nOwnerDepth + 1

		insert into @PossItems (ObjId, OwnerDepth, DateCreated)
		select co.[id], @nOwnerDepth, cp.DateCreated
		from [CmObject] co 
		join [CmPossibility] cp  on cp.[id] = co.[id]
		join @PossItems pi on pi.[ObjId] = co.[Owner$] and pi.[OwnerDepth] = @nOwnerDepth - 1

		if @@error <> 0 goto LFail
		set @nRowCnt=@@rowcount
	end

	declare @cAnthro int
	declare @cTimes int
	select @cAnthro = COUNT(*) from @PossItems
	select @cTimes = COUNT(distinct DateCreated) from @PossItems

	if @cTimes = @cAnthro begin
		-- Assume that none of them are factory if they all have different creation
		-- times.  This is true even if there's only one item.
		insert into @DelList
		select pi.ObjId
		from @PossItems pi
		where pi.OwnerDepth = 1
	end
	else if @cTimes != 1 begin
		-- assume that the oldest items are factory, the rest aren't
		insert into @DelList
		select pi.ObjId
		from @PossItems pi
		where pi.DateCreated > (select top 1 DateCreated from @PossItems order by DateCreated)
	end

return

LFail:
	delete from @DelList
	return
end
go














if object_id('DeleteAddedNotebookObjects$') is not null begin
	print 'removing proc DeleteAddedNotebookObjects$'
	drop proc [DeleteAddedNotebookObjects$]
end
go
print 'creating proc DeleteAddedNotebookObjects$'
go
create proc [DeleteAddedNotebookObjects$]
as
	declare @Err int
	set @Err = 0

	-- determine if the procedure was called within a transaction;
	-- if yes then create a savepoint, otherwise create a transaction
	declare @nTrnCnt int
	set @nTrnCnt = @@trancount
	if @nTrnCnt = 0 begin tran DelObj$_Tran
	else save tran DelObj$_Tran
	set @Err = @@error
	if @Err <> 0 begin
		raiserror ('DeleteAddedNotebookObjects$: SQL Error %d; Unable to create a transaction.', 16, 1, @Err)
		goto LFail
	end	

	-- delete the objects (records and list items) added to the data notebook
	-- first, build an XML string containing all of the object ids

	declare @ObjId int
	declare @vcXml varchar(8000)
	declare @cObj int
	set @vcXml = '<root>'
	set @cObj = 0
	declare @hdoc int
	
	DECLARE curObj CURSOR FOR SELECT [ObjId] FROM dbo.fnGetAddedNotebookObjects$()
	OPEN curObj
	FETCH NEXT FROM curObj INTO @ObjId
	WHILE @@FETCH_STATUS = 0
	BEGIN
		set @vcXml = @vcXml + '<Obj Id="'+ cast(@ObjId as varchar(10)) + '"/>'
		set @cObj = @cObj + 1
		if len(@vcXml) > 7970 begin
			-- we are close to filling the string, so convert the string into an "XML document",
			-- and delete all the objects (in one swell foop).
			set @vcXml = @vcXml + '</root>'
			exec sp_xml_preparedocument @hdoc output, @vcXml
			exec @Err = DeleteObj$ null,@hdoc
			exec sp_xml_removedocument @hdoc
			set @vcXml = '<root>'
			set @cObj = 0
			if @Err <> 0 goto LFail
		end
		FETCH NEXT FROM curObj INTO @ObjId
	END
	CLOSE curObj
	DEALLOCATE curObj

	if @cObj <> 0 begin
		set @vcXml = @vcXml + '</root>'
		-- now, convert the string into an "XML document", and delete all the objects
		-- (in one swell foop).
		exec sp_xml_preparedocument @hdoc output, @vcXml
		exec @Err = DeleteObj$ null,@hdoc
		exec sp_xml_removedocument @hdoc
		if @Err <> 0 goto LFail
	end

	if @nTrnCnt = 0 commit tran DelObj$_Tran

	return 0

LFail:
	rollback tran DelObj$_Tran
	return @Err
go

print '*********************** Finished loading NotebkSP.sql ************************'
go

