namespace Helpers {
    public class Log {
        public static void Debug(string msg) {
        }
    }
}
