Imports System

Public Class MainApp
    Shared Sub Main()
        Console.WriteLine("Hello World using VB.NET")
        Return
    End Sub
End Class
