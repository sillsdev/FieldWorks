using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;

namespace $rootnamespace$
{
	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// 
	/// </summary>
    /// ----------------------------------------------------------------------------------------
	[TestFixture]
	public class $safeitemname$
	{
		///--------------------------------------------------------------------------------------
		/// <summary>
		/// Tests the method Foo.
		/// </summary>
		///--------------------------------------------------------------------------------------
		[Test]
		public void Foo()
		{
		}
	}
}
