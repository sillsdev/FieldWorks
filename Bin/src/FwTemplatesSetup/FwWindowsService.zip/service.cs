// ---------------------------------------------------------------------------------------------
#region // Copyright (c) $year$, SIL International. All Rights Reserved.   
// <copyright from='$year$' to='$year$' company='SIL International'>
//		Copyright (c) $year$, SIL International. All Rights Reserved.   
//    
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
// 
// File: $itemname$.cs
// Responsibility: $full_username$
// 
// <remarks>
// </remarks>
// ---------------------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;
using System.Text;

namespace $rootnamespace$
{
	/// ----------------------------------------------------------------------------------------
	/// <summary>
	/// 
	/// </summary>
    /// ----------------------------------------------------------------------------------------
	partial class $safeitemrootname$: ServiceBase
	{
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Initializes a new instance of the <see cref="T:$safeitemrootname$"/> class.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public $safeitemrootname$()
		{
			InitializeComponent();
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// When implemented in a derived class, executes when a Start command is sent to the 
		/// service by the Service Control Manager (SCM) or when the operating system starts 
		/// (for a service that starts automatically). Specifies actions to take when the 
		/// service starts.
		/// </summary>
		/// <param name="args">Data passed by the start command.</param>
		/// ------------------------------------------------------------------------------------
		protected override void OnStart(string[] args)
		{
			// TODO: Add code here to start your service.
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// When implemented in a derived class, executes when a Stop command is sent to the 
		/// service by the Service Control Manager (SCM). Specifies actions to take when a 
		/// service stops running.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		protected override void OnStop()
		{
			// TODO: Add code here to perform any tear-down necessary to stop your service.
		}
	}
}
