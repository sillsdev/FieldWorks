This file contains FileMap-2.0.2 with some bugs fixed by EberhardB.

FileMap can be downloaded from http://www.winterdom.com/dev/dotnet/index.html.

It is a simple library that wraps the Win32 Memory Mapped File services.