using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.IO;
using System.Security;
using System.Runtime.Remoting;
using System.Runtime.InteropServices;
using System.Reflection;

namespace RunAsUser
{
	class Program
	{
		[DllImport("Kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		extern static public uint GetTempFileName(string lpPathName, string lpPrefixString,
			uint uUnique, StringBuilder lpTempFileName);

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Runs the specified application with specified args. The service "CompileService"
		/// is required. For an explanation why we do this see the comment on RunApp class.
		/// </summary>
		/// <param name="args">The args.</param>
		/// <returns>-2 if we get an exception, otherwise return value of external app.</returns>
		/// ------------------------------------------------------------------------------------
		static int Main(string[] args)
		{
			RemotingConfiguration.Configure(Assembly.GetExecutingAssembly().Location + ".config",
				true);
			string tempFolder = Path.Combine(Environment.GetEnvironmentVariable("windir"),
				"Temp");
			StringBuilder sb = new StringBuilder(260);
			if (GetTempFileName(tempFolder, "RUN", 0, sb) == 0)
				throw new ApplicationException("Creation of temp file failed");

			string fileName = sb.ToString();
			try
			{
				CompileService.RunApp runApp = new CompileService.RunApp();
				int nRet = runApp.Run(args, Directory.GetCurrentDirectory(), fileName);
				using (StreamReader reader = File.OpenText(fileName))
					Console.WriteLine(reader.ReadToEnd());
				return nRet;
			}
			catch (Exception e)
			{
				Console.WriteLine("Got exception in RunAsUser: " + e.Message);
				return -2;
			}
			finally
			{
				try
				{
					File.Delete(fileName);
				}
				catch
				{
				}
			}
		}
	}
}
