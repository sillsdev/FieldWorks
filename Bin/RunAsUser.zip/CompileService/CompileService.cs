using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;
using System.Text;
using System.Runtime.Remoting;
using System.Reflection;

namespace CompileService
{
	public partial class CompileService : ServiceBase
	{
		public CompileService()
		{
			InitializeComponent();
		}

		protected override void OnStart(string[] args)
		{
			RemotingConfiguration.Configure(Assembly.GetExecutingAssembly().Location + ".config",
				true);
		}

		protected override void OnStop()
		{
			// TODO: Add code here to perform any tear-down necessary to stop your service.
		}
	}
}
