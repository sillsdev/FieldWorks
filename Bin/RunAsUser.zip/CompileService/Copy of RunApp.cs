using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;
using System.Threading;

namespace CompileService
{
	public class RunApp : MarshalByRefObject
	{
		private StringBuilder m_bldr;
		private Process m_process;
		private Hashtable m_htThreadStream = new Hashtable();

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Runs the application specified as first element in args, passing the remaining
		/// string in args as arguments. This class gets called from RunAsUser.exe, and it runs
		/// as a service with permissions of a local user. This is a workaround for a Microsoft
		/// bug in Visual Studio 2005, where trying to compile C++ code from Local System user
		/// account results in error C1902: Program database manager mismatch.
		/// </summary>
		/// <param name="args">The args.</param>
		/// <param name="workingDirectory">The working directory.</param>
		/// <param name="appOutput">The app output.</param>
		/// <returns>-1 if no args are specified, otherwise return value of executed app.</returns>
		/// ------------------------------------------------------------------------------------
		public int Run(string[] args, string workingDirectory, out string appOutput)
		{
			if (args == null || args.Length == 0)
			{
				appOutput = string.Empty;
				return -1;
			}

			m_bldr = new StringBuilder();

			//Thread outputThread;
			//Thread errorThread;

			using (m_process = new Process())
			{
				string fileName = Path.GetTempFileName();
				try
				{
					m_process.StartInfo.FileName = Path.Combine(
						Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location),
						"CompileServiceHelper.cmd"); // args[0];
					StringBuilder bldr = new StringBuilder();
					bldr.AppendFormat("\"{0}\" ", fileName);
					for (int i = 0; i < args.Length; i++)
					{
						if (args[i].Contains(" "))
							bldr.AppendFormat("\"{0}\" ", args[i]);
						else
							bldr.AppendFormat("{0} ", args[i]);
					}
					m_process.StartInfo.Arguments = bldr.ToString();
					m_process.StartInfo.CreateNoWindow = false;
					m_process.StartInfo.WorkingDirectory = workingDirectory;
					m_process.StartInfo.UseShellExecute = true; //false;
					//m_process.StartInfo.RedirectStandardOutput = true;
					//m_process.StartInfo.RedirectStandardError = true;
					m_process.Start();

					// Now start two threads to collect the output of the m_process. We have to 
					// do it separately because StandardOutput and StandardError are two different
					// streams.
					//outputThread = StartThread("Output", m_process.StandardOutput);
					//errorThread = StartThread("Error", m_process.StandardError);

					// Wait for the m_process to exit
					m_process.WaitForExit();

					// Wait for the threads to exit
					//outputThread.Join();
					//errorThread.Join();

					//appOutput = m_bldr.ToString();
					using (StreamReader reader = File.OpenText(fileName))
						appOutput = reader.ReadToEnd();
				}
				finally
				{
					File.Delete(fileName);
				}

				Debug.WriteLine(appOutput);
				return m_process.ExitCode;
			}
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Starts the thread that reads from the Standard Error/Output stream.
		/// </summary>
		/// <param name="name">The name.</param>
		/// <param name="reader">The reader.</param>
		/// <returns>The started thread</returns>
		/// ------------------------------------------------------------------------------------
		private Thread StartThread(string name, StreamReader reader)
		{
			Thread thread = new Thread(new ThreadStart(OutputHandler));
			thread.Name = name;
			m_htThreadStream[thread.Name] = reader;
			thread.Start();
			return thread;
		}

		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Reads from the stream until the external program is ended.
		/// </summary>
		/// ------------------------------------------------------------------------------------
		private void OutputHandler()
		{
			StreamReader reader;
			lock (m_htThreadStream.SyncRoot) 
				reader = (StreamReader)m_htThreadStream[Thread.CurrentThread.Name];

			while (true)
			{
				string strOutput = reader.ReadLine();
				if (strOutput == null)
					break;
				
				// Ensure only one thread writes to the string builder at any time
				lock (m_bldr)
					m_bldr.AppendLine(strOutput);
			}
		}
	}
}
