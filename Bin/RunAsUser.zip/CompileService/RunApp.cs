using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;
using System.Threading;

namespace CompileService
{
	public class RunApp : MarshalByRefObject
	{
		/// ------------------------------------------------------------------------------------
		/// <summary>
		/// Runs the application specified as first element in args, passing the remaining
		/// string in args as arguments. This class gets called from RunAsUser.exe, and it runs
		/// as a service with permissions of a local user. This is a workaround for a Microsoft
		/// bug in Visual Studio 2005, where trying to compile C++ code from Local System user
		/// account results in error C1902: Program database manager mismatch.
		/// </summary>
		/// <param name="args">The args.</param>
		/// <param name="workingDirectory">The working directory.</param>
		/// <param name="fileName">Name of the output file.</param>
		/// <returns>
		/// -1 if no args are specified, -2 if got exception, otherwise return value of 
		/// executed app.
		/// </returns>
		/// ------------------------------------------------------------------------------------
		public int Run(string[] args, string workingDirectory, string fileName)
		{
			if (args == null || args.Length == 0)
				return -1;

			try
			{
				using (Process process = new Process())
				{
					process.StartInfo.FileName = Path.Combine(
						Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location),
						"CompileServiceHelper.cmd");
					StringBuilder bldr = new StringBuilder();
					for (int i = 0; i < args.Length; i++)
					{
						if (args[i].Contains(" "))
							bldr.AppendFormat("\"{0}\" ", args[i]);
						else
							bldr.AppendFormat("{0} ", args[i]);
					}
					process.StartInfo.Arguments = bldr.ToString();
					process.StartInfo.CreateNoWindow = true;
					process.StartInfo.WorkingDirectory = workingDirectory;
					process.StartInfo.UseShellExecute = false;
					process.StartInfo.EnvironmentVariables.Add("__OUTPUTFILE__", fileName);
					process.Start();

					// Wait for the process to exit
					process.WaitForExit();

					return process.ExitCode;
				}
			}
			catch (Exception e)
			{
				using (StreamWriter writer = new StreamWriter(fileName))
					writer.WriteLine("Got exception in CompileService: " + e.Message);
				return -2;
			}
		}
	}
}
