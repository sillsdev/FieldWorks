RunAsUser is a tool to work around a Microsoft bug in Visual Studio 2005.

When trying to compile C++ code from Local System account it fails with error C1902: Program database manager mismatch. This bug was already fixed by Microsoft, but unfortunately there seems to be no Hotfix available for it. It should be fixed in the next version, but for the meantime we need a workaround.

Running as Local System doesn't allow starting processes as a different user, so we have to create a service that runs with a real user account, and then use RanAsUser to pass the information what to compile to that service, so that the compilation can be done under the real user account. 

To install: 
- Install the CompileService service with the provided setup
- Set user name and password the CompileService uses the run as
- Now RunAsuser can be used from build that runs as Local System account (e.g. Draco.NET)



This works, but is very slow. A better way to do it is run the build as user and then call RunAsuser for the NUnit tests and run them as Local System account. But still we need CompileService and RunAsUser.exe.