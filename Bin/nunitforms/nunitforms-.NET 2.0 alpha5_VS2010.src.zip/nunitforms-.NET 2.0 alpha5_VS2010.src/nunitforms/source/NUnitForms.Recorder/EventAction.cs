using System;
using System.Text;

namespace NUnit.Extensions.Forms.Recorder
{
    public class EventAction : Action
    {
        private string methodName;

        private object[] args;

        private string comment;

        public string MethodName
        {
            get
            {
                return methodName;
            }
        }

        public object[] Args
        {
            get
            {
                return args;
            }
        }

        public string Comment
        {
            set
            {
                comment = " //" + value;
            }
        }

        public EventAction(string methodName, params object[] args)
        {
            this.methodName = methodName;

            if(args.Length > 0 && args[0] is Array)
            {
                this.args = (object[]) args[0];
            }
            else
            {
                this.args = args;
            }

            comment = string.Empty;
        }

        private string NoSpace(string name)
        {
            return name.Replace(" ", "");
        }

        public override string ToString()
        {
            return string.Format("{0}.{1}({2});{3}", NoSpace(Definition.VarName), methodName, GetArgs(args), comment);
        }

        private string GetArgs(object[] args)
        {
            StringBuilder sb = new StringBuilder();
            bool first = true;
            foreach(object arg in args)
            {
                if(!first)
                {
                    sb.Append(", ");
                }
                first = false;
                sb.Append(FormatArgument(arg));
            }
            return sb.ToString();
        }

        private string FormatArgument(object arg)
        {
            if(arg is string)
            {
                return string.Format("\"{0}\"", arg.ToString());
            }
            return arg.ToString();
        }
    }
}