#region Copyright (c) 2003-2005, Luke T. Maxon

/********************************************************************************************************************
'
' Copyright (c) 2003-2005, Luke T. Maxon
' All rights reserved.
' 
' Redistribution and use in source and binary forms, with or without modification, are permitted provided
' that the following conditions are met:
' 
' * Redistributions of source code must retain the above copyright notice, this list of conditions and the
' 	following disclaimer.
' 
' * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and
' 	the following disclaimer in the documentation and/or other materials provided with the distribution.
' 
' * Neither the name of the author nor the names of its contributors may be used to endorse or 
' 	promote products derived from this software without specific prior written permission.
' 
' THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
' WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
' PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
' ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
' LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
' INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
' OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
' IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
'
'*******************************************************************************************************************/

#endregion

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace NUnit.Extensions.Forms.TestApplications
{
    /// <summary>
    /// Summary description for AmbiguousNameForm.
    /// </summary>
    public class AmbiguousNameForm : Form
    {
        private ButtonControl myControl1;

        private ButtonControl myControl2;

        private Label myFirstLabel;

        private Label mySecondLabel;

        /// <summary>
        /// Required designer variable.
        /// </summary>
        private Container components = null;

        public AmbiguousNameForm()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if(disposing)
            {
                if(components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.myControl2 = new ButtonControl();
            this.myControl1 = new ButtonControl();
            this.myFirstLabel = new Label();
            this.mySecondLabel = new Label();
            this.SuspendLayout();
            // 
            // myControl2
            // 
            this.myControl2.Location = new Point(8, 56);
            this.myControl2.Name = "myControl2";
            this.myControl2.Size = new Size(96, 40);
            this.myControl2.TabIndex = 2;
            this.myControl2.SuperClick += new EventHandler(this.onSuperClick2);
            // 
            // myControl1
            // 
            this.myControl1.Location = new Point(8, 8);
            this.myControl1.Name = "myControl1";
            this.myControl1.Size = new Size(96, 40);
            this.myControl1.TabIndex = 1;
            this.myControl1.SuperClick += new EventHandler(this.onSuperClick1);
            // 
            // myFirstLabel
            // 
            this.myFirstLabel.Location = new Point(120, 16);
            this.myFirstLabel.Name = "myFirstLabel";
            this.myFirstLabel.TabIndex = 3;
            this.myFirstLabel.Text = "0";
            // 
            // mySecondLabel
            // 
            this.mySecondLabel.Location = new Point(120, 72);
            this.mySecondLabel.Name = "mySecondLabel";
            this.mySecondLabel.TabIndex = 4;
            this.mySecondLabel.Text = "0";
            // 
            // AmbiguousNameForm
            // 
            this.AutoScaleDimensions = new SizeF(5, 13);
            this.ClientSize = new Size(232, 109);
            this.Controls.Add(this.mySecondLabel);
            this.Controls.Add(this.myFirstLabel);
            this.Controls.Add(this.myControl1);
            this.Controls.Add(this.myControl2);
            this.Name = "AmbiguousNameForm";
            this.Text = "AmbiguousNameForm";
            this.ResumeLayout(false);
        }

        #endregion

        private void onSuperClick1(object sender, EventArgs e)
        {
            IncrementLabel(myFirstLabel);
        }

        private void onSuperClick2(object sender, EventArgs e)
        {
            IncrementLabel(mySecondLabel);
        }

        private void IncrementLabel(Label label)
        {
            int i = int.Parse(label.Text) + 1;
            label.Text = i.ToString();
        }
    }
}