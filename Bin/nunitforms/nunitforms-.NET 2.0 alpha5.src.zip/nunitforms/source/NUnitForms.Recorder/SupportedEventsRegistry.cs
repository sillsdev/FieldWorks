#region Copyright (c) 2003-2004, Luke T. Maxon

/********************************************************************************************************************
'
' Copyright (c) 2003-2004, Luke T. Maxon
' All rights reserved.
' 
' Redistribution and use in source and binary forms, with or without modification, are permitted provided
' that the following conditions are met:
' 
' * Redistributions of source code must retain the above copyright notice, this list of conditions and the
' 	following disclaimer.
' 
' * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and
' 	the following disclaimer in the documentation and/or other materials provided with the distribution.
' 
' * Neither the name of the author nor the names of its contributors may be used to endorse or 
' 	promote products derived from this software without specific prior written permission.
' 
' THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
' WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
' PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
' ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
' LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
' INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
' OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
' IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
'
'*******************************************************************************************************************/

#endregion

using System;
using System.Collections;
using System.Reflection;
using System.Windows.Forms;

namespace NUnit.Extensions.Forms.Recorder
{
    public class Censor
    {
        //can suppress the effect of specific recorder assemblies during testing.
        //this is easier (and more hackish) than loading / unloading app domains.

        public static ArrayList list = new ArrayList();
    }

    internal class SupportedEventsRegistry
    {
        public MulticastDelegate EventHandler(Type type, string eventName)
        {
            Hashtable events;
            Type thisType = type;
            do
            {
                events = (Hashtable) table[thisType];
                thisType = thisType.BaseType;
            }
            while(events == null && thisType != typeof(object));

            if(events == null)
            {
                return null;
            }

            return (MulticastDelegate) events[eventName];
        }

        public EventHandler PropertyAssertHandler(Type type)
        {
            return (EventHandler) EventHandler(type, PropertyAssert);
        }

        public SupportedEventsRegistry(Listener listener)
        {
            foreach(Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                if(!Censor.list.Contains(assembly.FullName.Substring(0, assembly.FullName.IndexOf(","))))
                {
                    foreach(Type type in assembly.GetTypes())
                    {
                        if((type.IsSubclassOf(typeof(Recorder))) && (!type.IsAbstract))
                        {
                            AddRecorderToRegistry(type, listener);
                        }
                    }
                }
            }
        }

        private string PropertyAssert = "PropertyAssert";

        //table contains:
        //  key = type of a control
        //  value = hashtable where
        //           key = name of event
        //           value = delegate method listening to that event.
        private Hashtable table = new Hashtable();

        private void AddRecorderToRegistry(Type type, Listener listener)
        {
            Recorder recorder = (Recorder) Activator.CreateInstance(type, new object[] {listener});

            Hashtable events = new Hashtable();

            AddEventHandlersToRegistry(recorder, type, events);

            AddPropertyAssertHandlersToRegistry(recorder, events);

            table.Add(recorder.RecorderType, events);
        }

        private void AddEventHandlersToRegistry(Recorder recorder, Type type, Hashtable events)
        {
            ArrayList eventNames = EventNames(recorder.RecorderType);
            foreach(MethodInfo info in type.GetMethods())
            {
                if(!eventNames.Contains(info.Name))
                {
                    continue;
                }
                object handler = Delegate.CreateDelegate(EventHandlerType(info), recorder, info.Name, false);
                events.Add(info.Name, handler);
            }
        }

        private void AddPropertyAssertHandlersToRegistry(Recorder recorder, Hashtable events)
        {
            if(supportsProperties(recorder.TesterType))
            {
                object handler = Delegate.CreateDelegate(typeof(EventHandler), recorder, PropertyAssert, false);
                events.Add(PropertyAssert, handler);
            }
        }

        //make this prettier.  mapping when appropriate?
        private Type EventHandlerType(MethodInfo info)
        {
            ParameterInfo[] parms = info.GetParameters();
            if(parms.Length == 2 && parms[1].ParameterType == typeof(TreeViewEventArgs))
            {
                return typeof(TreeViewEventHandler);
            }
            if(parms.Length == 2 && parms[1].ParameterType == typeof(LinkLabelLinkClickedEventArgs))
            {
                return typeof(LinkLabelLinkClickedEventHandler);
            }
            else
            {
                return typeof(EventHandler);
            }
        }

        private ArrayList EventNames(Type controlType)
        {
            ArrayList list = new ArrayList();
            foreach(EventInfo info in controlType.GetEvents())
            {
                list.Add(info.Name);
            }
            return list;
        }

        private bool supportsProperties(Type type)
        {
            PropertyInfo info =
                    type.GetProperty("Properties",
                                     BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly);
            return info != null;
        }
    }
}