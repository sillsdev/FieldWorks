#region Copyright (c) 2003-2005, Luke T. Maxon

/********************************************************************************************************************
'
' Copyright (c) 2003-2005, Luke T. Maxon
' All rights reserved.
' 
' Redistribution and use in source and binary forms, with or without modification, are permitted provided
' that the following conditions are met:
' 
' * Redistributions of source code must retain the above copyright notice, this list of conditions and the
' 	following disclaimer.
' 
' * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and
' 	the following disclaimer in the documentation and/or other materials provided with the distribution.
' 
' * Neither the name of the author nor the names of its contributors may be used to endorse or 
' 	promote products derived from this software without specific prior written permission.
' 
' THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
' WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
' PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
' ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
' LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
' INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
' OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
' IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
'
'*******************************************************************************************************************/

#endregion

using System;
using System.Text;

namespace NUnit.Extensions.Forms.Recorder
{
    public class Definition
    {
        
        public Definition(object control, string name, Type testerType, string formName)
        {
            this.control = control;
            this.name = name;
            this.testerType = testerType;
            this.formName = formName;
        }

        public object Control
        {
            get
            {
                return control;
            }
        }

        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }

        /// <summary>
        /// The variable name of an instance.
        /// </summary>
        /// <example>
        /// <i>toolStripSplitButton1</i> Is the variable name of an instance:
        /// <code>
        /// ToolStripSplitButtonTester toolStripSplitButton1 = new ToolStripSplitButtonTester("toolStripSplitButton1");
        /// </code>
        /// </example>
        public string VarName
        {
            get
            {
                if(FormName == null)
                {
                    return Name;
                }
                else
                {
                    return FormName + "_" + Name;
                }
            }
        }

        public string FormName
        {
            get
            {
                return formName;
            }
            set
            {
                formName = value;
            }
        }

        public Type TesterType
        {
            get
            {
                return testerType;
            }
        }

        public override string ToString()
        {
            StringBuilder buffer = new StringBuilder();
            if (FormName == null)
            {
                buffer.Append(
                        string.Format("{0} {1} = new {0}(\"{2}\");", TesterType.Name,
                                      NoSpace(VarName), Name.Replace("_", ".")));
            }
            else
            {
                buffer.Append(
                        string.Format("{0} {1} = new {0}(\"{2}\", \"{3}\");", TesterType.Name,
                                      NoSpace(VarName), Name.Replace("_", "."),
                                      FormName));
            }
            return buffer.ToString();
        }

        /// <summary>
        /// Removes all spaces from a string.
        /// </summary>
        /// <param name="name">
        /// Remove all spaces from this string.
        /// </param>
        /// <returns>
        /// <list type="bullet">
        /// <item><paramref name="name"/> without spaces.</item>
        /// <item>if <paramref name="name"/> is not effective, returns an empty string</item>
        /// </list>
        /// </returns>
        private string NoSpace(string name)
        {
            if (name != null)
            {
                return name.Replace(" ", "");
            }
            else
            {
                return String.Empty;
            }
        }

        private object control;

        private string name;

        private Type testerType;

        private string formName;
    }
}