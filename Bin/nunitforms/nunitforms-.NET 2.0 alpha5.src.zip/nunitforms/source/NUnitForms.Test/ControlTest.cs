#region Copyright (c) 2003-2005, Luke T. Maxon

/********************************************************************************************************************
'
' Copyright (c) 2003-2005, Luke T. Maxon
' All rights reserved.
' 
' Redistribution and use in source and binary forms, with or without modification, are permitted provided
' that the following conditions are met:
' 
' * Redistributions of source code must retain the above copyright notice, this list of conditions and the
' 	following disclaimer.
' 
' * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and
' 	the following disclaimer in the documentation and/or other materials provided with the distribution.
' 
' * Neither the name of the author nor the names of its contributors may be used to endorse or 
' 	promote products derived from this software without specific prior written permission.
' 
' THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
' WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
' PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
' ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
' LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
' INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
' OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
' IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
'
'*******************************************************************************************************************/

#endregion

using System;
using System.Reflection;
using System.Windows.Forms;

using NUnit.Extensions.Forms.TestApplications;
using NUnit.Framework;

namespace NUnit.Extensions.Forms.TestApplications
{
    [TestFixture]
    public class ControlTest : NUnitFormTest
    {
        private ControlTester label;

        public override void Setup()
        {
            new LabelTestForm().Show();
            label = new ControlTester("myLabel");
        }

        [Test]
        public void ControlText()
        {
            Assert.AreEqual("myValue", label.Text);
        }

        [Test]
        public void ControlClick()
        {
            Assert.AreEqual("myValue", label.Text);
        }

        [Test]
        public void Property()
        {
            Assert.AreEqual("myValue", label["Text"]);
            label["Text"] = "try to change it";
            Assert.AreEqual("try to change it", label["Text"]);
        }

        [Test]
        public void ControlTestersHaveFourConstructorsAndIndexer()
        {
            //crazy test :)

            Type[] types = typeof(ControlTester).Assembly.GetTypes();
            foreach(Type type in types)
            {
                if(type == typeof(ControlTester) || type.IsSubclassOf(typeof(ControlTester)))
                {
                    ConstructorInfo[] constructors = type.GetConstructors();
                    if(type == typeof(FormTester))
                    {
                        continue; //it only has 1 constructor
                    }
                    if(type == typeof(MessageBoxTester))
                    {
                        continue; //it only has 2 constructors
                    }

                    // OpenFileDialogTester only has one construtor.
                    if (type == typeof(OpenFileDialogTester))
                    {
                      Assert.AreEqual(1, constructors.Length, type.Name + "has incorrect constructor count.");
                      continue;
                    }

                    Assert.AreEqual(4, constructors.Length, type.Name + "has incorrect constructor count.");

                    VerifyEach(type.Name, constructors);
                    VerifyIndexer(type);
                }
            }
        }

        private void VerifyIndexer(Type type)
        {
            PropertyInfo[] property = type.GetProperties();
            bool indexerVerified = false;
            foreach(PropertyInfo prop in property)
            {
                if(prop.Name == "Item")
                {
                    if(prop.PropertyType == type)
                    {
                        if(prop.GetIndexParameters().Length == 1)
                        {
                            if(prop.GetIndexParameters()[0].ParameterType == typeof(int))
                            {
                                prop.GetGetMethod().Invoke(Activator.CreateInstance(type, new object[] {"string"}),
                                                           new object[] {0});
                                indexerVerified = true;
                                break;
                            }
                        }
                    }
                }
            }
            Assert.IsTrue(indexerVerified);
        }

        private bool constructor1; //string

        private bool constructor2; //string, string

        private bool constructor3; //string, Form

        private bool constructor4; //controlTester, int

        private void VerifyEach(string typeName, ConstructorInfo[] constructors)
        {
            constructor1 = false;
            constructor2 = false;
            constructor3 = false;
            constructor4 = false;
            foreach(ConstructorInfo constructor in constructors)
            {
                constructor1 = constructor1 || CheckMatches(constructor, "string");
                constructor2 = constructor1 || CheckMatches(constructor, "string", "string");
                constructor3 = constructor1 || CheckMatches(constructor, "string", new Form());
                constructor4 = constructor1 || CheckMatches(constructor, new ControlTester("string"), 1);
            }
            Assert.IsTrue(constructor1, typeName + " missing constructor 1");
            Assert.IsTrue(constructor2, typeName + " missing constructor 2");
            Assert.IsTrue(constructor3, typeName + " missing constructor 3");
            Assert.IsTrue(constructor4, typeName + " missing constructor 4");
        }

        private bool CheckMatches(ConstructorInfo constructor, params object[] args)
        {
            ParameterInfo[] parameters = constructor.GetParameters();

            if(parameters.Length != args.Length)
            {
                return false;
            }
            for(int i = 0; i < args.Length; i++)
            {
                if(parameters[i].ParameterType != args[i].GetType())
                {
                    return false;
                }
            }

            constructor.Invoke(args); //test it

            return true;
        }

        [Test]
        [ExpectedException(typeof(Exception), "Should not have index < 0")]
        public void BadIndex()
        {
            object o = new ControlTester("s")[-1];
            Assert.Fail("Should not find: " + o);
        }
    }
}