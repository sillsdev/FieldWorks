using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace NUnit.Extensions.Forms.TestApplications
{
	/// <summary>
	/// Summary description for ContextMenuBlankFormWithContextMenu.
	/// </summary>
	public class ContextMenuBlankFormWithContextMenu : System.Windows.Forms.Form
	{
		private System.Windows.Forms.ContextMenu formContextMenu;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.Label contextMenuItemLabel;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ContextMenuBlankFormWithContextMenu()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.formContextMenu = new System.Windows.Forms.ContextMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.contextMenuItemLabel = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// formContextMenu
			// 
			this.formContextMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																																										this.menuItem1,
																																										this.menuItem2,
																																										this.menuItem3});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.Text = "Menu Item 1";
			this.menuItem1.Click += new System.EventHandler(this.menuItem1_Click);
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 1;
			this.menuItem2.Text = "Menu Item 2";
			this.menuItem2.Click += new System.EventHandler(this.menuItem2_Click);
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 2;
			this.menuItem3.Text = "Menu Item 3";
			this.menuItem3.Click += new System.EventHandler(this.menuItem3_Click);
			// 
			// contextMenuItemLabel
			// 
			this.contextMenuItemLabel.Location = new System.Drawing.Point(24, 56);
			this.contextMenuItemLabel.Name = "contextMenuItemLabel";
			this.contextMenuItemLabel.Size = new System.Drawing.Size(160, 23);
			this.contextMenuItemLabel.TabIndex = 0;
			this.contextMenuItemLabel.Text = "label1";
			// 
			// ContextMenuBlankFormWithContextMenu
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.ContextMenu = this.formContextMenu;
			this.Controls.Add(this.contextMenuItemLabel);
			this.Name = "ContextMenuBlankFormWithContextMenu";
			this.Text = "ContextMenuBlankFormWithContextMenu";
			this.ResumeLayout(false);

		}
		#endregion

		private void menuItem1_Click(object sender, System.EventArgs e)
		{
			contextMenuItemLabel.Text = menuItem1.Text;
		}

		private void menuItem2_Click(object sender, System.EventArgs e)
		{
			contextMenuItemLabel.Text = menuItem2.Text;
		}

		private void menuItem3_Click(object sender, System.EventArgs e)
		{
			contextMenuItemLabel.Text = menuItem3.Text;
		}
	}
}
