using System;
using NUnit.Framework;
using SIL.FieldWorks.Common.Utils;

namespace SIL.FieldWorks.XWorks.MorphologyEditor
{
	/// <summary>finder
	/// Summary description for InterlinTests.
	/// </summary>
	public class ME_RecordClerkTests : RecordClerkTests
	{
		public ME_RecordClerkTests() 
		{
		}

		
		protected override void Init()
		{
			m_application =new MorphologyEditorApp();
		}
//
//		protected static string ConfigurationFilePath
//		{
//			get
//			{
//				string s = SIL.FieldWorks.Common.Utils.DirectoryFinder.FWInstallDirectory;
//				return s+@"\morphologyeditor\me.xml";
//			}
//		}

		[Test]
		public void AddRemovePOS()
		{
			InsertDelete("Categories", "Categories", "CmdInsertPOS");
		}
	}
}
