using System;
using NUnit.Framework;

namespace SIL.FieldWorks.XWorks.MorphologyEditor
{
	/// <summary>
	/// Summary description for ME_DataTreeSmokeTests.
	/// </summary>
	public class ME_DataTreeSmokeTests : SIL.FieldWorks.XWorks.DataTreeSmokeTests
	{
		public ME_DataTreeSmokeTests()
		{
		}
		protected override void Init()
		{
			m_application =new MorphologyEditorApp();
		}

		[Test]
	//	[Ignore("The DotNetBar Adapter does not support this kind of testing yet.")]
		public void POS_Smoke()
		{
			StandardViewTest("Categories");
		}


		[Test]
	//	[Ignore("The DotNetBar Adapter does not support this kind of testing yet.")]
		public void Adhoc_Smoke()
		{
			StandardViewTest("Adhoc Coprohibitions");
		}
		
		[Test]
	//	[Ignore("The DotNetBar Adapter does not support this kind of testing yet.")]
		public void CmpRules_Smoke()
		{
			StandardViewTest("Compound Rules");
		}
		

		[Test]
	//	[Ignore("The DotNetBar Adapter does not support this kind of testing yet.")]
		public void Phonemes_Smoke()
		{
			StandardViewTest("Phonemes");
		}
		
//		[Test]
//		public void Boundary_Smoke()
//		{
//			StandardViewTest("Boundary Markers");
//		}
		
		[Test]
	//	[Ignore("The DotNetBar Adapter does not support this kind of testing yet.")]
		public void Environments_Smoke()
		{
			StandardViewTest("Environments");
		}
		
		[Test]
	//	[Ignore("The DotNetBar Adapter does not support this kind of testing yet.")]
		public void NC_Smoke()
		{
			StandardViewTest("Natural Classes");
		}

	}
}
